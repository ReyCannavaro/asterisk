//   javascript//   javascript

import { useRouter, useRoute, RouterLink } from 'vue-router'
import { ref, readonly, reactive, inject, onMounted, onBeforeMount, watchEffect, onActivated } from 'vue'

const router = useRouter()
const route = useRoute()
const store = inject('store')
const swal = inject('swal')

const isRead = route.params.id && route.params.id !== 'create'
const actionText = ref(route.params.id === 'create' ? 'Tambah' : (route.query.action?.toLowerCase() === 'verifikasi' ? null : route.query.action))
const isBadForm = ref(false)
const isRequesting = ref(false)
const modulPath = route.params.modul
const currentMenu = store.currentMenu
const apiTable = ref(null)
const detailArr = ref([])
const titleOpen = ref('')
const formErrors = ref({})
const modalOpen = ref(false)
const detailArrOpen = reactive({ items: [] })
const detailArrAdjOpen = reactive({ items: [] })
let objectOpen = reactive({ items: 0 })
let idxOpen = reactive({ value: null })
let totalAdjOpen = reactive({ value: 0 })
let totalAdjPPHOpen = reactive({ value: 0 })
let totalAdjFinalOpen = reactive({ value: 0 })
const tsId = `ts=` + (Date.parse(new Date()))
let isApproved = ref(false)
let isFinish = ref(false)
const is_approval = route.query.is_approval ? true : false
const is_to_upload = route.query.is_to_upload ? true : false

// ------------------------------ PERSIAPAN
const endpointApi = '/t_final_gaji'
onBeforeMount(() => {
  document.title = 'Finalisasi Gaji'
})

function formatRupiah(amount) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(amount);
}


//  @if( $id )------------------- VALUES FORM ! PENTING JANGAN DIHAPUS
let initialValues = {}
const changedValues = []
let _id = 0
let thisMonth = new Date().toISOString().split('T')[0]
let tempYear = thisMonth.split('-')[0]
let tempMonth = thisMonth.split('-')[1]
const values = reactive({
  total_pengeluaran_gaji: 0,
})

// function closeModal() {
//   detailArrOpen.items = []
//   modalOpen.value = false
// }

function openDetail(i) {
  idxOpen.value = i
  detailArrAdjOpen.items = []
  objectOpen.items = detailArr.value[i]
  titleOpen.value = detailArr.value[i]['m_kary.nama_lengkap'] ?? '-' + ' - ' + detailArr.value[i]['m_kary.nik'] ?? ''
  let dataFormat = detailArr.value[i]?.detail_gaji?.slice() ?? detailArr.value[i].t_final_gaji_det_rincian?.sort((a, b) => a.seq - b.seq)

  // ambil dari detail_adj ketika sudah pernah memproses data adj
  detailArrOpen.items = dataFormat

  dataFormat = detailArr.value[i]?.detail_adj?.length ? detailArr.value[i]?.detail_adj : dataFormat
  dataFormat.filter(item => item.can_adjust == 1).forEach((v) => {
    const formattedValue = parseFloat(v.value);
    // Push a new object with the formatted value
    detailArrAdjOpen.items.push({
      ...v,
      default: v.default ?? true,
      type: v.type,
      value_ref: formattedValue,
      value: formattedValue
    });
  })

  summaryAdj()
  generatePPH(false)

  modalOpen.value = true
}

function addRowAdj() {
  detailArrAdjOpen.items.push({
    _id: ++_id,
    label: '',
    name: '',
    can_adjust: 1,
    default: false,
    factor: '+',
    type: 'Bulanan',
    value_ref: null,
    value: 0
  })
}

function summaryAdj() {
  totalAdjPPHOpen.value = []
  totalAdjOpen.value = 0
  detailArrAdjOpen.items.forEach((v) => {
    if (v.factor == '-') {
      totalAdjOpen.value -= Number(v.value ?? 0)
    } else if (v.factor == '+') {
      totalAdjOpen.value += Number(v.value ?? 0)
    }
  })

  totalAdjFinalOpen.value = totalAdjOpen.value
  summaryPengeluaranGaji()
}

function summaryPengeluaranGaji() {
  values.total_pengeluaran_gaji = detailArr.value.reduce((a, b) => {
    const netto = Number(b.netto);
    if (!isNaN(netto)) {
      return a + netto;
    } else {
      console.warn(`Skipping non-numeric value: ${b.netto}`);
      return a;
    }
  }, 0)
}

function onProcess(typePar) {
  const payload = {
    id: route.params.id,
    type: typePar === 'revise' ? 'REVISED' : (typePar === 'reject' ? 'REJECTED' : 'APPROVED'),
    note: values.catatan,
  };
  // if(!payload.note) {
  //   swal.fire({
  //     icon: 'warning',
  //     text: "Catatan wajib diisi",
  //   });
  //   return  
  // }


  swal.fire({
    icon: 'warning',
    text: typePar === 'revise' ? 'Revised data?' : (typePar === 'reject' ? 'Rejected data?' : 'Approved data?'),
    showDenyButton: true,
  }).then(async (res) => {
    if (res.isConfirmed) {
      try {
        const dataURL = `${store.server.url_backend}/operation${endpointApi}/progress`;
        isRequesting.value = true;
        const res = await fetch(dataURL, {
          method: 'POST',
          headers: {
            'Content-Type': 'Application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`,
          },
          body: JSON.stringify(payload),
        });




        if (!res.ok) {
          const responseJson = await res.json();
          if ([400, 422, 500].includes(res.status)) {
            formErrors.value = responseJson.errors || {};
            if (res.status === 422) {
              throw new Error(responseJson.message + " Pastikan anda sudah mengisi semua kolom dengan tanda bintang merah");
            }
            throw new Error(responseJson.message || "Failed when trying to post data");
          } else {
            throw new Error("Failed when trying to post data");
          }
        } else {
          // Success case
          swal.fire({
            icon: 'success',
            text: 'Proses berhasil',
          });
          router.replace('/notifikasi');
        }
      } catch (err) {
        isBadForm.value = true;
        swal.fire({
          icon: 'error',
          text: err || 'Failed when trying to post data',
        });
      } finally {
        isRequesting.value = false;
      }
    }
  });

  if (route.params.id === 'create') {
    activeTabIndex = 0;
  }
}

onBeforeMount(async () => {
  values.direktorat = store.user.data?.direktorat

  if (isRead) {
    try {
      let dataURL = ''
      let dataURLAprv = ''
      let resAprv = ''
      if (route.query.is_approval) {
        dataURLAprv = `${store.server.url_backend}/operation/t_final_gaji/detail?id=${route.params.id}`
        isRequesting.value = true

        const apiApp = await fetch(dataURLAprv, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`
          },
        })
        const resultJson = await apiApp.json()

        const apiTrx = await fetch(`${store.server.url_backend}/operation${endpointApi}/${resultJson.data.approval.trx_id}`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`
          },
        })

        if (!apiTrx.ok || !apiApp.ok) throw new Error("Failed when trying to read data")
        const resultTrxJson = await apiTrx.json()

        values.interval = resultJson?.data.approval
        values.approval = resultJson?.data.approval
        values.trx = resultJson?.data.trx
        values.datalog = resultJson?.data.approval_log
        initialValues = resultTrxJson.data

        // Format periode_awal dan periode_akhir
        const [tahunAwal, bulanAwal] = initialValues.periode_awal?.split('-') || []
        const [tahunAkhir, bulanAkhir] = initialValues.periode_akhir?.split('-') || []
        initialValues.periode_awal = `${tahunAwal}-${bulanAwal}`
        initialValues.periode_akhir = `${tahunAkhir}-${bulanAkhir}`

        // Urutkan detail dan tambahkan nama karyawan
        detailArr.value = initialValues.t_final_gaji_det?.sort((a, b) => a.id - b.id) || []
        detailArr.value.forEach((item) => {
          item.karyawan = item['m_kary.nama_lengkap']
        })

        isApproved.value = resultTrxJson?.data?.status_final === 'APPROVED'
        isFinish.value = resultJson?.data?.approval?.tahap_saat_ini === resultJson?.data?.approval?.tahap_total
      } else {
        const editedId = route.params.id
        dataURL = `${store.server.url_backend}/operation${endpointApi}/${editedId}`
        isRequesting.value = true

        const params = { transform: false }
        const fixedParams = new URLSearchParams(params)
        const res = await fetch(dataURL + '?' + fixedParams, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`
          },
        })

        if (!res.ok) throw new Error("Failed when trying to read data")
        const resultJson = await res.json()
        initialValues = resultJson.data

        // Format periode_awal dan periode_akhir
        const [tahunAwal, bulanAwal] = initialValues.periode_awal?.split('-') || []
        const [tahunAkhir, bulanAkhir] = initialValues.periode_akhir?.split('-') || []
        initialValues.periode_awal = `${tahunAwal}-${bulanAwal}`
        initialValues.periode_akhir = `${tahunAkhir}-${bulanAkhir}`

        // Urutkan detail dan tambahkan nama karyawan
        detailArr.value = initialValues.t_final_gaji_det?.sort((a, b) => a.id - b.id) || []
        detailArr.value.forEach((item) => {
          item.karyawan = item['m_kary.nama_lengkap']
        })

        isApproved.value = resultJson?.data?.status_final === 'APPROVED'
      }
    } catch (err) {
      isBadForm.value = true
      swal.fire({
        icon: 'error',
        text: err.message || err,
        allowOutsideClick: false,
        confirmButtonText: 'Kembali'
      }).then(() => router.back())
    } finally {
      isRequesting.value = false
    }
  }

  for (const key in initialValues) {
    values[key] = initialValues[key]
  }
})


function onBack() {
  if (route.query.view_gaji) {
    router.replace('/t_info_gaji')
  } else {
    router.replace('/' + modulPath)
  }
  return
  // let isChanged = false
  // for (const key in initialValues) {
  //   if (values[key] !== initialValues[key]) {
  //     isChanged = true
  //     break;
  //   }
  // }

  // if (!isChanged) {
  //   router.replace('/' + modulPath)
  //   return
  // }

  // swal.fire({
  //   icon: 'warning',
  //   text: 'Buang semua perubahan dan kembali ke list data?',
  //   showDenyButton: true
  // }).then((res) => {
  //   if (res.isConfirmed) {
  //     router.replace('/' + modulPath)
  //   }
  // })
}

function onReset() {
  swal.fire({
    icon: 'warning',
    text: 'Reset this form data?',
    showDenyButton: true
  }).then((res) => {
    if (res.isConfirmed) {
      for (const key in initialValues) {
        values[key] = initialValues[key]
      }
    }
  })
}


function openModal(id) {
  dataLog.items = []
  modalOpen.value = true
  loadLog(id)
}

function closeModal(i) {
  dataLog.items = []
  modalOpen.value = false
}

let dataLog = reactive({ items: [] })
async function loadLog(id) {
  const url = `${store.server.url_backend}/operation/t_cuti/log?id=${id}`
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'Application/json',
      Authorization: `${store.user.token_type} ${store.user.token}`
    },
  })
  if (!res.ok) throw new Error("Failed when trying to read data")
  const result = await res.json()
  dataLog.items = result
}


async function generatePPH(popup = true) {
  try {
    const dataURL = `${store.server.url_backend}/operation/t_perhitungan_gaji/generatePPH`
    const params = {
      m_kary_id: objectOpen.items['m_kary_id'],
      netto: totalAdjOpen.value,
    }
    const fixedParams = new URLSearchParams(params)
    const res = await fetch(dataURL + '?' + fixedParams, {
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`,
      }
    })
    if (!res.ok) {
      if ([400, 422].includes(res.status)) {
        const responseJson = await res.json()
        formErrors.value = responseJson.errors || {}
        throw (responseJson.errors.length ? responseJson.errors[0] : responseJson.message || "Failed when trying to post data")
      } else {
        throw ("Failed when trying to post data")
      }
    }

    const result = await res.json()
    if (result.length) {
      totalAdjPPHOpen.value = result
      totalAdjFinalOpen.value = totalAdjOpen.value - totalAdjPPHOpen.value[0]?.value ?? 0
    } else {
      totalAdjPPHOpen.value = 0;
      if (!popup) return
      swal.fire({
        icon: 'warning',
        text: 'Total Gaji berdasarkan jenis tanggungan dibawah standar minimun perhitungan PPH'
      })
    }

  } catch (err) {
    isBadForm.value = true
    swal.fire({
      icon: 'error',
      text: err
    })
  }
}

function formatDate(dateStr) {
  if (!dateStr) return null
  if (typeof dateStr === 'string' && dateStr.includes('/')) {
    const parts = dateStr.split('/')
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`
    }
  }
  return dateStr
}

async function generatePerhitungan() {
  detailArr.value = []
  try {
    const dataURL = `${store.server.url_backend}/operation/t_perhitungan_gaji`
    const params = {
      scopes: 'GenerateForFinal',
      periode_awal: formatDate(values.periode_awal),
      periode_akhir: formatDate(values.periode_akhir),
      m_divisi_id: values.m_divisi_id,
      m_dept_id: values.m_dept_id,
      paginate: 9999
    }

    const fixedParams = new URLSearchParams(params)
    const res = await fetch(dataURL + '?' + fixedParams, {
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`,
      }
    })

    if (!res.ok) {
      if ([400, 422].includes(res.status)) {
        const responseJson = await res.json()
        formErrors.value = responseJson.errors || {}
        throw (responseJson.errors?.length ? responseJson.errors[0] : responseJson.message || "Failed when trying to post data")
      } else if (res.status === 500) {
        const responseJson = await res.json().catch(() => ({}))
        throw (responseJson.message || "Terjadi kesalahan server saat mengambil data perhitungan gaji.")
      } else {
        throw ("Failed when trying to post data")
      }
    }

    const result = await res.json()
    const resultData = result.data || []
    console.log('json', result)

    if (!resultData.length) {
      return swal.fire({
        icon: 'warning',
        text: 'Tidak ditemukan data Perhitungan Gaji untuk periode ini. Pastikan Perhitungan Gaji sudah dilakukan.'
      })
    }

    resultData.forEach((item) => {
      item._id = ++_id
      item.t_perhitungan_gaji_id = item.id
      item.karyawan = item['m_kary.nama_lengkap']
      item.deskripsi = item['deskripsi']
      item.detail_gaji = item['detail_gaji']
    })

    detailArr.value = resultData
    summaryPengeluaranGaji()
  } catch (err) {
    isBadForm.value = true
    swal.fire({
      icon: 'error',
      text: err?.message || err || 'Terjadi kesalahan'
    })
  }
}


function deleteRow(item) {
  detailArrAdjOpen.items = detailArrAdjOpen.items.filter((e) => e._id != item._id)
  summaryAdj()
  generatePPH(false)
}

function saveModal() {
  // idxOpen.value

  console.log(detailArrAdjOpen.items)
  detailArrAdjOpen.items = detailArrAdjOpen.items.concat(totalAdjPPHOpen.value)

  // assign seq
  // if(detailArrAdjOpen.items.length !== length){
  //   detailArrAdjOpen.items.forEach((v,i)=>{
  //     v.seq = i+1
  //   })
  // }
  detailArrAdjOpen.items.forEach((v, i) => {
    if (v == 0) {
      return
    }

    v.seq = i + 1
  })

  // assign for subdetail
  detailArr.value[idxOpen.value]['detail_adj'] = detailArrAdjOpen.items

  detailArr.value[idxOpen.value]['total_tax'] = totalAdjPPHOpen.value.length ? totalAdjPPHOpen.value[0].value : 0
  detailArr.value[idxOpen.value]['netto'] = totalAdjFinalOpen.value
  generatePPH(false)
  summaryPengeluaranGaji()
  modalOpen.value = false
}

async function posted() {
  const payload = {
    id: route.params.id
  }
  try {
    const dataURL = `${store.server.url_backend}/operation${endpointApi}/postData`
    isRequesting.value = true
    const res = await fetch(dataURL, {
      method: 'POST',
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`
      },
      body: JSON.stringify(payload)
    })
    if (!res.ok) {
      if ([400, 422].includes(res.status)) {
        const responseJson = await res.json()
        formErrors.value = responseJson.errors || {}
        throw (responseJson.message || "Failed when trying to post data")
      } else {
        throw ("Failed when trying to post data")
      }
    }
    router.replace('/' + modulPath + '?reload=' + (Date.parse(new Date())))
  } catch (err) {
    isBadForm.value = true
    swal.fire({
      icon: 'error',
      text: err
    })
  }
  isRequesting.value = false

}

async function onSave() {
  const isCreating = ['Create', 'Copy', 'Tambah'].includes(actionText.value)
  let dataSave = JSON.parse(JSON.stringify(values))
  
  dataSave['periode_awal'] = formatDate(dataSave['periode_awal'])
  dataSave['periode_akhir'] = formatDate(dataSave['periode_akhir'])

  // Clean and map details so only valid columns are sent (and payload is lightweight)
  dataSave['t_final_gaji_det'] = detailArr.value.map((v) => {
    const rincianSource = (v.detail_adj && v.detail_adj.length) ? v.detail_adj : (v.detail_gaji || [])
    
    const cleanedRincian = rincianSource.map((d, i) => {
      const rincianObj = {
        seq: i + 1,
        name: d.name || d.label || '',
        label: d.label || d.name || '',
        type: d.type || 'Bulanan',
        factor: d.factor || '+',
        value_ref: d.value_ref !== undefined && d.value_ref !== null ? d.value_ref : d.value,
        value: Number(d.value) || 0,
        can_adjust: d.can_adjust ? 1 : 0,
        t_potongan_id: d.t_potongan_id || null,
        t_cuti_id: d.t_cuti_id || null,
        deskripsi: d.deskripsi || null
      }
      if (!isCreating && d.id) {
        rincianObj.id = d.id
      }
      return rincianObj
    })

    const detObj = {
      t_perhitungan_gaji_id: v.t_perhitungan_gaji_id || (isCreating ? v.id : undefined),
      m_kary_id: v.m_kary_id,
      m_kary_dir_id: v.m_kary_dir_id,
      m_kary_divisi_id: v.m_kary_divisi_id,
      m_kary_dept_id: v.m_kary_dept_id,
      periode: v.periode,
      periode_in_date: formatDate(v.periode_in_date) || dataSave['periode_awal'],
      total_gaji: Number(v.total_gaji) || 0,
      total_tax: Number(v.total_tax) || 0,
      netto: Number(v.netto) || 0,
      periode_id: v.periode_id || null,
      deskripsi: v.deskripsi || '',
      status: v.status || 'DRAFT',
      t_final_gaji_det_rincian: cleanedRincian
    }

    if (!isCreating && v.id) {
      detObj.id = v.id
    }

    return detObj
  })

  try {
    isRequesting.value = true
    const dataURL = `${store.server.url_backend}/operation${endpointApi}${isCreating ? '' : ('/' + route.params.id)}`
    const res = await fetch(dataURL, {
      method: isCreating ? 'POST' : 'PUT',
      headers: {
        'Content-Type': 'Application/json',
        Authorization: `${store.user.token_type} ${store.user.token}`
      },
      body: JSON.stringify(dataSave)
    })
    if (!res.ok) {
      if ([400, 422].includes(res.status)) {
        const responseJson = await res.json()
        formErrors.value = responseJson.errors || {}
        throw (responseJson.errors?.length ? responseJson.errors[0] : responseJson.message || "Failed when trying to post data")
      } else if (res.status === 500) {
        const responseJson = await res.json().catch(() => ({}))
        throw (responseJson.message || "Terjadi kesalahan server saat menyimpan data finalisasi gaji.")
      } else {
        throw ("Failed when trying to post data")
      }
    }
    router.replace('/' + modulPath + '?reload=' + (Date.parse(new Date())))
  } catch (err) {
    isBadForm.value = true
    swal.fire({
      icon: 'error',
      text: err?.message || err || 'Terjadi kesalahan'
    })
  } finally {
    isRequesting.value = false
  }
}

//  @else----------------------- LANDING
const landing = reactive({
  actions: [
    {
      icon: 'trash',
      class: 'bg-red-600 text-light-100',
      title: "Hapus",
      show: (row) => row.status?.toUpperCase() === 'DRAFT',
      // show: () => store.user.data.username==='developer',
      click(row) {
        swal.fire({
          icon: 'warning',
          text: 'Hapus Data Terpilih?',
          confirmButtonText: 'Yes',
          showDenyButton: true,
        }).then(async (result) => {
          if (result.isConfirmed) {
            try {
              const dataURL = `${store.server.url_backend}/operation${endpointApi}/${row.id}`
              isRequesting.value = true
              const res = await fetch(dataURL, {
                method: 'DELETE',
                headers: {
                  'Content-Type': 'Application/json',
                  Authorization: `${store.user.token_type} ${store.user.token}`
                }
              })
              if (!res.ok) {
                const resultJson = await res.json()
                throw (resultJson.message || "Failed when trying to remove data")
              }
              apiTable.value.reload()
              const resultJson = await res.json()
            } catch (err) {
              isBadForm.value = true
              swal.fire({
                icon: 'error',
                text: err
              })
            }
            isRequesting.value = false
          }
        })
      }
    },
    {
      icon: 'eye',
      title: "Read",
      class: 'bg-green-600 text-light-100',
      // show: (row) => (currentMenu?.can_read)||store.user.data.username==='developer',
      // click(row) {
      //   openDetailFromLanding(row)
      // }'
      click(row) {
        router.push(`${route.path}/${row.id}?` + tsId)
      }
    },
    {
      icon: 'edit',
      title: "Edit",
      class: 'bg-blue-600 text-light-100',
      show: (row) => row.status?.toUpperCase() === 'DRAFT',
      // show: (row) => (currentMenu?.can_update)||store.user.data.username==='developer',
      click(row) {
        router.push(`${route.path}/${row.id}?action=Edit&` + tsId)
      }
    },
    {
      icon: 'paper-plane',
      title: "Posted Data",
      class: 'bg-rose-700 rounded-lg text-white',
      show: (row) => row.status?.toUpperCase() === 'DRAFT',
      click(row) {
        router.push(`${route.path}/${row.id}?action=Verifikasi&` + tsId)
      }
    },
    {
      icon: 'location-arrow',
      title: "Send Approval",
      class: 'bg-rose-700 rounded-lg text-white',
      show: (row) => {
        const status = row.status?.toUpperCase()
        return ['POSTED', 'REVISED'].includes(status)
      },

      async click(row) {
        swal.fire({
          icon: 'warning',
          text: 'Send Approval?',
          iconColor: '#1469AE',
          confirmButtonColor: '#1469AE',

          showDenyButton: true
        }).then(async (res) => {
          if (res.isConfirmed) {
            try {
              const dataURL = `${store.server.url_backend}/operation/t_final_gaji/send_approval`
              isRequesting.value = true
              const res = await fetch(dataURL, {
                method: 'POST',
                headers: {
                  'Content-Type': 'Application/json',
                  Authorization: `${store.user.token_type} ${store.user.token}`
                },
                body: JSON.stringify({ id: row.id })
              })
              if (!res.ok) {
                if ([400, 422, 500].includes(res.status)) {
                  const responseJson = await res.json()
                  formErrors.value = responseJson.errors || {}
                  throw (responseJson.message + " " + responseJson.data.errorText || "Failed when trying to post data")
                } else {
                  throw ("Failed when trying to post data")
                }
              }
              const responseJson = await res.json()
              swal.fire({
                icon: 'success',
                text: responseJson.message
              })
              // const resultJson = await res.json()
            } catch (err) {
              isBadForm.value = true
              swal.fire({
                icon: 'error',
                iconColor: '#1469AE',
                confirmButtonColor: '#1469AE',
                text: err
              })
            }
            isRequesting.value = false

            apiTable.value.reload()
          }
        })
      }
    }
  ],
  api: {
    url: `${store.server.url_backend}/operation${endpointApi}`,
    headers: {
      'Content-Type': 'Application/json',
      authorization: `${store.user.token_type} ${store.user.token}`
    },
    params: {
      simplest: true,
      searchfield: 'this.nomor, this.desc, this.periode_awal, this.periode_akhir, this.total_pengeluaran_gaji, this.status',
    },
    onsuccess(response) {
      response.page = response.current_page
      response.hasNext = response.has_next
      return response
    }
  },
  columns: [{
    headerName: 'No',
    valueGetter: (params) => params.node.rowIndex + 1,
    width: 60,
    sortable: true,
    resizable: true,
    filter: true,
    cellClass: ['justify-center', 'bg-gray-50', 'border-r', '!border-gray-200']
  },
  {
    field: 'nomor',
    headerName: 'Nomor Generate',
    filter: true,
    wrapText: true,
    sortable: true,
    flex: 1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: ['border-r', '!border-gray-200', 'justify-start']
  },
  {
    field: 'desc',
    headerName: 'Deskripsi Pendek',
    filter: true,
    sortable: true,
    wrapText: true,
    flex: 1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: ['border-r', '!border-gray-200', 'justify-start']
  },
  {
    field: 'periode_awal',
    headerName: 'Periode Awal',
    filter: true,
    wrapText: true,
    sortable: true,
    flex: 1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: ['border-r', '!border-gray-200', 'justify-start']
  },
  {
    field: 'periode_akhir',
    headerName: 'Periode Akhir',
    filter: true,
    wrapText: true,
    sortable: true,
    flex: 1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: ['border-r', '!border-gray-200', 'justify-start']
  },
  {
    field: 'total_pengeluaran_gaji',
    headerName: 'Total Pengeluaran Gaji',
    filter: true,
    sortable: true,
    wrapText: true,
    flex: 1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: ['border-r', '!border-gray-200', 'justify-end'],
    cellRenderer: ({ value }) => {
      return formatRupiah(value)
    }
  },
  {
    field: 'status',
    headerName: 'Status',
    filter: true,
    wrapText: true,
    sortable: true,
    flex: 1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: ['border-r', '!border-gray-200', 'justify-center'],
    cellRenderer: ({ value }) => {
      return value === 'DRAFT'
        ? `<span class="text-gray-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">${value}</span>`
        : `<span class="text-green-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">${value}</span>`
    },
  },
  ]
})
onActivated(() => {
  //  reload table api landing
  if (apiTable.value) {
    if (route.query.reload) {
      apiTable.value.reload()
    }
  }
})

//  @endif -------------------------------------------------END
watchEffect(() => store.commit('set', ['isRequesting', isRequesting.value]))