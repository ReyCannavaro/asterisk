<?php

namespace App\Models\CustomModels;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Excel as ExcelType;
use PhpOffice\PhpSpreadsheet\IOFactory;

class m_kary extends \App\Models\BasicModels\m_kary
{
    private $helper;
    public function __construct()
    {
        parent::__construct();
        $this->helper = getCore("Helper");
    }

    public $fileColumns = [
        /*file_column*/
    ];

    public $createAdditionalData = ["creator_id" => "auth:id"];
    public $updateAdditionalData = ["last_editor_id" => "auth:id"];

    public function default_users() :\BelongsTo
    {
        return $this->belongsTo('App\Models\BasicModels\default_users', 'id', 'm_kary_id');
    }

    // public function t_cuti() :\BelongsTo
    // {
    //     return $this->belongsTo('App\Models\BasicModels\t_cuti', 'id', 'm_kary_id');
    // }
    public function t_cuti() {
        return $this->hasMany(t_cuti::class, 'm_kary_id', 'id');
    }


    public function createBefore($model, $arrayData, $metaData, $id = null)
    {
        $kode = @$arrayData['kode'];
        if (empty($kode) || DB::table('m_kary')->where('kode', $kode)->exists() || DB::table('default_users')->where('username', $kode)->exists()) {
            $kode = $this->helper->generateNomor("KODE KARYAWAN");
        }

        $newArrayData = array_merge($arrayData, [
            "kode"    => $kode,
            "comp_id" => auth()->user()->m_comp_id ?? 0,
        ]);
        return [
            "model" => $model,
            "data"  => $newArrayData,
            // "errors" => ['error1']
        ];
    }

    public function updateAfter( $model, $arrayData, $metaData, $id=null )
    {
        if(@$arrayData['m_dir_id']){
            default_users::where('m_kary_id', $id)->update(['m_dir_id' => $arrayData['m_dir_id']]);
        }
    }
    

    public function transformRowData(array $row)
    {
        $karyId = $row['id'] ?? 0;

        // Init object
        $object = [];

        /**
        * DETAIL REQUEST (extra data only when needed)
        */
        if (request('detail')) {
            $object['jadwal_kerja'] = \DB::table('t_jadwal_kerja as t')
                ->join('m_general as g', 'g.id', '=', 't.tipe_jam_kerja_id')
                ->where('t.tipe_jam_kerja_id', $row['tipe_jam_kerja_id'])
                ->where('t.status', 'POSTED')
                ->select('t.*')
                ->first();
        }

        /**
        * SINGLE FETCH untuk kartu & kontrak — ambil SEKALI SAJA
        */
        $detKartu = \DB::table('m_kary_det_kartu')
            ->where('m_kary_id', $karyId)
            ->select('ktp_no')
            ->first();

        $detKontrak = m_kary_det_kontrak::where('m_karyawan_id', $karyId)
            ->orderBy('id') // atau tgl_awal, sesuai logika data
            ->get(['tgl_awal', 'tgl_akhir', 'status']);

        $kontrakAktif = $detKontrak->firstWhere('status', true);
        $kontrakPertama = $detKontrak->first();


        /**
        * PERHITUNGAN SELISIH WAKTU (tanpa query tambahan)
        */
        $tglAwal = $kontrakPertama->tgl_awal ?? null;
        if ($tglAwal) {
            $start = Carbon::parse($tglAwal);
            $now = Carbon::now();

            $object['total_bulan'] = $start->diffInMonths($now);
            $object['total_tahun'] = $start->diffInYears($now);
        } else {
            $object['total_bulan'] = null;
            $object['total_tahun'] = null;
        }

        /**
        * ATTRIBUT TAMBAHAN
        */
        $object['is_atasan'] = m_kary::where('atasan_id', $karyId)->exists();
        $object['nomor_ktp'] = $detKartu->ktp_no ?? null;
        $object['tgl_awal_kontrak'] = $kontrakPertama->tgl_awal ?? null;
        $object['tgl_akhir_kontrak'] = $kontrakAktif->tgl_akhir ?? null;

        return array_merge($row, $object);
    }


    private function generateNik($compId, $dirId, $divisiId, $posisiId)
    {
        $currentDateTime = \Carbon\Carbon::now();;

        $year = $currentDateTime->format("Y");
        $month = $currentDateTime->format("m");
        $day = $currentDateTime->format("d");

        $lastInsertedId = m_kary::max("id");

        $newId = $lastInsertedId + 1;

        // Create a formatted nik
        $formattedNik = sprintf(
            "%s%s%s%s%s%04d",
            $year,
            $month,
            $day,
            $compId,
            $dirId,
            $newId
        );

        return $formattedNik;
    }



    public function custom_resetCuti($request)
    {
        try{
            \DB::beginTransaction();
            $employees = m_kary::where('is_active', true)->get();

            foreach ($employees as $employee) {
                $employmentStartDate = Carbon::parse($employee->tgl_masuk);  

                $yearsOfWork = $employmentStartDate->diffInYears(Carbon::now());

                $baseLeaveDays = 12;
                $additionalLeaveDays = [3, 5, 0, 3, 0, 0, 3, 0, 5];

                $employee->cuti_sisa_reguler = ($yearsOfWork >= 1) ? $baseLeaveDays + $additionalLeaveDays[($yearsOfWork - 1) % count($additionalLeaveDays)] : -4;

                $employee->cuti_sisa_panjang = 16;
                $employee->exp_date_cuti = Carbon::now()->addYear()->format('Y-m-d');

                $employee->save();
            }

            \DB::commit();
        } catch (\Exception $e) {
            return response()->json([
                "errors" => $e->getMessage(),
            ]);
        }
    }

    public function custom_postKaryawan($request)
    {
        try {
            \DB::beginTransaction();

            $idPelamar = $request->id;
            $status = $request->status;
            $data = t_pelamar::where("id", $idPelamar)->first();
            $dataBlacklist = m_blacklist::all();
            if($status === 'TOLAK'){
                $data->update([
                    "status" => "rejected",
                ]);

                return response()->json([
                    "message" => "Akun Ini Terblacklis",
                ]);
            }
            foreach ($dataBlacklist as $blacklist) {
                if ($blacklist->no_ktp === $data->ktp_no) {
                    $data->update([
                        "status" => "blacklist",
                    ]);

                    return response()->json([
                        "message" => "Akun Ini Terblacklis",
                    ]);
                }
            }


            $karyawan = m_kary::create([
                "ref_id" => $data["id"],
                "m_comp_id" => $data["m_comp_id"] ?? null,
                "m_dir_id" => $data["m_dir_id"] ?? null,
                "m_divisi_id" => $data["m_divisi_id"] ?? null,
                "m_dept_id" => $data["m_dept_id"] ?? null,
                "m_zona_id" => $data["m_zona_id"] ?? 0,
                "grading_id" => $data["grading_id"] ?? 0,
                "costcontre_id" => $data["costcontre_id"] ?? 0,
                "kode" => $this->helper->generateNomor("KODE KARYAWAN"),
                "m_posisi_id" => $data["m_posisi_id"] ?? null,
                "m_jam_kerja_id" => $data["m_jam_kerja_id"] ?? 0,
                "kode_presensi" => $data["kode_presensi"] ?? "",
                "nik" =>
                    $this->generateNik(
                        $data["m_comp_id"],
                        $data["m_dir_id"],
                        $data["m_divisi_id"],
                        $data["m_posisi_id"]
                    ) ?? null,
                "nama_depan" => $data["nama_depan"] ?? "",
                "nama_belakang" => $data["nama_belakang"] ?? "",
                "nama_lengkap" => $data["nama_pelamar"] ?? "",
                "nama_panggilan" => $data["nama_pelamar"] ?? "",
                "jk_id" => $data["jk_id"] ?? null,
                "tempat_lahir" => $data["tempat_lahir"] ?? null,
                "tgl_lahir" => $data["tgl_lahir"] ?? null,
                "provinsi_id" => $data["provinsi_id"] ?? 0,
                "kota_id" => $data["kota_id"] ?? 0,
                "kecamatan_id" => $data["kecamatan_id"] ?? 0,
                "kode_pos" => $data["kode_pos"] ?? 0,
                "alamat_asli" => $data["alamat_asli"] ?? "",
                "alamat_domisili" => $data["alamat_domisili"] ?? "",
                "no_tlp" => $data["telp"] ?? "",
                "no_tlp_lainnya" => $data["no_tlp_lainnya"] ?? "",
                "no_darurat" => $data["no_darurat"] ?? "",
                "nama_kontak_darurat" => $data["nama_kontak_darurat"] ?? "",
                "agama_id" => $data["agama_id"] ?? 0,
                "gol_darah_id" => $data["gol_darah_id"] ?? 0,
                "status_nikah_id" => $data["status_nikah_id"] ?? 0,
                "tanggungan_id" => $data["tanggungan_id"] ?? 0,
                "hub_dgn_karyawan" => $data["hub_dgn_karyawan"] ?? "",
                "cuti_jatah_reguler" => $data["cuti_jatah_reguler"] ?? 12,
                "cuti_sisa_reguler" => $data["cuti_sisa_reguler"] ?? 12,
                "cuti_panjang" => $data["cuti_panjang"] ?? 20,
                "cuti_sisa_panjang" => $data["cuti_sisa_panjang"] ?? 20,
                "status_kary_id" => $data["status_kary_id"] ?? null,
                "lama_kontrak_awal" => $data["lama_kontrak_awal"] ?? null,
                "lama_kontrak_akhir" => $data["lama_kontrak_akhir"] ?? null,
                "tgl_masuk" => $data["tgl_masuk"] ?? null,
                "tgl_berhenti" => $data["tgl_berhenti"] ?? null,
                "alasan_berhenti" => $data["alasan_berhenti"] ?? null,
                "uk_baju" => $data["uk_baju"] ?? "",
                "uk_celana" => $data["uk_celana"] ?? "",
                "uk_sepatu" => $data["uk_sepatu"] ?? "",
                "desc" => $data["desc"] ?? null,
                "is_active" => $data["is_active"] ?? true,
                "m_standart_gaji_id" => $data["m_standart_gaji_id"] ?? 0,
                "periode_gaji_id" => $data["periode_gaji_id"] ?? 0,
            ]);

            \DB::commit();

            return response()->json([
                "message" => "Registrasi Karyawan Berhasil",
            ]);
        } catch (\Exception $e) {
            \DB::rollBack();

            return response()->json([
                "errors" => $e->getMessage(),
            ]);
        }
    }

    /**
     * collection data diri karyawan 
     * for mobile profile
     */

    private function defaultDataDiri()
    {
        return 
        [
            "id"   => null,
            "m_comp_id"    => null,
            "m_dir_id" => null,
            "m_divisi_id"  => null,
            "m_dept_id"    => null,
            "m_zona_id"    => null,
            "grading_id"   => null,
            "costcontre_id"    => null,
            "kode" => null,
            "m_posisi_id"  => null,
            "m_jam_kerja_id"   => null,
            "kode_presensi"    => null,
            "nik"  => null,
            "nama_depan"   => null,
            "nama_belakang"    => null,
            "nama_lengkap" => null,
            "nama_panggilan"   => null,
            "jk_id"    => null,
            "tempat_lahir" => null,
            "tgl_lahir"    => null,
            "provinsi_id"  => null,
            "kota_id"  => null,
            "kecamatan_id" => null,
            "kode_pos" => null,
            "alamat_asli"  => null,
            "alamat_domisili"  => null,
            "no_tlp"   => null,
            "no_tlp_lainnya"   => null,
            "no_darurat"   => null,
            "nama_kontak_darurat"  => null,
            "agama_id" => null,
            "gol_darah_id" => null,
            "status_nikah_id"  => null,
            "tanggungan_id"    => null,
            "hub_dgn_karyawan" => null,
            "cuti_jatah_reguler"   => null,
            "cuti_sisa_reguler"    => null,
            "cuti_panjang" => null,
            "cuti_sisa_panjang"    => null,
            "status_kary_id"   => null,
            "lama_kontrak_awal"    => null,
            "lama_kontrak_akhir"   => null,
            "tgl_masuk"    => null,
            "tgl_berhenti" => null,
            "alasan_berhenti"  => null,
            "uk_baju"  => null,
            "uk_celana"    => null,
            "uk_sepatu"    => null,
            "desc" => null,
            "is_active"    => null,
            "creator_id"   => null,
            "last_editor_id"   => null,
            "created_at"   => null,
            "updated_at"   => null,
            "m_standart_gaji_id"   => null,
            "periode_gaji_id"  => null,
            "ref_id"   => null,
            "presensi_lokasi_default_id"   => null,
            "exp_date_cuti"    => null,
            "limit_potong" => null,
            "atasan_id"    => null,
            "cuti_p24" => null,
            "cuti_sisa_p24"    => null,
            "dir"  => null,
            "div"  => null,
            "dept" => null,
            "zona" => null,
            "grading"  => null,
            "posisi"   => null,
            "jam_kerja"    => null,
            "jk"   => null,
            "provinsi" => null,
            "kota" => null,
            "kecamatan"    => null,
            "agama"    => null,
            "gol_darah"    => null,
            "tanggungan"   => null,
            "costcontre"   => null,
            "status_nikah" => null,
            "ktp_no"   => null,
            "ktp_foto" => null,
            "pas_foto" => null,
            "kk_no"    => null,
            "kk_foto"  => null,
            "npwp_no"  => null,
            "npwp_foto"    => null,
            "npwp_tgl_berlaku" => null,
            "bpjs_tipe_id" => null,
            "bpjs_no"  => null,
            "bpjs_no_kesehatan"  => null,
            "bpjs_no_ketenagakerjaan"  => null,
            "bpjs_foto"    => null,
            "berkas_lain"  => null,
            "desc_file"    => null
        ];
    }

    public function custom_data_diri($req)
    {
        $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
        $data = [];
        $data = m_kary::selectRaw("
                m_kary.*,
                dir.nama dir,
                d.nama div,
                dp.nama dept,
                z.nama zona,
                g.value grading,
                z.nama zona,
                p.desc_kerja posisi,
                j.desc jam_kerja,
                jk.value jk,
                prov.value provinsi,
                kota.value kota,
                kec.value kecamatan,
                agama.value agama,
                gol_darah.value gol_darah,
                tanggungan.value tanggungan,
                costcontre.value costcontre,
                status_nikah.value status_nikah
            ")
            ->leftJoin('m_dir as dir','dir.id','m_kary.m_dir_id')
            ->leftJoin('m_divisi as d','d.id','m_kary.m_divisi_id')
            ->leftJoin('m_dept as dp','dp.id','m_kary.m_dept_id')
            ->leftJoin('m_zona as z','z.id','m_kary.m_zona_id')
            ->leftJoin('m_general as g','g.id','m_kary.grading_id')
            ->leftJoin('m_general as c','c.id','m_kary.costcontre_id')
            ->leftJoin('m_posisi as p','p.id','m_kary.m_posisi_id')
            ->leftJoin('m_jam_kerja as j','j.id','m_kary.m_jam_kerja_id')
            ->leftJoin('m_general as jk','jk.id','m_kary.jk_id')
            ->leftJoin('m_general as prov','prov.id','m_kary.provinsi_id')
            ->leftJoin('m_general as kota','kota.id','m_kary.kota_id')
            ->leftJoin('m_general as kec','kec.id','m_kary.kecamatan_id')
            ->leftJoin('m_general as agama','agama.id','m_kary.agama_id')
            ->leftJoin('m_general as gol_darah','gol_darah.id','m_kary.gol_darah_id')
            ->leftJoin('m_general as status_nikah','status_nikah.id','m_kary.status_nikah_id')
            ->leftJoin('m_general as tanggungan','tanggungan.id','m_kary.tanggungan_id')
            ->leftJoin('m_general as costcontre','costcontre.id','m_kary.costcontre_id')
            ->where('m_kary.id',$id_kary)->first();
        if(!$data){
            $data = $this->defaultDataDiri();
        }else{
            $det_kartu = m_kary_det_kartu::with(['bpjs_tipe'])->where('m_kary_id', @$id_kary ?? 0)->first();
            $det_pemb = m_kary_det_pemb::with(['periode_gaji', 'metode', 'tipe' , 'bank'])->where('m_kary_id', @$id_kary ?? 0)->first();
            if($det_kartu){
                $data['ktp_no'] = $det_kartu->ktp_no ?? null;
                $data['ktp_foto'] = $det_kartu->ktp_foto ?? null;
                $data['pas_foto'] = $det_kartu->pas_foto ?? null;
                $data['kk_no'] = $det_kartu->kk_no ?? null;
                $data['kk_foto'] = $det_kartu->kk_foto ?? null;
                $data['npwp_no'] = $det_kartu->npwp_no ?? null;
                $data['npwp_foto'] = $det_kartu->npwp_foto ?? null;
                $data['npwp_tgl_berlaku'] = $det_kartu->npwp_tgl_berlaku ?? null;
                $data['bpjs_tipe'] = $det_kartu->bpjs_tipe->value ?? null;
                $data['bpjs_tipe_id'] = $det_kartu->bpjs_tipe_id ?? null;
                $data['bpjs_no'] = $det_kartu->bpjs_no ?? null;
                $data['bpjs_no_kesehatan'] = $det_kartu->bpjs_no_kesehatan ?? null;
                $data['bpjs_no_ketenagakerjaan'] = $det_kartu->bpjs_no_ketenagakerjaan ?? null;
                $data['bpjs_foto'] = $det_kartu->bpjs_foto ?? null;
                $data['berkas_lain'] = $det_kartu->berkas_lain ?? null;
                $data['desc_file'] = $det_kartu->desc_file ?? null;
                $data['periode_gaji_id'] = $det_pemb->periode_gaji->id ?? null;
                $data['periode_gaji'] = $det_pemb->periode_gaji->value ?? null;
                $data['metode'] = $det_pemb->metode->value ?? null;
                $data['metode_id'] = $det_pemb->metode->id ?? null;
                $data['tipe'] = $det_pemb->tipe->value ?? null;
                $data['tipe_id'] = $det_pemb->tipe->id ?? null;
                $data['bank'] = $det_pemb->bank->value ?? null;
                $data['bank_id'] = $det_pemb->bank->id ?? null;
                $data['no_rek'] = $det_pemb->no_rek ?? null;
                $data['atas_nama_rek'] = $det_pemb->atas_nama_rek ?? null;
                
            }
        }
        return $this->helper->customResponse('OK', 200, $data);
    }

    private function uploadFile($file)
    {
        if ($file) {
            $fileName = md5(time()) . ":::" . $file->getClientOriginalName() . "." . $file->getClientOriginalExtension();
            $file->move(public_path("uploads/m_kary_det_kartu"), $fileName);
            return $fileName;
        }
        return null;
    }

    public function custom_data_diri_update($req)
    {
        try{
            \DB::beginTransaction();
            $id_kary = default_users::where('id',auth()->user()->id)->pluck('m_kary_id')->first();
            $kar = m_kary::where('id',$id_kary)->first();
            if(!$kar) {
                // buat karyawan jika tidak ditemukan kary
                $createHeader = $this->create([
                    "m_comp_id" => $req->m_comp_id,
                    "m_dir_id" => $req->m_dir_id,
                    "m_divisi_id" => $req->m_divisi_id,
                    "m_dept_id" => $req->m_dept_id,
                    "m_zona_id" => $req->m_zona_id,
                    "grading_id" => $req->grading_id ?? null,
                    "costcontre_id" => $req->costcontre_id,
                    "kode" => $req->kode ?? null,
                    "m_posisi_id" => $req->m_posisi_id,
                    "m_jam_kerja_id" => $req->m_jam_kerja_id,
                    "kode_presensi" => $req->kode_presensi ?? null,
                    "nik" => $req->nik,
                    "nama_depan" => $req->nama_depan,
                    "nama_belakang" => $req->nama_belakang,
                    "nama_lengkap" => $req->nama_lengkap,
                    "nama_panggilan" => $req->nama_panggilan,
                    "jk_id" => $req->jk_id,
                    "tempat_lahir" => $req->tempat_lahir,
                    "tgl_lahir" => $req->tgl_lahir,
                    "provinsi_id" => $req->provinsi_id,
                    "kota_id" => $req->kota_id,
                    "kecamatan_id" => $req->kecamatan_id,
                    "kode_pos" => $req->kode_pos,
                    "alamat_asli" => $req->alamat_asli,
                    "alamat_domisili" => $req->alamat_domisili,
                    "no_tlp" => $req->no_tlp,
                    "no_tlp_lainnya" => $req->no_tlp_lainnya,
                    "no_darurat" => $req->no_darurat,
                    "nama_kontak_darurat" => $req->nama_kontak_darurat,
                    "agama_id" => $req->agama_id,
                    "gol_darah_id" => $req->gol_darah_id,
                    "status_nikah_id" => $req->status_nikah_id,
                    "tanggungan_id" => $req->tanggungan_id,
                    "hub_dgn_karyawan" => $req->hub_dgn_karyawan,
                    "cuti_jatah_reguler" => $req->cuti_jatah_reguler,
                    "cuti_sisa_reguler" => $req->cuti_sisa_reguler,
                    "cuti_panjang" => $req->cuti_panjang,
                    "cuti_sisa_panjang" => $req->cuti_sisa_panjang,
                    "status_kary_id" => $req->status_kary_id ?? null,
                    "lama_kontrak_awal" => $req->lama_kontrak_awal ?? null,
                    "lama_kontrak_akhir" => $req->lama_kontrak_akhir ?? null,
                    "tgl_masuk" => $req->tgl_masuk,
                    "tgl_berhenti" => $req->tgl_berhenti ?? null,
                    "alasan_berhenti" => $req->alasan_berhenti ?? null,
                    "uk_baju" => $req->uk_baju,
                    "uk_celana" => $req->uk_celana,
                    "uk_sepatu" => $req->uk_sepatu,
                    "desc" => $req->desc ?? null
                ]);
                // update user -> isikan m_kary_id
                default_users::where('id',auth()->user()->id)->update(['m_kary_id'=>$createHeader->id]);
            }else{
                $createHeader = m_kary::where('id', $id_kary)->update([
                    "m_comp_id" => $req->m_comp_id ?? $kar->m_comp_id,
                    "m_dir_id" => $req->m_dir_id ?? $kar->m_dir_id,
                    "m_divisi_id" => $req->m_divisi_id ?? $kar->m_divisi_id,
                    "m_dept_id" => $req->m_dept_id ?? $kar->m_dept_id,
                    "m_zona_id" => $req->m_zona_id ?? $kar->m_zona_id,
                    "grading_id" => $req->grading_id ?? $kar->grading_id ?? null,
                    "costcontre_id" => $req->costcontre_id ?? $kar->costcontre_id,
                    "kode" => $req->kode ?? $kar->kode ?? null,
                    "m_posisi_id" => $req->m_posisi_id ?? $kar->m_posisi_id,
                    "m_jam_kerja_id" => $req->m_jam_kerja_id ?? $kar->m_jam_kerja_id,
                    "kode_presensi" => $req->kode_presensi ?? $kar->kode_presensi ?? null,
                    "nik" => $req->nik ?? $kar->nik,
                    "nama_depan" => $req->nama_depan ?? $kar->nama_depan,
                    "nama_belakang" => $req->nama_belakang ?? $kar->nama_belakang,
                    "nama_lengkap" => $req->nama_lengkap ?? $kar->nama_lengkap,
                    "nama_panggilan" => $req->nama_panggilan ?? $kar->nama_panggilan,
                    "jk_id" => $req->jk_id ?? $kar->jk_id,
                    "tempat_lahir" => $req->tempat_lahir ?? $kar->tempat_lahir,
                    "tgl_lahir" => $req->tgl_lahir ?? $kar->tgl_lahir,
                    "provinsi_id" => $req->provinsi_id ?? $kar->provinsi_id,
                    "kota_id" => $req->kota_id ?? $kar->kota_id,
                    "kecamatan_id" => $req->kecamatan_id ?? $kar->kecamatan_id,
                    "kode_pos" => $req->kode_pos ?? $kar->kode_pos,
                    "alamat_asli" => $req->alamat_asli ?? $kar->alamat_asli,
                    "alamat_domisili" => $req->alamat_domisili ?? $kar->alamat_domisili,
                    "no_tlp" => $req->no_tlp ?? $kar->no_tlp,
                    "no_tlp_lainnya" => $req->no_tlp_lainnya ?? $kar->no_tlp_lainnya,
                    "no_darurat" => $req->no_darurat ?? $kar->no_darurat,
                    "nama_kontak_darurat" => $req->nama_kontak_darurat ?? $kar->nama_kontak_darurat,
                    "agama_id" => $req->agama_id ?? $kar->agama_id,
                    "gol_darah_id" => $req->gol_darah_id ?? $kar->gol_darah_id,
                    "status_nikah_id" => $req->status_nikah_id ?? $kar->status_nikah_id,
                    "tanggungan_id" => $req->tanggungan_id ?? $kar->tanggungan_id,
                    "hub_dgn_karyawan" => $req->hub_dgn_karyawan ?? $kar->hub_dgn_karyawan,
                    "cuti_jatah_reguler" => $req->cuti_jatah_reguler ?? $kar->cuti_jatah_reguler,
                    "cuti_sisa_reguler" => $req->cuti_sisa_reguler ?? $kar->cuti_sisa_reguler,
                    "cuti_panjang" => $req->cuti_panjang ?? $kar->cuti_panjang,
                    "cuti_sisa_panjang" => $req->cuti_sisa_panjang ?? $kar->cuti_sisa_panjang,
                    "status_kary_id" => $req->status_kary_id ?? $kar->status_kary_id ?? null,
                    "lama_kontrak_awal" => $req->lama_kontrak_awal ?? $kar->lama_kontrak_awal ?? null,
                    "lama_kontrak_akhir" => $req->lama_kontrak_akhir ?? $kar->lama_kontrak_akhir ?? null,
                    "tgl_masuk" => $req->tgl_masuk ?? $kar->tgl_masuk,
                    "tgl_berhenti" => $req->tgl_berhenti ?? $kar->tgl_berhenti ?? null,
                    "alasan_berhenti" => $req->alasan_berhenti ?? $kar->alasan_berhenti ?? null,
                    "uk_baju" => $req->uk_baju ?? $kar->uk_baju,
                    "uk_celana" => $req->uk_celana ?? $kar->uk_celana,
                    "uk_sepatu" => $req->uk_sepatu ?? $kar->uk_sepatu,
                    "desc" => $req->desc ?? $kar->desc ?? null
                ]);
            }
            \DB::commit();

            
            if($createHeader){
                $check = m_kary_det_kartu::where('m_kary_id', $id_kary)->first();
                $check_pemb = m_kary_det_pemb::where('m_kary_id', $id_kary)->first();


                $file = $req->file('ktp_foto');
                $fileName_ktp = $this->uploadFile($file);
                // if(!$fileName_ktp) return $this->helper->customResponse('Foto KTP tidak valid, silahkan melakukan upload ulang file', 422);

                $file = $req->file('pas_foto');
                $fileName_pas = $this->uploadFile($file);
                // if(!$fileName_pas) return $this->helper->customResponse('Pas foto tidak valid, silahkan melakukan upload ulang file', 422);

                $file = $req->file('kk_foto');
                $fileName_kk = $this->uploadFile($file);
                // if(!$fileName_kk) return $this->helper->customResponse('Foto KK tidak valid, silahkan melakukan upload ulang file', 422);

                $file = $req->file('npwp_foto');
                $fileName_npwp = $this->uploadFile($file);
                // if(!$fileName_npwp) return $this->helper->customResponse('Foto NPWP tidak valid, silahkan melakukan upload ulang file', 422);

                $file = $req->file('bpjs_foto');
                $fileName_bpjs = $this->uploadFile($file);
                // if(!$fileName_bpjs) return $this->helper->customResponse('Foto BPJS tidak valid, silahkan melakukan upload ulang file', 422);

                $file = $req->file('berkas_lain');
                $fileName_berkas = $this->uploadFile($file);
                // if(!$fileName_berkas) return $this->helper->customResponse('Upload berkas lain tidak valid, silahkan melakukan upload ulang file', 422);
                \DB::beginTransaction();
                if($check){

                    \DB::table('m_kary_det_kartu')
                        ->where('m_kary_id', $id_kary)
                        ->update([
                        "m_kary_id" => $id_kary,
                        "ktp_no" => $req->ktp_no ?? @$check->ktp_no,
                        "ktp_foto" => $fileName_ktp ?? @$check->ktp_foto,
                        "pas_foto" => $fileName_pas ?? @$check->pas_foto,
                        "kk_no" => $req->kk_no ?? @$check->kk_no,
                        "kk_foto" => $fileName_kk ?? @$check->kk_foto,
                        "npwp_no" => $req->npwp_no ?? @$check->npwp_no,
                        "npwp_foto" => $fileName_npwp ?? @$check->npwp_foto,
                        "npwp_tgl_berlaku" => $req->npwp_tgl_berlaku ?? @$check->npwp_tgl_berlaku,
                        "bpjs_tipe_id" => $req->bpjs_tipe_id ?? @$check->bpjs_tipe_id,
                        "bpjs_no" => $req->bpjs_no ?? @$check->bpjs_no,
                        "bpjs_no_kesehatan" => $req->bpjs_no_kesehatan ?? @$check->bpjs_no_kesehatan,
                        "bpjs_no_ketenagakerjaan" => $req->bpjs_no_ketenagakerjaan ?? @$check->bpjs_no_ketenagakerjaan,
                        "bpjs_foto" => $fileName_bpjs ?? @$check->bpjs_foto,
                        "berkas_lain" => $fileName_berkas ?? @$check->berkas_lain,
                        "desc_file" => $req->desc_file ?? @$check->desc_file,
                    ]);           
                }else{
                        \DB::table('m_kary_det_kartu')->insert([
                            "m_kary_id" => $id_kary,
                            "ktp_no" => @$req->ktp_no,
                            "ktp_foto" => @$fileName_ktp,
                            "pas_foto" => @$fileName_pas,
                            "kk_no" => @$req->kk_no,
                            "kk_foto" => @$fileName_kk,
                            "npwp_no" => @$req->npwp_no,
                            "npwp_foto" => @$fileName_npwp,
                            "npwp_tgl_berlaku" => @$req->npwp_tgl_berlaku,
                            "bpjs_tipe_id" => @$req->bpjs_tipe_id,
                            "bpjs_no" => @$req->bpjs_no,
                            "bpjs_no_kesehatan" => @$req->bpjs_no_kesehatan,
                            "bpjs_no_ketenagakerjaan" => @$req->bpjs_no_ketenagakerjaan ,
                            "bpjs_foto" => @$fileName_bpjs,
                            "berkas_lain" => @$fileName_berkas,
                            "desc_file" => @$req->desc_file
                        ]);
                }
                \DB::commit();

                \DB::beginTransaction();
                if($check_pemb){
                    \DB::table('m_kary_det_pemb')
                        ->where('m_kary_id', $id_kary)
                        ->update([
                            'bank_id' => @$req->bank_id ?? @$check_pemb->bank_id,
                            'no_rek' => @$req->no_rek ?? @$check_pemb->no_rek,
                            'atas_nama_rek' => @$req->atas_nama_rek ?? @$check_pemb->atas_nama_rek
                    ]);
                }else{
                    \DB::table('m_kary_det_pemb')
                        ->insert([
                            'm_kary_id' => $id_kary,
                            'm_comp_id' => @$req->m_comp_id,
                            'm_dir_id' => @$req->m_dir_id,
                            'periode_gaji_id' => @$req->periode_gaji_id ?? 362,
                            'metode_id' => @$req->metode_id ?? 0,
                            'tipe_id' => @$req->tipe_id ?? 956,
                            'bank_id' => @$req->bank_id ?? 0,
                            'no_rek' => @$req->no_rek ?? 0,
                            'atas_nama_rek' => @$req->atas_nama_rek ?? 0,
                            'desc' => @$req->desc
                    ]);
    
                }       
                \DB::commit();
            }
           
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }
        return $this->helper->customResponse('Data diri berhasil diupdate');
    }

    /**
     * collection data pendidikan karyawan 
     * for mobile profile
     */

    public function custom_pendidikan($req)
    {
        $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
        $tbl = 'm_kary_det_pend';
        $data = m_kary_det_pend::query()
            ->selectRaw("
                k.nama_lengkap karyawan,
                tingkat.value as tingkat,
                kota.value as kota,
                $tbl.*
            ")
            ->leftJoin('m_general as tingkat','tingkat.id',"$tbl.tingkat_id")
            ->leftJoin('m_general as kota','kota.id',"$tbl.kota_id")
            ->join('m_kary as k','k.id',"$tbl.m_kary_id")
            ->orderBy("$tbl.created_at", 'desc')
            ->where("$tbl.m_kary_id",$id_kary)->get();
        return $this->helper->customResponse('OK', 200, $data);
    }

    public function custom_pendidikan_create($req)
    {
        \DB::beginTransaction();
        $fileName = null;

        if ($req->hasFile("ijazah_foto")) {
            $file = $req->file("ijazah_foto");
            $fileName =
                md5(time()) .
                ":::" .
                $file->getClientOriginalName().
                "." .
                $file->getClientOriginalExtension();
            $file->move(public_path("uploads/m_kary_det_pend"), $fileName);
        } 

        try{
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            \DB::table('m_kary_det_pend')->insert([
                'm_kary_id' => $id_kary,
                'tingkat_id' => $req->tingkat_id,
                'nama_sekolah' => $req->nama_sekolah,
                'thn_masuk' => $req->thn_masuk,
                'thn_lulus' => $req->thn_lulus,
                'kota_id' => $req->kota_id,
                'nilai' => $req->nilai,
                'jurusan' => $req->jurusan,
                'is_pend_terakhir' => $req->is_pend_terakhir,
                'ijazah_no' => $req->ijazah_no,
                'ijazah_foto' => $fileName,
                'desc' => $req->desc,
                'creator_id' => auth()->user()->id,
                'created_at' => date('Y-m-d H:i:s')
            ]);

            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pendidikan berhasil ditambahkan');
    }

    public function custom_pendidikan_update($req)
    {
        \DB::beginTransaction();
        $id = $req->id;
        try {
            $pendidikan = \DB::table('m_kary_det_pend')->find($id);

            if (!$pendidikan) {
                return $this->helper->customResponse('Data pendidikan tidak ditemukan', 404);
            }

            $fileName = $pendidikan->ijazah_foto;

            if ($req->hasFile("ijazah_foto")) {
                $oldFilePath = public_path("uploads/m_kary_det_pend/{$fileName}");
                if ($fileName && file_exists($oldFilePath)) {
                    unlink($oldFilePath);
                }

                $file = $req->file("ijazah_foto");
                $fileName =
                    md5(time()) .
                    ":::" .
                    $file->getClientOriginalName() .
                    "." .
                    $file->getClientOriginalExtension();
                $file->move(public_path("uploads/m_kary_det_pend"), $fileName);
            } else {
                $fileName = $pendidikan->ijazah_foto;
            }

            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            \DB::table('m_kary_det_pend')->where('id', $id)->update([
                'm_kary_id' => $id_kary,
                'tingkat_id' => $req->tingkat_id ?? $pendidikan->tingkat_id,
                'nama_sekolah' => $req->nama_sekolah ?? $pendidikan->nama_sekolah,
                'thn_masuk' => $req->thn_masuk ?? $pendidikan->thn_masuk,
                'thn_lulus' => $req->thn_lulus ?? $pendidikan->thn_lulus,
                'kota_id' => $req->kota_id ?? $pendidikan->kota_id,
                'nilai' => $req->nilai ?? $pendidikan->nilai,
                'jurusan' => $req->jurusan ?? $pendidikan->jurusan,
                'is_pend_terakhir' => $req->is_pend_terakhir ?? $pendidikan->is_pend_terakhir,
                'ijazah_no' => $req->ijazah_no ?? $pendidikan->ijazah_no,
                'ijazah_foto' => $fileName,
                'desc' => $req->desc ?? $pendidikan->desc,
                'creator_id' => auth()->user()->id,
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pendidikan berhasil diperbarui');
    }


    public function custom_pendidikan_delete($req)
    {
        \DB::beginTransaction();
        try{
            m_kary_det_pend::find($req->id)->delete();
            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pendidikan berhasil dihapus');
    }

    public function custom_keluarga($req)
    {
        try {
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            
            $data = m_kary_det_kel::where('m_kary_id', $id_kary)
            ->select(
                'm_kary_det_kel.*', 
                'keluarga.value AS keluarga', 
                'pend_terakhir.value AS pendidikan', 
                'jk.value AS jenis_kelamin', 
                'pekerjaan.value AS pekerjaan'
            )
            ->leftJoin('m_general AS keluarga', 'm_kary_det_kel.keluarga_id', '=', 'keluarga.id')
            ->leftJoin('m_general AS pend_terakhir', 'm_kary_det_kel.pend_terakhir_id', '=', 'pend_terakhir.id')
            ->leftJoin('m_general AS jk', 'm_kary_det_kel.jk_id', '=', 'jk.id')
            ->leftJoin('m_general AS pekerjaan', 'm_kary_det_kel.pekerjaan_id', '=', 'pekerjaan.id')
            ->orderBy('m_kary_det_kel.created_at', 'desc')
            ->get();

            return $this->helper->customResponse('OK', 200, $data);
        } catch (\Exception $e) {
            return $this->helper->responseCatch($e);
        }
    }

    public function custom_keluarga_create($req)
    {
        try{
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            \DB::table('m_kary_det_kel')->insert([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->m_comp_id ?? null,
                'm_dir_id' => $req->m_dir_id ?? null,
                'keluarga_id' => $req->keluarga_id,
                'nama' => $req->nama,
                'pend_terakhir_id' => $req->pend_terakhir_id,
                'jk_id' => $req->jk_id,
                'pekerjaan_id' => $req->pekerjaan_id,
                'usia' => $req->usia,
                'desc' => $req->desc,
                'creator_id' => auth()->user()->id,
                'last_editor_id' => auth()->user()->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data keluarga berhasil ditambahkan');
    }

    public function custom_keluarga_update($req)
    {
        \DB::beginTransaction();
        $id = $req->id;
        try {
            $keluarga = \DB::table('m_kary_det_kel')->find($id);

            if (!$keluarga) {
                return $this->helper->customResponse('Data keluarga tidak ditemukan', 404);
            }

            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;

            \DB::table('m_kary_det_kel')->where('id', $id)->update([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->input('m_comp_id', $keluarga->m_comp_id),
                'm_dir_id' => $req->input('m_dir_id', $keluarga->m_dir_id),
                'keluarga_id' => $req->input('keluarga_id', $keluarga->keluarga_id),
                'nama' => $req->input('nama', $keluarga->nama),
                'pend_terakhir_id' => $req->input('pend_terakhir_id', $keluarga->pend_terakhir_id),
                'jk_id' => $req->input('jk_id', $keluarga->jk_id),
                'pekerjaan_id' => $req->input('pekerjaan_id', $keluarga->pekerjaan_id),
                'usia' => $req->input('usia', $keluarga->usia),
                'desc' => $req->input('desc', $keluarga->desc),
                'last_editor_id' => auth()->user()->id,
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data keluarga berhasil diperbarui');
    }


    public function custom_keluarga_delete($req)
    {
        \DB::beginTransaction();
        try{

            m_kary_det_kel::find($req->id)->delete();
            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data keluarga berhasil dihapus');
    }

    public function custom_pelatihan($req)
    {
        try {
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            
            $data = m_kary_det_pel::where('m_kary_id', $id_kary)
            ->select(
                'm_kary_det_pel.*', 
                'kota.value AS kota'
            )
            ->leftJoin('m_general AS kota', 'm_kary_det_pel.kota_id', '=', 'kota.id')
            ->orderBy('m_kary_det_pel.created_at', 'desc')
            ->get();

            return $this->helper->customResponse('OK', 200, $data);
        } catch (\Exception $e) {
            return $this->helper->responseCatch($e);
        }
    }

    public function custom_pelatihan_create($req)
    {
        try{
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            \DB::table('m_kary_det_pel')->insert([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->m_comp_id ?? null,
                'm_dir_id' => $req->m_dir_id ?? null,
                'nama_pel' => $req->nama_pel,
                'tahun' => $req->tahun,
                'nama_lem' => $req->nama_lem,
                'kota_id' => $req->kota_id ?? null,
                'creator_id' => auth()->user()->id,
                'last_editor_id' => auth()->user()->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pelatihan berhasil ditambahkan');
    }

    public function custom_pelatihan_update($req)
    {
        \DB::beginTransaction();
        $id = $req->id;
        try {
            $pelatihan = \DB::table('m_kary_det_pel')->find($id);

            if (!$pelatihan) {
                return $this->helper->customResponse('Data pelatihan tidak ditemukan', 404);
            }

            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;

            \DB::table('m_kary_det_pel')->where('id', $id)->update([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->input('m_comp_id', $pelatihan->m_comp_id),
                'm_dir_id' => $req->input('m_dir_id', $pelatihan->m_dir_id),
                'nama_pel' => $req->input('nama_pel', $pelatihan->nama_pel),
                'tahun' => $req->input('tahun', $pelatihan->tahun),
                'nama_lem' => $req->input('nama_lem', $pelatihan->nama_lem),
                'kota_id' => $req->input('kota_id', $pelatihan->kota_id),
                'last_editor_id' => auth()->user()->id,
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pelatihan berhasil diperbarui');
    }


    public function custom_pelatihan_delete($req)
    {
        \DB::beginTransaction();
        try{

            m_kary_det_pel::find($req->id)->delete();
            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data keluarga berhasil dihapus');
    }

    public function custom_prestasi($req)
    {
        try {
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            
            $data = m_kary_det_pres::where('m_kary_id', $id_kary)
            ->select(
                'm_kary_det_pres.*', 
                'tingkat.value AS tingkat_prestasi'
            )
            ->leftJoin('m_general AS tingkat', 'm_kary_det_pres.tingkat_pres_id', '=', 'tingkat.id')
            ->orderBy('m_kary_det_pres.created_at', 'desc')
            ->get();

            return $this->helper->customResponse('OK', 200, $data);
        } catch (\Exception $e) {
            return $this->helper->responseCatch($e);
        }
    }

    public function custom_prestasi_create($req)
    {
        try{
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            \DB::table('m_kary_det_pres')->insert([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->m_comp_id ?? null,
                'm_dir_id' => $req->m_dir_id ?? null,
                'nama_pres' => $req->nama_pres,
                'tahun' => $req->tahun,
                'tingkat_pres_id' => $req->tingkat_pres_id,
                'desc' => $req->desc,
                'creator_id' => auth()->user()->id,
                'last_editor_id' => auth()->user()->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data prestasi berhasil ditambahkan');
    }

    public function custom_prestasi_update($req)
    {
        \DB::beginTransaction();
        $id = $req->id;
        try {
            $prestasi = \DB::table('m_kary_det_pres')->find($id);

            if (!$prestasi) {
                return $this->helper->customResponse('Data prestasi tidak ditemukan', 404);
            }

            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;

            \DB::table('m_kary_det_pres')->where('id', $id)->update([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->input('m_comp_id', $prestasi->m_comp_id),
                'm_dir_id' => $req->input('m_dir_id', $prestasi->m_dir_id),
                'nama_pres' => $req->input('nama_pres', $prestasi->nama_pres),
                'tahun' => $req->input('tahun', $prestasi->tahun),
                'tingkat_pres_id' => $req->input('tingkat_pres_id', $prestasi->tingkat_pres_id),
                'desc' => $req->input('desc', $prestasi->desc),
                'last_editor_id' => auth()->user()->id,
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data prestasi berhasil diperbarui');
    }


    public function custom_prestasi_delete($req)
    {
        \DB::beginTransaction();
        try{

            m_kary_det_pres::find($req->id)->delete();
            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data prestasi berhasil dihapus');
    }

    public function custom_organisasi($req)
    {
        try {
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            
            $data = m_kary_det_org::where('m_kary_id', $id_kary)
            ->select(
                'm_kary_det_org.*', 
                'jenis.value AS jenis_organisasi',
                'kota.value AS kota',
            )
            ->leftJoin('m_general AS jenis', 'm_kary_det_org.jenis_org_id', '=', 'jenis.id')
            ->leftJoin('m_general AS kota', 'm_kary_det_org.kota_id', '=', 'kota.id')
            ->orderBy('m_kary_det_org.created_at', 'desc')
            ->get();

            return $this->helper->customResponse('OK', 200, $data);
        } catch (\Exception $e) {
            return $this->helper->responseCatch($e);
        }
    }

    public function custom_organisasi_create($req)
    {
        try{
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            \DB::table('m_kary_det_org')->insert([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->m_comp_id ?? null,
                'm_dir_id' => $req->m_dir_id ?? null,
                'nama' => $req->nama,
                'tahun' => $req->tahun,
                'jenis_org_id' => $req->jenis_org_id,
                'kota_id' => $req->kota_id,
                'posisi' => $req->posisi,
                'desc' => $req->desc,
                'creator_id' => auth()->user()->id,
                'last_editor_id' => auth()->user()->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data organisasi berhasil ditambahkan');
    }

    public function custom_organisasi_update($req)
    {
        \DB::beginTransaction();
        $id = $req->id;
        try {
            $organisasi = \DB::table('m_kary_det_org')->find($id);

            if (!$organisasi) {
                return $this->helper->customResponse('Data organisasi tidak ditemukan', 404);
            }

            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;

            \DB::table('m_kary_det_org')->where('id', $id)->update([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->input('m_comp_id', $organisasi->m_comp_id),
                'm_dir_id' => $req->input('m_dir_id', $organisasi->m_dir_id),
                'nama' => $req->input('nama', $organisasi->nama),
                'tahun' => $req->input('tahun', $organisasi->tahun),
                'jenis_org_id' => $req->input('jenis_org_id', $organisasi->jenis_org_id),
                'kota_id' => $req->input('kota_id', $organisasi->kota_id),
                'posisi' => $req->input('posisi', $organisasi->posisi),
                'desc' => $req->input('desc', $organisasi->desc),
                'last_editor_id' => auth()->user()->id,
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data organisasi berhasil diperbarui');
    }


    public function custom_organisasi_delete($req)
    {
        \DB::beginTransaction();
        try{

            m_kary_det_org::find($req->id)->delete();
            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data organisasi berhasil dihapus');
    }

    public function custom_bahasa($req)
    {
        try {
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            
            $data = m_kary_det_bhs::where('m_kary_id', $id_kary)
            ->orderBy('created_at', 'desc')
            ->get();

            return $this->helper->customResponse('OK', 200, $data);
        } catch (\Exception $e) {
            return $this->helper->responseCatch($e);
        }
    }

    public function custom_bahasa_create($req)
    {
        try{
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            \DB::table('m_kary_det_bhs')->insert([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->m_comp_id ?? null,
                'm_dir_id' => $req->m_dir_id ?? null,
                'bhs_dikuasai' => $req->bhs_dikuasai,
                'nilai_lisan' => $req->nilai_lisan,
                'nilai_tertulis' => $req->nilai_tertulis,
                'level_lisan' => $req->level_lisan,
                'level_tertulis' => $req->level_tertulis,
                'desc' => $req->desc,
                'creator_id' => auth()->user()->id,
                'last_editor_id' => auth()->user()->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data bahasa berhasil ditambahkan');
    }

    public function custom_bahasa_update($req)
    {
        \DB::beginTransaction();
        $id = $req->id;
        try {
            $bahasa = \DB::table('m_kary_det_bhs')->find($id);

            if (!$bahasa) {
                return $this->helper->customResponse('Data bahasa tidak ditemukan', 404);
            }

            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;

            \DB::table('m_kary_det_bhs')->where('id', $id)->update([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->input('m_comp_id', $bahasa->m_comp_id),
                'm_dir_id' => $req->input('m_dir_id', $bahasa->m_dir_id),
                'bhs_dikuasai' => $req->input('bhs_dikuasai', $bahasa->bhs_dikuasai),
                'nilai_lisan' => $req->input('nilai_lisan', $bahasa->nilai_lisan),
                'nilai_tertulis' => $req->input('nilai_tertulis', $bahasa->nilai_tertulis),
                'level_lisan' => $req->input('level_lisan', $bahasa->level_lisan),
                'level_tertulis' => $req->input('level_tertulis', $bahasa->level_tertulis),
                'desc' => $req->input('desc', $bahasa->desc),
                'last_editor_id' => auth()->user()->id,
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data bahasa berhasil diperbarui');
    }


    public function custom_bahasa_delete($req)
    {
        \DB::beginTransaction();
        try{

            m_kary_det_bhs::find($req->id)->delete();
            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data bahasa berhasil dihapus');
    }

    public function custom_pk($req)
    {
        try {
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;
            
            $data = m_kary_det_pk::where('m_kary_id', $id_kary)
            ->select(
                'm_kary_det_pk.*', 
                'kota.value AS kota',
            )
            ->leftJoin('m_general AS kota', 'm_kary_det_pk.kota_id', '=', 'kota.id')
            ->orderBy('m_kary_det_pk.created_at', 'desc')
            ->get();

            return $this->helper->customResponse('OK', 200, $data);
        } catch (\Exception $e) {
            return $this->helper->responseCatch($e);
        }
    }

    public function custom_pk_create($req)
    {
        try{
            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;

            $file = $req->file('surat_referensi');
            $fileName_berkas = $this->uploadFile($file);

            \DB::table('m_kary_det_pk')->insert([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->m_comp_id ?? null,
                'm_dir_id' => $req->m_dir_id ?? null,
                'instansi' => $req->instansi,
                'bidang_usaha' => $req->bidang_usaha,
                'no_tlp' => $req->no_tlp,
                'posisi' => $req->posisi,
                'thn_masuk' => $req->thn_masuk,
                'thn_keluar' => $req->thn_keluar,
                'alamat_kantor' => $req->alamat_kantor,
                'kota_id' => $req->kota_id,
                'surat_referensi' => $fileName_berkas,
                'creator_id' => auth()->user()->id,
                'last_editor_id' => auth()->user()->id,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pengalaman kerja berhasil ditambahkan');
    }

    public function custom_pk_update($req)
    {
        \DB::beginTransaction();
        $id = $req->id;
        try {
            $pengalaman_kerja = \DB::table('m_kary_det_pk')->find($id);

            if (!$pengalaman_kerja) {
                return $this->helper->customResponse('Data pengalaman kerja tidak ditemukan', 404);
            }

            $id_kary = default_users::find(auth()->user()->id)->m_kary_id;

            $file = $req->file('surat_referensi');
            $fileName_berkas = $pengalaman_kerja->surat_referensi;

            if ($file) {
                $oldFilePath = public_path("uploads/m_kary_det_pk/{$fileName_berkas}");
                if ($fileName_berkas&& file_exists($oldFilePath)) {
                    unlink($oldFilePath);
                }
                $fileName_berkas = $this->uploadFile($file);
            }else{
                $fileName_berkas = $pengalaman_kerja->surat_referensi;
            }

            \DB::table('m_kary_det_pk')->where('id', $id)->update([
                'm_kary_id' => $id_kary,
                'm_comp_id' => $req->input('m_comp_id', $pengalaman_kerja->m_comp_id),
                'm_dir_id' => $req->input('m_dir_id', $pengalaman_kerja->m_dir_id),
                'instansi' => $req->input('instansi', $pengalaman_kerja->instansi),
                'bidang_usaha' => $req->input('bidang_usaha', $pengalaman_kerja->bidang_usaha),
                'no_tlp' => $req->input('no_tlp', $pengalaman_kerja->no_tlp),
                'posisi' => $req->input('posisi', $pengalaman_kerja->posisi),
                'thn_masuk' => $req->input('thn_masuk', $pengalaman_kerja->thn_masuk),
                'thn_keluar' => $req->input('thn_keluar', $pengalaman_kerja->thn_keluar),
                'alamat_kantor' => $req->input('alamat_kantor', $pengalaman_kerja->alamat_kantor),
                'kota_id' => $req->input('kota_id', $pengalaman_kerja->kota_id),
                'surat_referensi' => $fileName_berkas,
                'last_editor_id' => auth()->user()->id,
                'updated_at' => Carbon::now(),
            ]);

            \DB::commit();
        } catch (\Exception $e) {
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pengalaman kerja berhasil diperbarui');
    }


    public function custom_pk_delete($req)
    {
        \DB::beginTransaction();
        try{

            m_kary_det_pk::find($req->id)->delete();
            \DB::commit();
        }catch(\Exception $e){
            \DB::rollback();
            return $this->helper->responseCatch($e);
        }

        return $this->helper->customResponse('Data pengalaman kerja berhasil dihapus');
    }

    public function custom_delete_kary($req)
    {
        \DB::beginTransaction();

        try {
            $kary = m_kary::find($req->id);

            if ($kary) {
                m_kary_det_kontrak::where('m_karyawan_id', $kary->id)->delete();
                $kary->delete();
            } else {
                return $this->helper->customResponse('Data karyawan tidak ditemukan', 404);
            }

            \DB::commit();
            return $this->helper->customResponse('Data berhasil dihapus');
        } catch (\Exception $e) {
            \DB::rollBack();
            return $this->helper->responseCatch($e);
        }
    }


    public function scopeKaryawanOffice($model)
    {
        return $model->join('m_general','m_general.id','m_kary.tipe_jam_kerja_id')
            ->whereRaw("lower(m_general.code) = 'office'");
    }

    public function scopeKaryawanShift($model)
    {
        return $model->join('m_general','m_general.id','m_kary.tipe_jam_kerja_id')
            ->whereRaw("lower(m_general.code) != 'office'")
            ->orWhere('m_kary.tipe_jam_kerja_id',null);
    }

    public function scopeNotInGenerate($model)
    {
        $t_jadwal_kerja_id = app()->request->t_jadwal_kerja_id;

        return $model
        ->whereRaw("
            m_kary.id not in(select d.m_kary_id from t_jadwal_kerja_det d 
            join t_jadwal_kerja t on t.id = d.t_jadwal_kerja_id where t.status = 'POSTED')
            or m_kary.id in(select d.m_kary_id from t_jadwal_kerja_det d 
            join t_jadwal_kerja t on t.id = d.t_jadwal_kerja_id where t.id = ?)
        ", [$t_jadwal_kerja_id ?? 0]);
    }

    public function scopeHUT($model)
    {
        $model->whereRaw("to_char(m_kary.tgl_lahir, 'mm') = to_char(CURRENT_DATE + INTERVAL '1 day', 'mm')");
    }

    public function public_importKary($req)
    {
        try{
           if ($req->hasFile('csv')) {
            $file = $req->file('csv');

            $ext = strtolower($file->getClientOriginalExtension());
            if (!in_array($ext, ['csv'])) {
                return response()->json(['error' => 'File harus berformat CSV'], 422);
            }

            $path = $file->getRealPath();
            $data = array_map('str_getcsv', file($path));

            $header = array_map('trim', $data[0]); 
            $header[0] = str_replace("\xEF\xBB\xBF", '', $header[0]); 
            $header = array_map(function($key) {
                return preg_replace('/[\x{FEFF}]/u', '', $key);
            }, $header);
            unset($data[0]);

            DB::beginTransaction();
            foreach ($data as $row) {
                $row = array_map('trim', $row);
                if (count($header) !== count($row)) {
                    if (count($row) < count($header)) {
                        $row = array_pad($row, count($header), '');
                    } 
                    else {
                        $row = array_slice($row, 0, count($header));
                    }
                }
                $rowData = array_combine($header, $row);

                if (empty($rowData['ID'])) {
                    continue;
                }

                $validator = Validator::make($rowData, [
                    'ID' => 'required',
                    'NAMA' => 'required',
                    'JABATAN' => 'required',
                    'UNIT' => 'required',
                    'TGL_MASUK' => 'required',
                    'STATUS_KARYAWAN' => 'required',
                    'STATUS_KERJA' => 'required',
                    'NO_REK' => 'required',
                    'NO_IJAZAH' => 'required',
                    'TGL_LAHIR' => 'required',
                    'ALAMAT' => 'required',
                    'KOTA' => 'required',
                    'TELP' => 'nullable'
                ]);

                if ($validator->fails()) {
                    DB::rollBack();
                    return response()->json([
                        'error' => 'Data tidak valid di baris: ' . json_encode($rowData),
                        'detail' => $validator->errors(),
                    ], 422);
                }

                $status_kerja = m_general::where('group', 'TIPE KARYAWAN')->where('key', $rowData['STATUS_KERJA'])?->first()?->id ?? 0;
                // dd($rowData);

                $status_nikah = m_general::where('group', 'TANGGUNGAN')->where('value', $rowData['STATUS_KARYAWAN'])?->first()?->id ?? 0;
                $unit = m_dir::where('nama', $rowData['UNIT'])?->first()?->id ?? 0;
                //$jabatan = m_divisi::where('nama', $rowData['JABATAN'])?->first()?->id ?? 0;
                $jabatan = m_divisi::firstOrCreate(
                    ['nama' => $rowData['JABATAN']], 
                    [
                        'status' => true,
                        'desc'=> $rowData['JABATAN']
                    ]
                )->id;
                $kota = m_general::where('group', 'KOTA')->whereRaw("LOWER(TRIM(REPLACE(REPLACE(value, 'Kota ', ''), 'Kabupaten ', ''))) = ?", [strtolower($rowData['KOTA'])])->first() ?? null;
                $presensi_lokasi = presensi_lokasi::where('nama', $rowData['UNIT'])?->first()?->id ?? 0;

                $m_kary_data = [
                    'kode' => $rowData['ID'],
                    'nama_lengkap' => $rowData['NAMA'],
                    'nama_depan' => $rowData['NAMA'],
                    'nama_belakang' => $rowData['NAMA'],
                    'nama_panggilan' => $rowData['NAMA'],
                    'tgl_lahir' => $rowData['TGL_LAHIR'],
                    'periode_gaji_id' => 362,
                    'alamat_domisili' => $rowData['ALAMAT'],
                    'alamat_asli' => $rowData['ALAMAT'],
                    'no_tlp' => $rowData['TELP'],
                    'm_dir_id' => $unit,
                    'm_divisi_id' => $jabatan,
                    'tipe_karyawan_id' => $status_kerja,
                    'tanggungan_id' => $status_nikah,
                    'kota_id' => $kota?->id ?? 0,
                    'provinsi_id' => $kota?->key ?? 0,
                    'presensi_lokasi_default_id' => $presensi_lokasi,
                    't_jadwal_kerja_id' => 37, //hardcode sementara ke office
                    'tipe_jam_kerja_id' => 990 //hardcode sementara ke office
                ];

                $m_kary = m_kary::updateOrCreate(
                    ['kode' => $rowData['ID']], 
                    $m_kary_data               
                );

                m_kary_det_kartu::updateOrCreate(
                    ['m_kary_id' => $m_kary->id],
                    ['desc_file' => $rowData['NO_IJAZAH']]
                );

                m_kary_det_pemb::updateOrCreate(
                    ['m_kary_id' => $m_kary->id],
                    [
                        'no_rek' => $rowData['NO_REK'] ?? 0,
                        'periode_gaji_id' => m_general::where('group', 'PERIODE GAJI')->where('value', 'BULANAN')->first()?->id ?? 0,
                    ]
                );
                // dd($rowData['TGL_AKHIR']);
                m_kary_det_kontrak::updateOrCreate(
                    ['m_karyawan_id' => $m_kary->id],
                    [
                        'm_divisi_id' => $jabatan,
                        'm_dir_id' => $unit,
                        'tipe_karyawan_id' => $status_kerja,
                        'status' => true,
                        'tgl_awal' => $rowData['TGL_MASUK'],
                        'tgl_akhir' => $rowData['TGL_AKHIR'] != "" ? $rowData['TGL_AKHIR'] : null,
                    ]
                );

            }

            DB::commit();
             return response()->json(['success' => 'Import berhasil'], 200);
        }

        }catch (\Exception $e) {
            return response()->json(['error' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
        }
    }

    public function hitungDurasi()
    {
        $object = [];
        $detKontrak = m_kary_det_kontrak::where('m_karyawan_id', $this->id)
            ->orderBy('tgl_awal', 'asc')
            ->orderBy('id', 'asc')
            ->get(['tgl_awal', 'tgl_akhir', 'status']);

        $kontrakAktif = $detKontrak->firstWhere('status', true);
        $kontrakPertama = $detKontrak->first();

        $tglAwal = $this->tgl_masuk ?: ($kontrakPertama->tgl_awal ?? null);
        if ($tglAwal) {
            $start = Carbon::parse($tglAwal);
            $now = Carbon::now();

            $object['total_bulan'] = $start->diffInMonths($now);
            $object['total_tahun'] = $start->diffInYears($now);
            $object['tgl_akhir'] = $kontrakAktif?->tgl_akhir ?? ($detKontrak->last()?->tgl_akhir ?? '-');
        } else {
            $object['total_bulan'] = null;
            $object['total_tahun'] = null;
            $object['tgl_akhir'] = null;
        }

        return $object;

    }

    public function public_exportKary()
    {
        try {
            $req = app()->request;
            $m_dir_id = $req->m_dir_id ?? null;
            $fileName = 'data_karyawan_' . Carbon::now()->format('Ymd_His') . '.xlsx';
            // dd($m_dir_id);
            // Ambil data yang relevan dengan kolom yang diimport
            $data = m_kary::with(['m_divisi', 'm_dir', 'm_kary_det_kartu', 'm_kary_det_pemb', 'm_kary_det_kontrak', 'kota', 'm_standart_gaji'])
                ->when($m_dir_id, function ($query) use ($m_dir_id) {
                    $query->where('m_dir_id', $m_dir_id);
                })
                ->where('is_active', true)
                ->get()
               ->map(function ($kary) {
                
                     $format = function ($date) {
                        if (!$date || $date === '-' || $date === '0000-00-00') {
                            return '';
                        }

                        try {
                            return \Carbon\Carbon::parse($date)->format('d-m-Y');
                        } catch (\Exception $e) {
                            return '';
                        }
                    };

                    $gaji = $kary->m_standart_gaji?->gaji_pokok ?? 0;

                    $durasi = $kary->hitungDurasi();
                    $tglAkhir = data_get($durasi, 'tgl_akhir');
                    $tglMasuk = $kary->tgl_masuk ?: optional($kary->m_kary_det_kontrak?->sortBy('tgl_awal')->first())->tgl_awal;

                    return [
                        'ID' => $kary->kode ?? '',
                        'NAMA' => $kary->nama_lengkap ?? '',
                        'GAJI' => number_format($gaji, 2, ',', '.'),
                        'JABATAN' => $kary->m_divisi?->nama ?? '',
                        'UNIT' => $kary->m_dir?->nama ?? '',
                        'TGL_MASUK' => $format($tglMasuk),
                        'STATUS_TANGGUNGAN' => m_general::find($kary->tanggungan_id)?->value ?? '',
                        'STATUS_KERJA' => m_general::find($kary->tipe_karyawan_id)?->key ?? '',
                        'BULAN' => (string) $durasi['total_bulan'],
                        'TAHUN' => (string) $durasi['total_tahun'],

                        // BARIS INI YANG SUDAH DIBENARKAN
                        'TGL_AKHIR' => $tglAkhir ? $format($tglAkhir) : '',

                        'NO_REK' => $kary->m_kary_det_pemb->first()?->no_rek ?? '',
                        'NO_IJAZAH' => $kary->m_kary_det_kartu->first()?->desc_file ?? '',
                        'TGL_LAHIR' => $format($kary->tgl_lahir),
                        'ALAMAT' => $kary->alamat_domisili ?? '',
                        'KOTA' => $kary->kota?->value ?? '',
                        'TELP' => $kary->no_tlp ?? '',
                    ];
                });


            // Buat export dinamis langsung tanpa class
            $export = new class($data) implements FromCollection, WithHeadings {
                protected $data;
                public function __construct($data) { $this->data = $data; }
                public function collection() { return $this->data; }
                public function headings(): array
                {
                    return [
                        'ID', 'NAMA', 'GAJI', 'JABATAN', 'UNIT', 'TGL_MASUK',
                        'STATUS_KARYAWAN', 'STATUS_KERJA', 'BULAN', 'TAHUN', 'TGL_AKHIR','NO_REK', 'NO_IJAZAH',
                        'TGL_LAHIR', 'ALAMAT', 'KOTA', 'TELP'
                    ];
                }
            };

            return Excel::download($export, $fileName, ExcelType::XLSX);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Terjadi kesalahan saat export: ' . $e->getMessage(),
            ], 500);
        }
    }

    // public function public_importKaryGaji($req)
    // {
    //     DB::beginTransaction();

    //     try {
    //         if (!$req->hasFile('csv')) {
    //             return response()->json(['error' => 'File tidak ditemukan'], 422);
    //         }

    //         $file = $req->file('csv');
    //         $ext = strtolower($file->getClientOriginalExtension());

    //         if (!in_array($ext, ['csv'])) {
    //             return response()->json(['error' => 'File harus berformat CSV'], 422);
    //         }

    //         $data = array_map('str_getcsv', file($file->getRealPath()));

    //         if (count($data) < 2) {
    //             return response()->json(['error' => 'File CSV tidak memiliki data'], 422);
    //         }

    //         $header = array_map('trim', $data[0]);
    //         unset($data[0]);

    //         $header[0] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $header[0]);

    //         //dd($data);

    //         foreach ($data as $rowIndex => $row) {
    //             if (count($row) !== count($header)) {
    //                 DB::rollBack();
    //                 return response()->json([
    //                     'error' => "Jumlah kolom tidak sesuai di baris ke-" . ($rowIndex),
    //                 ], 422);
    //             }

    //             $row = array_map('trim', $row);
    //             $rowData = array_combine($header, $row);

    //             $validator = Validator::make($rowData, [
    //                 'ID' => 'required',
    //                 'NAMA' => 'required',
    //                 'GAJI' => 'required',
    //             ]);

    //             if ($validator->fails()) {
    //                 DB::rollBack();
    //                 return response()->json([
    //                     'error' => 'Data tidak valid di baris: ' . ($rowIndex),
    //                     'detail' => $validator->errors(),
    //                 ], 422);
    //             }

    //             // Ambil angka dari teks GAJI
    //             $gaji = (int) preg_replace('/[^0-9]/', '', $rowData['GAJI 2025']);
    //             if ($gaji <= 0) continue;

    //             // Cek atau buat data standar gaji
    //             $standartGaji = m_standart_gaji::firstOrCreate(
    //                 ['gaji_pokok' => $gaji],
    //                 [
    //                     'kode' => $this->helper->generateNomor('KODE STANDART GAJI'),
    //                     'is_active' => true,
    //                     'desc' => $gaji . ' - GAJI IMPORT EXCEL',
    //                     'gaji_pokok_periode' => 'Bulanan',
    //                     'created_at' => Carbon::now(),
    //                     'updated_at' => Carbon::now(),
    //                 ]
    //             );

    //             if ($standartGaji->wasRecentlyCreated) {
    //                 m_standart_gaji_det::create([
    //                     'm_standart_gaji_id' => $standartGaji->id,
    //                     'komponen' => 'TERLAMBAT 15',
    //                     'faktor' => '-',
    //                     'nilai' => 5000,
    //                     'periode' => 'Harian',
    //                     'tipe_komponen' => 'NOMINAL',
    //                     'created_at' => Carbon::now(),
    //                     'updated_at' => Carbon::now(),
    //                 ]);

    //                 m_standart_gaji_det::create([
    //                     'm_standart_gaji_id' => $standartGaji->id,
    //                     'komponen' => 'TERLAMBAT 30',
    //                     'faktor' => '-',
    //                     'nilai' => 10000,
    //                     'periode' => 'Harian',
    //                     'tipe_komponen' => 'NOMINAL',
    //                     'created_at' => Carbon::now(),
    //                     'updated_at' => Carbon::now(),
    //                 ]);

    //                 m_standart_gaji_det::create([
    //                     'm_standart_gaji_id' => $standartGaji->id,
    //                     'komponen' => 'TERLAMBAT 45',
    //                     'faktor' => '-',
    //                     'nilai' => 15000,
    //                     'periode' => 'Harian',
    //                     'tipe_komponen' => 'NOMINAL',
    //                     'created_at' => Carbon::now(),
    //                     'updated_at' => Carbon::now(),
    //                 ]);

    //                 m_standart_gaji_det::create([
    //                     'm_standart_gaji_id' => $standartGaji->id,
    //                     'komponen' => 'TERLAMBAT 60',
    //                     'faktor' => '-',
    //                     'nilai' => 25000,
    //                     'periode' => 'Harian',
    //                     'tipe_komponen' => 'NOMINAL',
    //                     'created_at' => Carbon::now(),
    //                     'updated_at' => Carbon::now(),
    //                 ]);

    //                  m_standart_gaji_det::create([
    //                     'm_standart_gaji_id' => $standartGaji->id,
    //                     'komponen' => 'TERLAMBAT 61',
    //                     'faktor' => '-',
    //                     'nilai' => 100000,
    //                     'periode' => 'Harian',
    //                     'tipe_komponen' => 'NOMINAL',
    //                     'created_at' => Carbon::now(),
    //                     'updated_at' => Carbon::now(),
    //                 ]);
    //             }

    //             // Update karyawan berdasarkan kode ID
    //             m_kary::where('kode', $rowData['ID'])
    //                 ->update([
    //                     'm_standart_gaji_id' => $standartGaji->id,
    //                     'updated_at' => Carbon::now(),
    //                 ]);
    //         }

    //         DB::commit();

    //         return response()->json([
    //             'message' => 'Import selesai. Gaji unik berhasil disimpan dan karyawan dimapping.',
    //         ]);

    //     } catch (\Throwable $e) {
    //         DB::rollBack();
    //         return response()->json([
    //             'error' => 'Terjadi kesalahan: ' . $e->getMessage(),
    //         ], 500);
    //     }
    // }

    public function public_importKaryGaji($req)
    {
        DB::beginTransaction();

        try {
            // 1. Validasi keberadaan file
            if (!$req->hasFile('csv')) {
                return response()->json(['error' => 'File tidak ditemukan'], 422);
            }

            $file = $req->file('csv');
            $ext = strtolower($file->getClientOriginalExtension());

            // 2. Cek ekstensi (Mendukung CSV dan Excel)
            if (!in_array($ext, ['csv', 'xls', 'xlsx'])) {
                return response()->json(['error' => 'File harus berformat CSV, XLS, atau XLSX'], 422);
            }

            // 3. Load file menggunakan PhpSpreadsheet
            $spreadsheet = IOFactory::load($file->getRealPath());
            $sheet = $spreadsheet->getActiveSheet();
            $data = $sheet->toArray(); // Konversi sheet menjadi array PHP

            if (count($data) < 2) {
                return response()->json(['error' => 'File tidak memiliki data'], 422);
            }

            // 4. Ambil header dan bersihkan karakter aneh/BOM
            $header = array_map('trim', $data[0]);
            unset($data[0]);
            $header[0] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $header[0]);

            // 5. Looping data
            foreach ($data as $rowIndex => $row) {
                // Lewati jika baris kosong (sering terjadi di file Excel)
                if (empty(array_filter($row))) continue;

                if (count($row) !== count($header)) {
                    DB::rollBack();
                    return response()->json([
                        'error' => "Jumlah kolom tidak sesuai di baris ke-" . ($rowIndex + 1),
                    ], 422);
                }

                $row = array_map('trim', $row);
                $rowData = array_combine($header, $row);

                // Validasi field (sesuai kode asli Anda)
                $validator = Validator::make($rowData, [
                    'ID' => 'required',
                    'NAMA' => 'required',
                    'GAJI' => 'required',
                ]);

                if ($validator->fails()) {
                    DB::rollBack();
                    return response()->json([
                        'error' => 'Data tidak valid di baris: ' . ($rowIndex + 1),
                        'detail' => $validator->errors(),
                    ], 422);
                }

                // Ambil angka dari teks GAJI (menggunakan key GAJI 2025 sesuai kode asli)
                $gaji = (int) preg_replace('/[^0-9]/', '', $rowData['GAJI']);
                if ($gaji <= 0) continue;

                // Cek atau buat data standar gaji
                $standartGaji = m_standart_gaji::firstOrCreate(
                    ['gaji_pokok' => $gaji],
                    [
                        'kode' => $this->helper->generateNomor('KODE STANDART GAJI'),
                        'is_active' => true,
                        'desc' => $gaji . ' - GAJI IMPORT EXCEL',
                        'gaji_pokok_periode' => 'Bulanan',
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]
                );

                // Jika record baru dibuat, buatkan detail potongannya
                if ($standartGaji->wasRecentlyCreated) {
                    m_standart_gaji_det::create([
                        'm_standart_gaji_id' => $standartGaji->id,
                        'komponen' => 'TERLAMBAT 15',
                        'faktor' => '-',
                        'nilai' => 5000,
                        'periode' => 'Harian',
                        'tipe_komponen' => 'NOMINAL',
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]);

                    m_standart_gaji_det::create([
                        'm_standart_gaji_id' => $standartGaji->id,
                        'komponen' => 'TERLAMBAT 30',
                        'faktor' => '-',
                        'nilai' => 10000,
                        'periode' => 'Harian',
                        'tipe_komponen' => 'NOMINAL',
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]);

                    m_standart_gaji_det::create([
                        'm_standart_gaji_id' => $standartGaji->id,
                        'komponen' => 'TERLAMBAT 45',
                        'faktor' => '-',
                        'nilai' => 15000,
                        'periode' => 'Harian',
                        'tipe_komponen' => 'NOMINAL',
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]);

                    m_standart_gaji_det::create([
                        'm_standart_gaji_id' => $standartGaji->id,
                        'komponen' => 'TERLAMBAT 60',
                        'faktor' => '-',
                        'nilai' => 25000,
                        'periode' => 'Harian',
                        'tipe_komponen' => 'NOMINAL',
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]);

                    m_standart_gaji_det::create([
                        'm_standart_gaji_id' => $standartGaji->id,
                        'komponen' => 'TERLAMBAT 61',
                        'faktor' => '-',
                        'nilai' => 100000,
                        'periode' => 'Harian',
                        'tipe_komponen' => 'NOMINAL',
                        'created_at' => Carbon::now(),
                        'updated_at' => Carbon::now(),
                    ]);
                }

                // Update karyawan berdasarkan kode ID
                m_kary::where('kode', $rowData['ID'])
                    ->update([
                        'm_standart_gaji_id' => $standartGaji->id,
                        'updated_at' => Carbon::now(),
                    ]);
            }

            DB::commit();

            return response()->json([
                'message' => 'Import selesai. Gaji unik berhasil disimpan dan karyawan dimapping.',
            ]);

        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json([
                'error' => 'Terjadi kesalahan: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function public_updateKontrak()
    {
        $this->updateKontrak();
    }

    public function updateKontrak()
    {
        $today = \Carbon\Carbon::today();

        $id_seleksi = m_general::where('group', 'TIPE KARYAWAN')->where('key', 'S')->first()?->id ??0;
        $id_training = m_general::where('group', 'TIPE KARYAWAN')->where('key', 'TR')->first()?->id ??0;
        $id_kontrak = m_general::where('group', 'TIPE KARYAWAN')->where('key', 'K')->first()?->id ??0;

        $seleksi = m_kary_det_kontrak::where('tipe_karyawan_id', $id_seleksi)
            ->where('status', true)
            ->whereDate('tgl_awal', '<=', $today->copy()->subDays(7))
            ->get();

        foreach ($seleksi as $item) {
            $item->update(['status' => false]);

            $tgl_awal_baru = \Carbon\Carbon::parse($item->tgl_akhir)->addDay();
            $tgl_akhir_baru = $tgl_awal_baru->copy()->addMonths(3);

            m_kary_det_kontrak::create([
                'nomor'           => $this->helper->generateNomor("KODE KONTRAK"),
                'm_karyawan_id'   => $item->m_karyawan_id,
                'm_divisi_id'     => $item->m_divisi_id,
                'm_dir_id'        => $item->m_dir_id,
                'tipe_karyawan_id'=> $id_training,
                'status'          => true,
                'tgl_awal'        => $tgl_awal_baru,
                'duration'        => 3,
                'tgl_akhir'       => $tgl_akhir_baru,
                'created_at'      => Carbon::now(),
                'updated_at'      => Carbon::now(),
            ]);

            m_kary::where('id', $item->m_karyawan_id)->update([
                'm_divisi_id'     => $item->m_divisi_id,
                'm_dir_id'        => $item->m_dir_id,
                'tipe_karyawan_id'=> $id_training,
            ]);

            \Log::info("Auto insert: Seleksi → Training untuk karyawan ID {$item->m_karyawan_id}");
        }

        // $training = m_kary_det_kontrak::where('tipe_karyawan_id', $id_training)
        //     ->where('status', true)
        //     ->whereDate('tgl_akhir', '<=', $today)
        //     ->get();

        // foreach ($training as $item) {
        //     $item->update(['status' => false]);

        //     m_kary_det_kontrak::create([
        //         'm_karyawan_id'   => $item->m_karyawan_id,
        //         'm_divisi_id'     => $item->m_divisi_id,
        //         'm_dir_id'        => $item->m_dir_id,
        //         'tipe_karyawan_id'=> $id_kontrak,
        //         'status'          => true,
        //         'tgl_awal'        => $today,
        //         'duration'        => 6,
        //         'tgl_akhir'       => $today->copy()->addMonths(6),
        //         'created_at'      => now(),
        //         'updated_at'      => now(),
        //     ]);

        //     \Log::info("Auto insert: Training → Kontrak untuk karyawan ID {$item->m_karyawan_id}");
        // }

    }

    public function custom_countEnd($req)
    {  
        if(isset($req->tgl_awal) && isset($req->duration)){
            if($req->duration == 7){
                $tgl_akhir = Carbon::parse($req->tgl_awal)->addDays(7);
            }else{
                $tgl_akhir = Carbon::parse($req->tgl_awal)->addMonths($req->duration);
            }
            return response()->json([
                'tgl_akhir' => $tgl_akhir->format('d/m/Y'),
            ]);
        }else{
            return response()->json([
                'tgl_akhir' => null,
            ]);
        }
        
    }

    public function scopelanding($model)
    {
        try {
            \DB::statement("
                UPDATE m_kary
                SET is_active = false,
                    tgl_berhenti = COALESCE(t_resign.date, m_kary.tgl_berhenti, CURRENT_DATE),
                    alasan_berhenti = COALESCE(t_resign.keterangan, m_kary.alasan_berhenti, 'Pengunduran Diri')
                FROM t_resign
                WHERE t_resign.m_kary_id = m_kary.id
                  AND t_resign.status = 'POSTED'
                  AND m_kary.is_active = true
            ");

            \DB::statement("
                UPDATE m_kary_det_kontrak
                SET status = false
                FROM t_resign
                WHERE t_resign.m_kary_id = m_kary_det_kontrak.m_karyawan_id
                  AND t_resign.status = 'POSTED'
                  AND m_kary_det_kontrak.status = true
            ");

            \DB::statement("
                UPDATE default_users
                SET is_active = false
                FROM t_resign
                WHERE t_resign.m_kary_id = default_users.m_kary_id
                  AND t_resign.status = 'POSTED'
                  AND default_users.is_active = true
            ");
        } catch (\Throwable $e) {
        }

        return $model->select('m_kary.id', 'm_kary.kode','m_kary.nama_lengkap', 'm_kary.nama_depan', 'tipe_karyawan.value as tipe_karyawan.value' ,'tipe_karyawan.value as tipe_karyawan_value', 'm_dir.nama as m_dir.nama', 'm_divisi.nama as m_divisi.nama', 'm_kary.is_active');
    }

    public function custom_getTipeKaryawan()
    {
        $result = m_general::where('group', 'TIPE KARYAWAN')->select('id', 'key', 'value')->get();
        return $result;
    }

    public function custom_laporan_history_karyawan($req)
    {
        try {
            $start = null;
            $end = null;
            $filterDate = false;

            if ($req->tipe_periode === 'Rentang Tanggal' && $req->date_start && $req->date_end) {
                $start = Carbon::parse($req->date_start)->format('Y-m-d');
                $end = Carbon::parse($req->date_end)->format('Y-m-d');
                $filterDate = true;
            } elseif ($req->tipe_periode === 'Bulan' && ($req->month || $req->periode)) {
                $month = $req->month ?? $req->periode;
                $start = Carbon::parse($month . '-01')->startOfMonth()->format('Y-m-d');
                $end = Carbon::parse($month . '-01')->endOfMonth()->format('Y-m-d');
                $filterDate = true;
            }

            $kategori = $req->kategori ?? 'Semua';

            // 1. Base Query Karyawan
            $karyQuery = DB::table('m_kary as k')
                ->leftJoin('m_dir as d', 'k.m_dir_id', '=', 'd.id')
                ->leftJoin('m_divisi as div', 'k.m_divisi_id', '=', 'div.id')
                ->select(
                    'k.id',
                    'k.kode as nik',
                    'k.nama_lengkap as nama',
                    'd.nama as unit_sekarang',
                    'div.nama as jabatan_sekarang',
                    'k.tgl_masuk',
                    'k.tgl_berhenti',
                    'k.is_active'
                );

            if ($req->m_dir_id) $karyQuery->where('k.m_dir_id', $req->m_dir_id);
            if ($req->m_divisi_id) $karyQuery->where('k.m_divisi_id', $req->m_divisi_id);
            if ($req->m_kary_id) {
                if (is_array($req->m_kary_id)) {
                    $karyQuery->whereIn('k.id', $req->m_kary_id);
                } elseif (strpos($req->m_kary_id, ',') !== false) {
                    $karyQuery->whereIn('k.id', explode(',', $req->m_kary_id));
                } else {
                    $karyQuery->where('k.id', $req->m_kary_id);
                }
            }
            if ($req->is_active !== null && $req->is_active !== '' && $req->is_active !== 'Semua') {
                $isActive = filter_var($req->is_active, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($isActive !== null) {
                    $karyQuery->where('k.is_active', $isActive ? 'true' : 'false');
                }
            }

            $karyawanList = $karyQuery->get()->keyBy('id');
            $karyawanIds = $karyawanList->keys()->toArray();

            if (empty($karyawanIds)) {
                return $this->helper->customResponse('OK', 200, []);
            }

            $historyList = [];

            // A. Riwayat Mutasi Unit, Jabatan & Kontrak (m_kary_det_kontrak & t_extend_kontrak)
            if ($kategori === 'Semua' || $kategori === 'Mutasi & Kontrak') {
                // Dari m_kary_det_kontrak
                $kontrakQ = DB::table('m_kary_det_kontrak as kdk')
                    ->leftJoin('m_dir as d', 'kdk.m_dir_id', '=', 'd.id')
                    ->leftJoin('m_divisi as div', 'kdk.m_divisi_id', '=', 'div.id')
                    ->leftJoin('m_general as gen', 'kdk.tipe_karyawan_id', '=', 'gen.id')
                    ->whereIn('kdk.m_karyawan_id', $karyawanIds)
                    ->select(
                        'kdk.m_karyawan_id',
                        'kdk.tgl_awal',
                        'kdk.tgl_akhir',
                        'kdk.duration',
                        'kdk.status',
                        'd.nama as unit',
                        'div.nama as jabatan',
                        'gen.value as tipe_karyawan'
                    );

                if ($filterDate) {
                    $kontrakQ->where(function($q) use ($start, $end) {
                        $q->whereBetween('kdk.tgl_awal', [$start, $end])
                          ->orWhereBetween('kdk.tgl_akhir', [$start, $end]);
                    });
                }
                $kontrakData = $kontrakQ->get();

                foreach ($kontrakData as $kd) {
                    $kary = $karyawanList[$kd->m_karyawan_id] ?? null;
                    if (!$kary) continue;

                    $tglAwal = $kd->tgl_awal ? Carbon::parse($kd->tgl_awal)->format('d-m-Y') : '-';
                    $tglAkhir = $kd->tgl_akhir ? Carbon::parse($kd->tgl_akhir)->format('d-m-Y') : '-';

                    $historyList[] = [
                        'tanggal_sort' => $kd->tgl_awal ?? '1970-01-01',
                        'nik' => $kary->nik ?? '-',
                        'nama' => $kary->nama ?? '-',
                        'kategori' => 'Mutasi & Kontrak',
                        'unit' => $kd->unit ?? $kary->unit_sekarang ?? '-',
                        'jabatan' => $kd->jabatan ?? $kary->jabatan_sekarang ?? '-',
                        'tanggal' => "{$tglAwal} s/d {$tglAkhir}",
                        'deskripsi' => "Kontrak / Penempatan {$kd->tipe_karyawan} ({$kd->duration} Bulan)",
                        'keterangan_detail' => "Unit: " . ($kd->unit ?? '-') . " | Jabatan: " . ($kd->jabatan ?? '-'),
                        'status' => $kd->status ? 'Aktif' : 'Selesai'
                    ];
                }

                // Dari t_extend_kontrak
                $extendQ = DB::table('t_extend_kontrak as tek')
                    ->leftJoin('m_dir as d', 'tek.m_dir_id', '=', 'd.id')
                    ->leftJoin('m_divisi as div', 'tek.m_divisi_id', '=', 'div.id')
                    ->leftJoin('m_general as gen', 'tek.tipe_karyawan_id', '=', 'gen.id')
                    ->whereIn('tek.m_karyawan_id', $karyawanIds)
                    ->select(
                        'tek.m_karyawan_id',
                        'tek.nomor',
                        'tek.tgl_awal',
                        'tek.tgl_akhir',
                        'tek.duration',
                        'tek.status',
                        'tek.catatan',
                        'd.nama as unit',
                        'div.nama as jabatan',
                        'gen.value as tipe_karyawan'
                    );

                if ($filterDate) {
                    $extendQ->where(function($q) use ($start, $end) {
                        $q->whereBetween('tek.tgl_awal', [$start, $end])
                          ->orWhereBetween('tek.tgl_akhir', [$start, $end]);
                    });
                }
                $extendData = $extendQ->get();

                foreach ($extendData as $ed) {
                    $kary = $karyawanList[$ed->m_karyawan_id] ?? null;
                    if (!$kary) continue;

                    $tglAwal = $ed->tgl_awal ? Carbon::parse($ed->tgl_awal)->format('d-m-Y') : '-';
                    $tglAkhir = $ed->tgl_akhir ? Carbon::parse($ed->tgl_akhir)->format('d-m-Y') : '-';

                    $historyList[] = [
                        'tanggal_sort' => $ed->tgl_awal ?? '1970-01-01',
                        'nik' => $kary->nik ?? '-',
                        'nama' => $kary->nama ?? '-',
                        'kategori' => 'Mutasi & Kontrak',
                        'unit' => $ed->unit ?? $kary->unit_sekarang ?? '-',
                        'jabatan' => $ed->jabatan ?? $kary->jabatan_sekarang ?? '-',
                        'tanggal' => "{$tglAwal} s/d {$tglAkhir}",
                        'deskripsi' => "Perpanjangan Kontrak: " . ($ed->nomor ?? '-') . " ({$ed->duration} Bulan)",
                        'keterangan_detail' => ($ed->catatan ? $ed->catatan . " | " : "") . "Tipe: " . ($ed->tipe_karyawan ?? '-'),
                        'status' => $ed->status ?? 'APPROVED'
                    ];
                }
            }

            // B. Riwayat Gaji & Penggajian (t_final_gaji_det)
            if ($kategori === 'Semua' || $kategori === 'Riwayat Gaji') {
                $gajiQ = DB::table('t_final_gaji_det as fgd')
                    ->leftJoin('t_final_gaji as fg', 'fgd.t_final_gaji_id', '=', 'fg.id')
                    ->whereIn('fgd.m_kary_id', $karyawanIds)
                    ->select(
                        'fgd.m_kary_id',
                        'fgd.periode',
                        'fgd.periode_in_date',
                        'fg.periode_awal',
                        'fg.periode_akhir',
                        'fg.status as status_gaji',
                        'fgd.status as status_gaji_det',
                        'fgd.netto',
                        'fgd.total_gaji',
                        'fgd.total_tax'
                    );

                if ($filterDate) {
                    $gajiQ->where(function($q) use ($start, $end) {
                        $q->whereBetween('fgd.periode_in_date', [$start, $end])
                          ->orWhere(function($sub) use ($start, $end) {
                              $sub->whereNotNull('fgd.periode')
                                  ->whereBetween('fgd.periode', [$start, $end]);
                          })
                          ->orWhereBetween('fg.periode_awal', [$start, $end])
                          ->orWhereBetween('fg.periode_akhir', [$start, $end]);
                    });
                }
                $gajiData = $gajiQ->orderBy('fgd.periode_in_date', 'desc')->get();

                foreach ($gajiData as $gd) {
                    $kary = $karyawanList[$gd->m_kary_id] ?? null;
                    if (!$kary) continue;

                    $sortDate = $gd->periode_in_date ?? $gd->periode_awal ?? ($gd->periode ? $gd->periode . '-01' : '1970-01-01');
                    $periodeLabel = '-';
                    if ($gd->periode_in_date) {
                        $periodeLabel = Carbon::parse($gd->periode_in_date)->translatedFormat('F Y');
                    } elseif ($gd->periode) {
                        $periodeLabel = is_numeric(substr($gd->periode, 0, 4)) ? Carbon::parse($gd->periode . '-01')->translatedFormat('F Y') : $gd->periode;
                    } elseif ($gd->periode_awal) {
                        $periodeLabel = Carbon::parse($gd->periode_awal)->format('d-m-Y') . ' s/d ' . Carbon::parse($gd->periode_akhir)->format('d-m-Y');
                    }

                    $nettoFormatted = number_format($gd->netto ?? 0, 0, ',', '.');
                    $brutoFormatted = number_format($gd->total_gaji ?? 0, 0, ',', '.');
                    $taxFormatted = number_format($gd->total_tax ?? 0, 0, ',', '.');

                    $historyList[] = [
                        'tanggal_sort' => $sortDate,
                        'nik' => $kary->nik ?? '-',
                        'nama' => $kary->nama ?? '-',
                        'kategori' => 'Riwayat Gaji',
                        'unit' => $kary->unit_sekarang ?? '-',
                        'jabatan' => $kary->jabatan_sekarang ?? '-',
                        'tanggal' => $periodeLabel,
                        'deskripsi' => "Penggajian / Payroll Periode " . $periodeLabel,
                        'keterangan_detail' => "Bruto: Rp {$brutoFormatted} | PPh: Rp {$taxFormatted} | Netto (THP): Rp {$nettoFormatted}",
                        'status' => $gd->status_gaji ?? $gd->status_gaji_det ?? 'POSTED'
                    ];
                }
            }

            // C. Riwayat Surat Peringatan / Sanksi / Penghargaan (t_surat)
            if ($kategori === 'Semua' || $kategori === 'Surat & Disiplin') {
                $suratQ = DB::table('t_surat as s')
                    ->whereIn('s.m_karyawan_id', $karyawanIds)
                    ->select(
                        's.m_karyawan_id',
                        's.jenis_surat',
                        's.level_surat',
                        's.tanggal_terbit',
                        's.alasan',
                        's.is_signed'
                    );

                if ($filterDate) {
                    $suratQ->whereBetween('s.tanggal_terbit', [$start, $end]);
                }
                $suratData = $suratQ->get();

                foreach ($suratData as $sd) {
                    $kary = $karyawanList[$sd->m_karyawan_id] ?? null;
                    if (!$kary) continue;

                    $tglTerbit = $sd->tanggal_terbit ? Carbon::parse($sd->tanggal_terbit)->format('d-m-Y') : '-';

                    $historyList[] = [
                        'tanggal_sort' => $sd->tanggal_terbit ?? '1970-01-01',
                        'nik' => $kary->nik ?? '-',
                        'nama' => $kary->nama ?? '-',
                        'kategori' => 'Surat & Disiplin',
                        'unit' => $kary->unit_sekarang ?? '-',
                        'jabatan' => $kary->jabatan_sekarang ?? '-',
                        'tanggal' => $tglTerbit,
                        'deskripsi' => "Surat: {$sd->jenis_surat} " . ($sd->level_surat ? "({$sd->level_surat})" : ""),
                        'keterangan_detail' => $sd->alasan ?? 'Penerbitan surat resmi',
                        'status' => $sd->is_signed ? 'Ditandatangani' : 'Terbit'
                    ];
                }
            }

            // D. Tanggal Masuk & Berhenti Karyawan
            if ($kategori === 'Semua') {
                foreach ($karyawanList as $kary) {
                    if ($kary->tgl_masuk) {
                        if (!$filterDate || ($kary->tgl_masuk >= $start && $kary->tgl_masuk <= $end)) {
                            $historyList[] = [
                                'tanggal_sort' => $kary->tgl_masuk,
                                'nik' => $kary->nik ?? '-',
                                'nama' => $kary->nama ?? '-',
                                'kategori' => 'Status Karyawan',
                                'unit' => $kary->unit_sekarang ?? '-',
                                'jabatan' => $kary->jabatan_sekarang ?? '-',
                                'tanggal' => Carbon::parse($kary->tgl_masuk)->format('d-m-Y'),
                                'deskripsi' => "Tanggal Masuk / Onboarding Perusahaan",
                                'keterangan_detail' => "Bergabung sebagai " . ($kary->jabatan_sekarang ?? 'Karyawan'),
                                'status' => 'Aktif'
                            ];
                        }
                    }

                    if ($kary->tgl_berhenti) {
                        if (!$filterDate || ($kary->tgl_berhenti >= $start && $kary->tgl_berhenti <= $end)) {
                            $historyList[] = [
                                'tanggal_sort' => $kary->tgl_berhenti,
                                'nik' => $kary->nik ?? '-',
                                'nama' => $kary->nama ?? '-',
                                'kategori' => 'Status Karyawan',
                                'unit' => $kary->unit_sekarang ?? '-',
                                'jabatan' => $kary->jabatan_sekarang ?? '-',
                                'tanggal' => Carbon::parse($kary->tgl_berhenti)->format('d-m-Y'),
                                'deskripsi' => "Tanggal Berhenti / Resign / End of Contract",
                                'keterangan_detail' => "Status non-aktif per tanggal berhenti",
                                'status' => 'Tidak Aktif'
                            ];
                        }
                    }
                }
            }

            // Urutkan riwayat berdasarkan tanggal descending
            usort($historyList, function($a, $b) {
                return strcmp($b['tanggal_sort'], $a['tanggal_sort']);
            });

            return $this->helper->customResponse('OK', 200, $historyList);
        } catch (\Exception $e) {
            return $this->helper->responseCatch($e);
        }
    }

    public function public_exportHistoryKaryawan()
    {
        try {
            $req = request();
            $start = null;
            $end = null;
            $filterDate = false;
            $labelPeriod = 'Semua_Periode';

            if ($req->tipe_periode === 'Rentang Tanggal' && $req->date_start && $req->date_end) {
                $start = Carbon::parse($req->date_start)->format('Y-m-d');
                $end = Carbon::parse($req->date_end)->format('Y-m-d');
                $filterDate = true;
                $labelPeriod = $start . '_sd_' . $end;
            } elseif ($req->tipe_periode === 'Bulan' && ($req->month || $req->periode)) {
                $month = $req->month ?? $req->periode;
                $start = Carbon::parse($month . '-01')->startOfMonth()->format('Y-m-d');
                $end = Carbon::parse($month . '-01')->endOfMonth()->format('Y-m-d');
                $filterDate = true;
                $labelPeriod = $month;
            }

            $kategori = $req->kategori ?? 'Semua';

            $karyQuery = DB::table('m_kary as k')
                ->leftJoin('m_dir as d', 'k.m_dir_id', '=', 'd.id')
                ->leftJoin('m_divisi as div', 'k.m_divisi_id', '=', 'div.id')
                ->select(
                    'k.id',
                    'k.kode as nik',
                    'k.nama_lengkap as nama',
                    'd.nama as unit_sekarang',
                    'div.nama as jabatan_sekarang',
                    'k.tgl_masuk',
                    'k.tgl_berhenti',
                    'k.is_active'
                );

            if ($req->m_dir_id) $karyQuery->where('k.m_dir_id', $req->m_dir_id);
            if ($req->m_divisi_id) $karyQuery->where('k.m_divisi_id', $req->m_divisi_id);
            if ($req->m_kary_id) {
                if (is_array($req->m_kary_id)) {
                    $karyQuery->whereIn('k.id', $req->m_kary_id);
                } elseif (strpos($req->m_kary_id, ',') !== false) {
                    $karyQuery->whereIn('k.id', explode(',', $req->m_kary_id));
                } else {
                    $karyQuery->where('k.id', $req->m_kary_id);
                }
            }
            if ($req->is_active !== null && $req->is_active !== '' && $req->is_active !== 'Semua') {
                $isActive = filter_var($req->is_active, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($isActive !== null) {
                    $karyQuery->where('k.is_active', $isActive ? 'true' : 'false');
                }
            }

            $karyawanList = $karyQuery->get()->keyBy('id');
            $karyawanIds = $karyawanList->keys()->toArray();

            $historyList = [];

            if (!empty($karyawanIds)) {
                // A. Mutasi & Kontrak
                if ($kategori === 'Semua' || $kategori === 'Mutasi & Kontrak') {
                    $kontrakQ = DB::table('m_kary_det_kontrak as kdk')
                        ->leftJoin('m_dir as d', 'kdk.m_dir_id', '=', 'd.id')
                        ->leftJoin('m_divisi as div', 'kdk.m_divisi_id', '=', 'div.id')
                        ->leftJoin('m_general as gen', 'kdk.tipe_karyawan_id', '=', 'gen.id')
                        ->whereIn('kdk.m_karyawan_id', $karyawanIds)
                        ->select('kdk.m_karyawan_id', 'kdk.tgl_awal', 'kdk.tgl_akhir', 'kdk.duration', 'kdk.status', 'd.nama as unit', 'div.nama as jabatan', 'gen.value as tipe_karyawan');
                    if ($filterDate) {
                        $kontrakQ->where(function($q) use ($start, $end) {
                            $q->whereBetween('kdk.tgl_awal', [$start, $end])->orWhereBetween('kdk.tgl_akhir', [$start, $end]);
                        });
                    }
                    foreach ($kontrakQ->get() as $kd) {
                        $kary = $karyawanList[$kd->m_karyawan_id] ?? null;
                        if (!$kary) continue;
                        $tglAwal = $kd->tgl_awal ? Carbon::parse($kd->tgl_awal)->format('d-m-Y') : '-';
                        $tglAkhir = $kd->tgl_akhir ? Carbon::parse($kd->tgl_akhir)->format('d-m-Y') : '-';
                        $historyList[] = [
                            'tanggal_sort' => $kd->tgl_awal ?? '1970-01-01',
                            'NIK' => $kary->nik ?? '-',
                            'NAMA KARYAWAN' => $kary->nama ?? '-',
                            'KATEGORI' => 'Mutasi & Kontrak',
                            'UNIT' => $kd->unit ?? $kary->unit_sekarang ?? '-',
                            'JABATAN' => $kd->jabatan ?? $kary->jabatan_sekarang ?? '-',
                            'TANGGAL / PERIODE' => "{$tglAwal} s/d {$tglAkhir}",
                            'RIWAYAT / PERUBAHAN' => "Kontrak / Penempatan {$kd->tipe_karyawan} ({$kd->duration} Bulan)",
                            'KETERANGAN / DETAIL' => "Unit: " . ($kd->unit ?? '-') . " | Jabatan: " . ($kd->jabatan ?? '-'),
                            'STATUS' => $kd->status ? 'Aktif' : 'Selesai'
                        ];
                    }

                    $extendQ = DB::table('t_extend_kontrak as tek')
                        ->leftJoin('m_dir as d', 'tek.m_dir_id', '=', 'd.id')
                        ->leftJoin('m_divisi as div', 'tek.m_divisi_id', '=', 'div.id')
                        ->leftJoin('m_general as gen', 'tek.tipe_karyawan_id', '=', 'gen.id')
                        ->whereIn('tek.m_karyawan_id', $karyawanIds)
                        ->select('tek.m_karyawan_id', 'tek.nomor', 'tek.tgl_awal', 'tek.tgl_akhir', 'tek.duration', 'tek.status', 'tek.catatan', 'd.nama as unit', 'div.nama as jabatan', 'gen.value as tipe_karyawan');
                    if ($filterDate) {
                        $extendQ->where(function($q) use ($start, $end) {
                            $q->whereBetween('tek.tgl_awal', [$start, $end])->orWhereBetween('tek.tgl_akhir', [$start, $end]);
                        });
                    }
                    foreach ($extendQ->get() as $ed) {
                        $kary = $karyawanList[$ed->m_karyawan_id] ?? null;
                        if (!$kary) continue;
                        $tglAwal = $ed->tgl_awal ? Carbon::parse($ed->tgl_awal)->format('d-m-Y') : '-';
                        $tglAkhir = $ed->tgl_akhir ? Carbon::parse($ed->tgl_akhir)->format('d-m-Y') : '-';
                        $historyList[] = [
                            'tanggal_sort' => $ed->tgl_awal ?? '1970-01-01',
                            'NIK' => $kary->nik ?? '-',
                            'NAMA KARYAWAN' => $kary->nama ?? '-',
                            'KATEGORI' => 'Mutasi & Kontrak',
                            'UNIT' => $ed->unit ?? $kary->unit_sekarang ?? '-',
                            'JABATAN' => $ed->jabatan ?? $kary->jabatan_sekarang ?? '-',
                            'TANGGAL / PERIODE' => "{$tglAwal} s/d {$tglAkhir}",
                            'RIWAYAT / PERUBAHAN' => "Perpanjangan Kontrak: " . ($ed->nomor ?? '-') . " ({$ed->duration} Bulan)",
                            'KETERANGAN / DETAIL' => ($ed->catatan ? $ed->catatan . " | " : "") . "Tipe: " . ($ed->tipe_karyawan ?? '-'),
                            'STATUS' => $ed->status ?? 'APPROVED'
                        ];
                    }
                }

                // B. Riwayat Gaji
                if ($kategori === 'Semua' || $kategori === 'Riwayat Gaji') {
                    $gajiQ = DB::table('t_final_gaji_det as fgd')
                        ->leftJoin('t_final_gaji as fg', 'fgd.t_final_gaji_id', '=', 'fg.id')
                        ->whereIn('fgd.m_kary_id', $karyawanIds)
                        ->select(
                            'fgd.m_kary_id',
                            'fgd.periode',
                            'fgd.periode_in_date',
                            'fg.periode_awal',
                            'fg.periode_akhir',
                            'fg.status as status_gaji',
                            'fgd.status as status_gaji_det',
                            'fgd.netto',
                            'fgd.total_gaji',
                            'fgd.total_tax'
                        );

                    if ($filterDate) {
                        $gajiQ->where(function($q) use ($start, $end) {
                            $q->whereBetween('fgd.periode_in_date', [$start, $end])
                              ->orWhere(function($sub) use ($start, $end) {
                                  $sub->whereNotNull('fgd.periode')
                                      ->whereBetween('fgd.periode', [$start, $end]);
                              })
                              ->orWhereBetween('fg.periode_awal', [$start, $end])
                              ->orWhereBetween('fg.periode_akhir', [$start, $end]);
                        });
                    }
                    foreach ($gajiQ->orderBy('fgd.periode_in_date', 'desc')->get() as $gd) {
                        $kary = $karyawanList[$gd->m_kary_id] ?? null;
                        if (!$kary) continue;
                        $sortDate = $gd->periode_in_date ?? $gd->periode_awal ?? ($gd->periode ? $gd->periode . '-01' : '1970-01-01');
                        $periodeLabel = '-';
                        if ($gd->periode_in_date) {
                            $periodeLabel = Carbon::parse($gd->periode_in_date)->translatedFormat('F Y');
                        } elseif ($gd->periode) {
                            $periodeLabel = is_numeric(substr($gd->periode, 0, 4)) ? Carbon::parse($gd->periode . '-01')->translatedFormat('F Y') : $gd->periode;
                        } elseif ($gd->periode_awal) {
                            $periodeLabel = Carbon::parse($gd->periode_awal)->format('d-m-Y') . ' s/d ' . Carbon::parse($gd->periode_akhir)->format('d-m-Y');
                        }
                        $nettoFormatted = number_format($gd->netto ?? 0, 0, ',', '.');
                        $brutoFormatted = number_format($gd->total_gaji ?? 0, 0, ',', '.');
                        $taxFormatted = number_format($gd->total_tax ?? 0, 0, ',', '.');
                        $historyList[] = [
                            'tanggal_sort' => $sortDate,
                            'NIK' => $kary->nik ?? '-',
                            'NAMA KARYAWAN' => $kary->nama ?? '-',
                            'KATEGORI' => 'Riwayat Gaji',
                            'UNIT' => $kary->unit_sekarang ?? '-',
                            'JABATAN' => $kary->jabatan_sekarang ?? '-',
                            'TANGGAL / PERIODE' => $periodeLabel,
                            'RIWAYAT / PERUBAHAN' => "Penggajian Periode " . $periodeLabel,
                            'KETERANGAN / DETAIL' => "Bruto: Rp {$brutoFormatted} | PPh: Rp {$taxFormatted} | Netto (THP): Rp {$nettoFormatted}",
                            'STATUS' => $gd->status_gaji ?? $gd->status_gaji_det ?? 'POSTED'
                        ];
                    }
                }

                // C. Surat & Disiplin
                if ($kategori === 'Semua' || $kategori === 'Surat & Disiplin') {
                    $suratQ = DB::table('t_surat as s')
                        ->whereIn('s.m_karyawan_id', $karyawanIds)
                        ->select('s.m_karyawan_id', 's.jenis_surat', 's.level_surat', 's.tanggal_terbit', 's.alasan', 's.is_signed');
                    if ($filterDate) {
                        $suratQ->whereBetween('s.tanggal_terbit', [$start, $end]);
                    }
                    foreach ($suratQ->get() as $sd) {
                        $kary = $karyawanList[$sd->m_karyawan_id] ?? null;
                        if (!$kary) continue;
                        $tglTerbit = $sd->tanggal_terbit ? Carbon::parse($sd->tanggal_terbit)->format('d-m-Y') : '-';
                        $historyList[] = [
                            'tanggal_sort' => $sd->tanggal_terbit ?? '1970-01-01',
                            'NIK' => $kary->nik ?? '-',
                            'NAMA KARYAWAN' => $kary->nama ?? '-',
                            'KATEGORI' => 'Surat & Disiplin',
                            'UNIT' => $kary->unit_sekarang ?? '-',
                            'JABATAN' => $kary->jabatan_sekarang ?? '-',
                            'TANGGAL / PERIODE' => $tglTerbit,
                            'RIWAYAT / PERUBAHAN' => "Surat: {$sd->jenis_surat} " . ($sd->level_surat ? "({$sd->level_surat})" : ""),
                            'KETERANGAN / DETAIL' => $sd->alasan ?? 'Penerbitan surat resmi',
                            'STATUS' => $sd->is_signed ? 'Ditandatangani' : 'Terbit'
                        ];
                    }
                }
            }

            usort($historyList, function($a, $b) {
                return strcmp($b['tanggal_sort'], $a['tanggal_sort']);
            });

            // Hilangkan field sorting sebelum render excel
            $exportRows = array_map(function($item) {
                unset($item['tanggal_sort']);
                return $item;
            }, $historyList);

            $export = new class(collect($exportRows)) implements FromCollection, WithHeadings {
                protected $data;
                public function __construct($data) { $this->data = $data; }
                public function collection() { return $this->data; }
                public function headings(): array
                {
                    return [
                        'NIK', 'NAMA KARYAWAN', 'KATEGORI', 'UNIT', 'JABATAN',
                        'TANGGAL / PERIODE', 'RIWAYAT / PERUBAHAN', 'KETERANGAN / DETAIL', 'STATUS'
                    ];
                }
            };

            return Excel::download($export, "laporan_history_karyawan_{$labelPeriod}.xlsx");
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function public_exportTHR()
    {
        try {
            $req = request();
            
            // Validasi tanggal cut-off wajib ada
            if (!$req->filled('date_cut_off')) {
                throw new \Exception("Tanggal Cut-Off wajib diisi untuk menghitung masa kerja dan THR.");
            }
            
            $date_cut_off = \Carbon\Carbon::parse($req->date_cut_off)->format('Y-m-d');
            $cutOffObj = \Carbon\Carbon::parse($date_cut_off);

            // Tarik data karyawan dengan relasi lengkap, termasuk m_agama
            $karyQuery = m_kary::with(['m_dir', 'm_divisi', 'm_standart_gaji', 'agama', 'm_kary_det_kontrak']);

            // Terapkan Filter
            if ($req->filled('m_kary_id')) {
                $ids = array_map('intval', explode(',', $req->m_kary_id));
                $karyQuery->whereIn('id', $ids);
            } else {
                if ($req->filled('m_divisi_id')) $karyQuery->where('m_divisi_id', $req->m_divisi_id);
                if ($req->filled('m_dir_id')) $karyQuery->where('m_dir_id', $req->m_dir_id);
            }

            if ($req->filled('is_active')) {
                $isActive = filter_var($req->is_active, FILTER_VALIDATE_BOOLEAN);
                $karyQuery->where('is_active', $isActive);
            }

            // Pengecekan filter ke kolom agama_id
            if ($req->filled('agama')) {
                $karyQuery->where('agama_id', $req->agama);
            }

            $karyawans = $karyQuery->get();

            if ($karyawans->isEmpty()) {
                throw new \Exception("Tidak ada data karyawan yang sesuai dengan filter pencarian.");
            }

            $rows = [];

            foreach ($karyawans as $kary) {
                // NILAI DEFAULT JIKA KEDUA TANGGAL (tgl_masuk & created_at) KOSONG
                $lamaBekerjaStr = 'Data Tgl Masuk Kosong';
                $thr = 0;
                $tglMasukStr = '-';

                // TENTUKAN TANGGAL ACUAN (Fallback ke created_at jika tgl_masuk kosong)
                $tanggalAcuan = $kary->tgl_masuk;
                if(empty($tanggalAcuan)){
                    $tanggalAcuan = $kary->m_kary_det_kontrak->sortBy('tgl_awal')->first()?->tgl_awal;
                }
                if (empty($tanggalAcuan) && !empty($kary->created_at)) {
                    $tanggalAcuan = $kary->created_at;
                }

                if (!empty($tanggalAcuan)) {
                    // Carbon akan otomatis membaca dan mem-parsing format Date maupun DateTime
                    // Tambahkan startOfDay() agar jam/menit/detik di-reset ke 00:00:00 (menghindari perhitungan bulan meleset)
                    $tglMasukObj = \Carbon\Carbon::parse($tanggalAcuan)->startOfDay();
                    
                    // Format untuk ditampilkan di Excel (Hanya Tanggal)
                    $tglMasukStr = $tglMasukObj->format('d/m/Y');
                    
                    $totalMonths = $tglMasukObj->diffInMonths($cutOffObj);
                    $diffYears = $tglMasukObj->diffInYears($cutOffObj);
                    $diffMonthsRemainder = $tglMasukObj->copy()->addYears($diffYears)->diffInMonths($cutOffObj);
                    
                    $lamaBekerjaStr = "{$diffYears} Tahun {$diffMonthsRemainder} Bulan";

                    $gajiPokok = $kary->m_standart_gaji->gaji_pokok ?? 0;
                    $periodeGaji = strtolower($kary->m_standart_gaji->gaji_pokok_periode ?? 'bulanan');
                    
                    $upahSatuBulan = ($periodeGaji === 'harian') ? ($gajiPokok * 25) : $gajiPokok;

                    if ($totalMonths >= 12) {
                        $thr = $upahSatuBulan;
                    } else if ($totalMonths >= 3) {
                        $thr = ($totalMonths / 12) * $upahSatuBulan;
                    } 
                }

                $rows[] = [
                    'ID KARYAWAN' => $kary->kode ?? '-',
                    'NAMA KARYAWAN' => $kary->nama_lengkap ?? '',
                    'UNIT' => $kary->m_dir->nama ?? '-',
                    'JABATAN' => $kary->m_divisi->nama ?? '-',
                    'AGAMA' => $kary->agama->value ?? '-', // Memanggil dari relasi
                    'TANGGAL MASUK' => $tglMasukStr, // Sudah bersih hanya DD/MM/YYYY
                    'LAMA BEKERJA' => $lamaBekerjaStr,
                    'THR DITERIMA' => round($thr, 0),
                    'IS_NO_THR' => ($thr == 0)
                ];
            }

            // 4. Proses Pembuatan File / Response
            $export = new class(collect($rows)) implements \Maatwebsite\Excel\Concerns\FromCollection, \Maatwebsite\Excel\Concerns\WithHeadings, \Maatwebsite\Excel\Concerns\WithStyles {
                protected $data;
                
                public function __construct($data) { 
                    $this->data = $data; 
                }
                
                public function collection() { 
                    return $this->data->map(function($item) {
                        unset($item['IS_NO_THR']); 
                        return $item;
                    });
                }
                
                public function headings(): array {
                    return [
                        'ID KARYAWAN', 'NAMA KARYAWAN', 'UNIT', 'JABATAN', 
                        'AGAMA', 'TANGGAL MASUK', 'LAMA BEKERJA', 'THR DITERIMA'
                    ];
                }
                
                public function styles(\PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet) {
                    $highestColumn = $sheet->getHighestColumn();
                    $sheet->getStyle('A1:' . $highestColumn . '1')->getFont()->setBold(true);
                    
                    // Format agar kolom THR berbentuk format Number (#,##0)
                    $sheet->getStyle('H2:H' . ($this->data->count() + 1))
                          ->getNumberFormat()
                          ->setFormatCode('#,##0');

                    foreach ($this->data as $index => $row) {
                        $rowIndex = $index + 2;
                        // Ubah warna font jadi abu-abu pudar untuk karyawan yang tidak dapat THR (< 3 bulan)
                        if ($row['IS_NO_THR']) {
                            $sheet->getStyle('A' . $rowIndex . ':' . $highestColumn . $rowIndex)->applyFromArray([
                                'font' => ['color' => ['argb' => 'FF999999']],
                            ]);
                        }
                    }
                    return [];
                }
            };

            // Mode View HTML Frontend
            if (strtolower($req->input('tipe')) === 'html') {
                return response()->json([
                    'status' => 'success',
                    'data' => collect($rows)->map(function($item) {
                        unset($item['IS_NO_THR']); 
                        return $item;
                    })
                ]);
            }

            // Mode Download Excel
            return \Maatwebsite\Excel\Facades\Excel::download($export, "Laporan_THR_{$date_cut_off}.xlsx");

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
}