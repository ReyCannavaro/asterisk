@php
  use Carbon\Carbon;
  use Carbon\CarbonPeriod;
  use App\Models\CustomModels\t_mutasi;
  use App\Models\CustomModels\t_jadwal_kerja_n;
  use App\Models\CustomModels\t_jadwal_kerja_d_hari_n;
  Carbon::setLocale('id');
  $req = app()->request;

  $id = $req->id;
  $t_mutasi = t_mutasi::find($id);

  $carbonDate = Carbon::parse($t_mutasi->tgl);
  //$namaHari = $carbonDate->translatedFormat('l');
  $tanggalIndo = $carbonDate->translatedFormat('l, d F Y');

  $terbitDate = Carbon::parse($t_mutasi?->updated_at ?? $t_mutasi?->created_at ?? now());
  $tanggalTerbit = $terbitDate->translatedFormat('d F Y');

  $tembusan = $t_mutasi?->t_mutasi_d_tembusan ?? null;
  if ((!$tembusan || count($tembusan) === 0) && !empty($t_mutasi?->id)) {
    try {
      $tembusan = \DB::table('t_mutasi_d_tembusan')->where('t_mutasi_id', $t_mutasi->id)->get();
    } catch (\Throwable $th) {
    }
  }


  if ($tembusan && count($tembusan) > 0) {
    $tembusan = collect($tembusan)->unique(function ($item) {
      return trim(is_array($item) ? ($item['value'] ?? '') : ($item->value ?? ''));
    })->values();
  }

  $memperhatikan = $t_mutasi?->t_mutasi_d_memperhatikan ?? null;
  if ((!$memperhatikan || count($memperhatikan) === 0) && !empty($t_mutasi?->id)) {
    try {
      $memperhatikan = \DB::table('t_mutasi_d_memperhatikan')->where('t_mutasi_id', $t_mutasi->id)->get();
    } catch (\Throwable $th) {
    }
  }


  if ($memperhatikan && count($memperhatikan) > 0) {
    $memperhatikan = collect($memperhatikan)->unique(function ($item) {
      return trim(is_array($item) ? ($item['value'] ?? '') : ($item->value ?? ''));
    })->values();
  }

  // Query jam kerja asli dari tabel detail jadwal kerja di database
  $jadwalLama = null;
  if (!empty($t_mutasi?->jadwal_kerja_lama_id)) {
    try {
      $jadwalLama = \DB::table('t_jadwal_kerja_d_hari_n')
        ->where('t_jadwal_kerja_n_id', $t_mutasi->jadwal_kerja_lama_id)
        ->whereNotNull('waktu_mulai')
        ->where('waktu_mulai', '!=', '')
        ->first();
    } catch (\Throwable $th) {
      $jadwalLama = null;
    }
  }

  $jadwalBaru = null;
  if (!empty($t_mutasi?->jadwal_kerja_baru_id)) {
    try {
      $jadwalBaru = \DB::table('t_jadwal_kerja_d_hari_n')
        ->where('t_jadwal_kerja_n_id', $t_mutasi->jadwal_kerja_baru_id)
        ->whereNotNull('waktu_mulai')
        ->where('waktu_mulai', '!=', '')
        ->first();
    } catch (\Throwable $th) {
      $jadwalBaru = null;
    }
  }

  // Format jam kerja riil dari database
  $formatJam = function ($jadwal) {
    if (!$jadwal || empty($jadwal->waktu_mulai)) {
      return '08:00 - 17:00 (Kebutuhan Setempat)';
    }
    $mulai = substr($jadwal->waktu_mulai, 0, 5);
    $akhir = !empty($jadwal->waktu_akhir) ? substr($jadwal->waktu_akhir, 0, 5) : (!empty($jadwal->waktu_selesai) ? substr($jadwal->waktu_selesai, 0, 5) : '17:00');
    return "{$mulai} - {$akhir} (Kebutuhan Setempat)";
  };

  $jamKerjaLama = $formatJam($jadwalLama);
  $jamKerjaBaru = $formatJam($jadwalBaru);

  // Deteksi entitas perusahaan baru & lama
  $dest = strtoupper(
    ($t_mutasi->m_sub_baru?->name ?? '') . ' ' .
    ($t_mutasi->m_sbu_baru?->name ?? '') . ' ' .
    ($t_mutasi->m_sub_baru?->kode ?? '') . ' ' .
    ($t_mutasi->m_sbu_baru?->kode ?? '')
  );
  $origin = strtoupper(
    ($t_mutasi->m_sub_lama?->name ?? '') . ' ' .
    ($t_mutasi->m_sbu_lama?->name ?? '') . ' ' .
    ($t_mutasi->m_sub_lama?->kode ?? '') . ' ' .
    ($t_mutasi->m_sbu_lama?->kode ?? '') . ' ' .
    ($t_mutasi->m_kary?->m_sbu?->name ?? '') . ' ' .
    ($t_mutasi->m_kary?->m_sbu?->kode ?? '')
  );

  $checkIsJp = function ($str) {
    return str_contains($str, 'JEPE') ||
      str_contains($str, 'JP BOOKS') ||
      str_contains($str, 'JPBOOKS') ||
      str_contains($str, 'JPMU') ||
      str_contains($str, 'SAHABAT EDUKASI') ||
      preg_match('/\bJP\b/', $str);
  };

  // Menggunakan template KOP resmi JP Books (PT. JePe Press Media Utama) sesuai acuan cetak
  $isJpBooks = true;
  $companyName = 'PT. JePe Press Media Utama';
  $kotaTerbit = $t_mutasi?->m_branch_baru?->kota
    ?? $t_mutasi?->m_branch_lama?->kota
    ?? $t_mutasi?->m_kary?->m_branch?->kota
    ?? 'Surabaya';

  $resolveMedia = function ($rawPath) {
    if (empty($rawPath))
      return '';
    if (str_starts_with($rawPath, 'data:image/'))
      return $rawPath;

    $clean = preg_replace('#^https?://[^/]+/#i', '', ltrim($rawPath, '/'));
    $clean = ltrim($clean, '/');

    $candidates = [
      $clean,
      'uploads/m_media/' . $clean,
      'uploads/' . $clean,
      'storage/' . $clean,
      'images/' . $clean,
      'media/' . $clean
    ];

    foreach ($candidates as $cand) {
      $paths = [
        function_exists('base_path') ? base_path($cand) : null,
        function_exists('public_path') ? public_path($cand) : null,
        function_exists('base_path') ? base_path('public/' . $cand) : null,
        function_exists('base_path') ? base_path('storage/' . $cand) : null,
        __DIR__ . '/../' . $cand,
        __DIR__ . '/../../' . $cand,
        __DIR__ . '/../../../' . $cand,
        '/opt/www/hris/public/' . $cand,
        '/opt/www/hris/' . $cand,
        $cand
      ];
      foreach ($paths as $full) {
        if ($full && file_exists($full) && is_file($full) && filesize($full) > 50) {
          $type = pathinfo($full, PATHINFO_EXTENSION);
          return 'data:image/' . ($type === 'png' ? 'png' : 'jpeg') . ';base64,' . base64_encode(file_get_contents($full));
        }
      }
    }
    return '';
  };

  // 1. Ambil header JP Books dari media fisik lokal terlebih dahulu (sesuai instruksi), lalu fallback DB
  $logoJpHeader = '';
  $headerCandidates = [
    'media/header_jpbooks.jpg',
    'public/media/header_jpbooks.jpg',
    'images/header_jpbooks.jpg',
    'storage/header_jpbooks.jpg',
    'uploads/m_media/header_jpbooks.jpg',
    'media/b64_header_jpbooks.txt',
    'public/media/b64_header_jpbooks.txt',
  ];
  foreach ($headerCandidates as $cand) {
    $paths = [
      function_exists('base_path') ? base_path($cand) : null,
      function_exists('public_path') ? public_path($cand) : null,
      function_exists('base_path') ? base_path('public/' . $cand) : null,
      __DIR__ . '/../' . $cand,
      __DIR__ . '/../../' . $cand,
      __DIR__ . '/../../../' . $cand,
      '/opt/www/hris/public/' . $cand,
      '/opt/www/hris/' . $cand,
      $cand
    ];
    foreach ($paths as $full) {
      if ($full && file_exists($full) && is_file($full) && filesize($full) > 50) {
        $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
        if ($ext === 'txt') {
          $logoJpHeader = 'data:image/jpeg;base64,' . trim(file_get_contents($full));
        } else {
          $logoJpHeader = 'data:image/' . ($ext === 'png' ? 'png' : 'jpeg') . ';base64,' . base64_encode(file_get_contents($full));
        }
        break 2;
      }
    }
  }

  // Jika belum ditemukan di lokal, cari dari tabel m_media di database
  if (empty($logoJpHeader) || !str_starts_with($logoJpHeader, 'data:image/')) {
    try {
      $mediaHeaderJP = \DB::table('m_media')
        ->where('is_active', true)
        ->whereIn('kode', ['HEADER-JPBOOKS', 'LOGO-JPBOOKS'])
        ->orderBy('id', 'desc')
        ->first();
      if ($mediaHeaderJP && !empty($mediaHeaderJP->file_path)) {
        $res = $resolveMedia($mediaHeaderJP->file_path);
        if (str_starts_with($res, 'data:image/')) {
          $logoJpHeader = $res;
        }
      }
    } catch (\Throwable $th) {
    }
  }

  // Fallback 3: Base64 default ter-embed langsung (100% aman jika file/database di server belum tersinkron)
  if (empty($logoJpHeader) || !str_starts_with($logoJpHeader, 'data:image/')) {
    $logoJpHeader = 'data:image/jpeg;base64,' . '/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAIBAQEBAQIBAQECAgICAgQDAgICAgUEBAMEBgUGBgYFBgYGBwkIBgcJBwYGCAsICQoKCgoKBggLDAsKDAkKCgr/2wBDAQICAgICAgUDAwUKBwYHCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgr/wAARCAEcB0UDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooqPz/agCSio/P8Aajz/AGoAkoqPz/ajz/agCSio/P8Aajz/AGoAkoqPz/ajz/agCSio/P8Aajz/AGoAkoqPz/ajz/agCSio/P8Aajz/AGoAkoqPz/ajz/agCSio/P8Aajz/AGoAkoqPz/ajz/agCSio/P8Aajz/AGoAkoqPz/aigCSio/P9qKAJKKjooAkoqOigCSio6KAJKKjooAkoqOigCSio6KAJKKjooAkoqOigCSio6KAJKKjooAkoqOigCSio6KAJKKjooAkoqOigCSio6KAJKKjooAkoqOigCSio6KAJKKjooAkoqOigCSio6KAJKKjooAkoqOigCSio6PP9qAJKKjqSgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCOftRRP2qE3QAyTigTaW5NRVH7bD/fH51LBc2w63Kf991XLUMvrFH+dEnz+1Hz+1J/aFp/z3j/77o/tC0/57x/990ctQx9tS/nF+f2o+f2pP7QtP+e8f/fdH9oWn/PeP/vunyVOwe3o/wA6F+f2o+f2pP7QtP8AnvH/AN90f2haf894/wDvuly1A9tS/nF+f2o+f2pP7QtP+e8f/fdH9oWn/PeP/vujlqB7al/OL8/tR8/tSf2hZ/8APyn/AH0KP7QtP+e8f/fdHLUD29F/bQvz+1Hz+1J/aFp/z3j/AO+6P7QtP+e8f/fdHLUD21L+cX5/aj5/ak/tC0/57x/990f2haf894/++6OWoHtqX84vz+1Hz+1J/aFp/wA94/8Avuj+0LT/AJ7x/wDfdHLUD21L+cX5/aj5/ak/tC0/57x/990f2haf894/++xRy1A9tS/nF+f2qTLf3f1qP+0LT/nvF/38FN+32f8Az8J/38p8jH7ekvtr7x3z+1S1Tgvopx5hkTb70+3niA/1w/OsJ1adN2lI2hOVRc0R9zU1Vv8ARv8AnvH/AN/KX7TD/wA/MP8A33R7ej/OdHLPsWKKg+0J/wA9o/zFH2hP+e0f5iuf29H+cXLUJ6Kg+0J/z2j/ADFJ9ph/5+Yf++6Xt6P84ctQsUVB9oT/AJ7R/mKPtCf89o/zFP29H+cOWoT0VX+0w/8APzD/AN90faYf+fmH/vuj29H+cfJU7Fiiq/2mH/n5h/77o+0w/wDPzD/33R7ej/OHJU7Fiiq/2qL/AJ7Rf990faYf+fmH/vuj29H+cOSp2LFFV/tMP/PzD/33R9ph/wCfmH/vuj29H+cOSp2LFFV/tMP/AD8w/wDfdL9oT/ntH+Yo9vR/nFy1Ceiq/wBph/5+Yf8Avuj7TD/z8w/990e3o/zj5KnYsUVX+0w/8/MP/fdH2mL/AJ6xf990e3o/zhyVOxYoqD7Qn/PWP8xR9oT/AJ7R/mKPb0f5xctQnoqv9pg/57p+dH2mH/n5h/77o9vR/nHyVOxYoqD7Qn/PaP8AMUfaE/57R/mKPb0f5xctQnoqv9ph/wCfmH/vuj7TF/z1i/77o9vR/nHyVOxYoqv9qi/56xf990faYf8An5h/77pe3o/zhyVOxYoqv9ph/wCfmH/vuj7TD/z8w/8AfdHt6P8AOHJU7FiioPtCf89o/wAxR9oT/ntH+Yp+3o/zi5ahPRUH2hP+e0f5ij7Qn/PaP8xR7ej/ADhy1CeioPOh/wCeqf8AfdJ9ph/5+Yf++6Pb0f5w5ahYoqHz1/56R/nR56/89I/zo9vR/nFyvsTUVX+0wDrOn50faYf+fmH/AL7o9vR/nHyVCxRUHnp/z1j/ADFL56/89I/zo9vS/nHaZNRUPnr/AM9I/wA6Tz1/56x/mKPb0f5xctQnoqv9ph/5+Yf++6PtUX/PWL/vuq9tS/icw+WfYnjjxS1Xs5sirT9q6bqaM1NzHUUUUxhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUHpxQBFPgGvjj/AIKv+OvF3gL4a6Jd+D/Emqae0+pbX/s/Ufs1fYcrkxbin418W/8ABY3P/CrfD3+1r4b/AMlrivpeEMPDEcR4dS7n574n4nE4bgnEVcP8R8Kf8NFftBf9Fr8T/wDgxno/4aJ/aC/6LX4n/wDBlPXI8ev6UvHqfyr+u1kOUW/3aJ/no+JM9v8A7xP7zr/+Gh/2gf8Aotfij/wY3FJ/w0N+0F/0WzxR/wCDK4rk/wBz70fufen/AKv5N/0DIw/1kzz/AKCKn/gR1v8Aw0B+0N/0WvxP/wCDW4qT/hoD9ob/AKLX4n/8GtxXFfP7Un2n3qP7Byu3+7wNP9ZM+X/L+X3nbn9oX9ob/os/if8A8GNxR/w0J+0N/wBFn8T/APgyuK5D93R+7pU8lyn/AKB4fcJcS53/ANBNT7zrv+GhP2hj/wA1s8Tf+DG4pf8AhoT9of8A6LP4n/8ABlPXE/P7VJ9mtsdT+VP+xsr/AOgaH3DnxJnUH/vNT7zsf+Ggf2iB0+M/if8A8GtxSH9oL9obv8a/E/8A4NLiuKtqm8j3prJcmq1v93h9w/8AWTPaX/MRL7zsf+Ghf2hv+iz+KP8AwY3FJN+0F+0H/wBFo8T/APgyuK4+o6n+xcq/6B6Yv9ZM7/6Can3na/8ADQv7Q3/RZ/FH/gxuKP8AhoX9ob/os/if/wAGNxXFUVt/q/lf/PiH3Ff6yZ7/ANBEzrv+Gif2gun/AAuvxP8A+DKel/4aA+P/AP0WfxT/AODKeuQ49aOMVEMlyL/oGX3B/rJnv/QRU+867/hov9oL/otfij/wY3FH/DRf7QX/AEWvxR/4MbiuR+yp6ml+T++Kz/sHJ3/zDL7g/wBZM7/6CKn/AIEdb/w0V+0H/wBFs8T/APgyuKn/AOGiv2hv+i0eKP8AwY3FcVRWz4fye3+7xBcSZ1f/AHip957x8JfjR8Y9c0NY9d+Mvid19H1G4rsP+Fr/ABk6H4gah/4H3FeU/A//AJAuo/8AYRrtq/xl+kHmec5b4sY+hhZWpc5/t59HjAYTMvCPLcTioc0uQ6D/AIW98Y/+h91H/wADrij/AIW98Y/+h91H/wADriufor8f/t/PP+f8z9o/snJv+gY6L/hbvxj/AOh+1T/wOuKP+Fu/GP8A6H7VP/A64rnaKr+3c+/5/sP7Eyn/AKBkdF/wt34x/wDQ/ap/4HXFH/C3fjH/AND9qn/gdcVztFYTz3Pf+gh/eH9iZT/0DI6H/hbnxi/6H3U//A24o/4W58Yv+h91P/wNuK56itv7ez3/AJ/sP7Gyh/8ALhHRf8Lf+Mn/AEP+qf8AgdcUf8Lf+Mn/AEUDVP8AwOuK52il/b+ef8/5i/sXKP8AoGX3HRf8Lf8AjJ/0UDVP/A64o/4W/wDGT/of9U/8Driudoo/t/O/+f8AMf8AYuUf9AyOg/4W98Yv+h91H/wOuKP+Fu/GL/ofNR/8Driufoqv7fzn/n+zX+xco/6B19xv/wDC3fjF/wBD7qP/AIH3FH/C3fjF/wBD7qP/AIH3FYFFP/WLNv8An/If9iZH/wA+4nQD4v8Axg/6H/Uf/BjcUv8Awt/4ydviBqX/AIMbiueoqf8AWLNv+f8AUMJ5TkV/4C+46L/hb/xk/wCigap/4HXFH/C3/jJ/0UDVP/A64rnaKX9v53/z/mL+xco/6Bl9x0X/AAt34x/9D9qn/gdcUf8AC3fjH/0P2qf+B1xXO0VP+sebf9BEx/2LlP8A0DL7jov+Fv8Axk/6KBqf/gxuKT/hb/xl/wCig6n/AODG4rnqKqef5r0r1DX+wcB/z4h9x0X/AAt/4yf9D/qf/gxuKQ/F74xnr4/1P/wOuK56isv9Ys9/5/zMqeTZT/0DL7jof+FufGL/AKH3U/8AwNno/wCFufGL/ofdT/8AA24rnqKn+389/wCf9Qf9jZP/AM+EdF/wt/4yf9D/AKp/4HXFH/C3/jJ/0P8Aqn/gdcVztFb/ANv53/z/AJh/YmU/9AyOi/4W78Y/+h+1T/wOuKP+Fu/GP/oftU/8DriudorP/WPN/wDoIYf2JlP/AEDI6L/hbvxj/wCh+1T/AMDrij/hbvxj/wCh+1T/AMDriudorb/WDOf+f7J/sPKP+fCOi/4W/wDGT/of9T/8GNxR/wALf+Mn/Q/6n/4Mbiudopf6x57/AM/2V/YuA/58Uzov+Fu/GP8A6H7VP/A64o/4W78Y/wDoftU/8Driudoo/wBYs2/5/sP7Eyn/AKBkdEfi/wDGX/of9U/8Drim/wDC3/jF/wBD9qX/AIMZ65+isf8AWLNl/wAv6hrTyTKf+gaJ0X/C4vjN/wBD/qf/AIMbij/hcPxn/wCih6p/4Mbiudoqf9Y86/5/zM55NlP/AD4gdF/wt/4yf9D/AKn/AODG4pD8XvjJ3+IGp/8AgxuK56iqXEWe/wDP+oTTybKb/wC7L7jov+Fx/Gf/AKH/AFP/AMGNxR/wuP4z/wDQ/wCp/wDgxuK52itP9Ys6q/8AL+obf2NlP/Pin9x0X/C4/jN/0P2p/wDgxno/4XH8Z/8AoftT/wDBjPXO0Vv/AG7m3/P+p94f2NlP/Pin9x0B+L3xi7+PdR/8Driov+Fs/GT/AKH/AFT/AMD7isSis6ee508XFOvP7yJ5NlCpv9wj9If2ar3V9U+Cuh65q832u8ubFWeSvRR1P+7Xnv7MWf8AhSeh/wDYNg/9Br0EdTx/DX99cONzyLDt/wAiP45ztKObVV/fZPRRRXuI80KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCJ/umvi3/gsp/wAks8O/9h7/ANt7ivtJ+n418Xf8FlP+SV+Hf+w//wC29xX1fBH/ACU+G/xH5x4rf8kNjP8AAfnB83tQN2ecUfN7UDdnnFf2gtj/ADcf8EPn9qPm74o+f2o+f2qDmNXwr4P1Pxprv/CPeCvDr6pe/wDTklexWP8AwTl/ae1Mfbv+Eax9NQt//j1Uv2If2kvBX7NvxSbX/iAf9AvrDh6/TX4KftG/DD4+aL9v+H2upItfjnHfGfE+Q472eFpful1P6K8M/D3gri7Bw+tYuf1j+T+kfm9/w7g/ak/6Jz/5Ubf/AOPVJF/wTd/akH+s+G+P+4jb/wDx6v1igzOPlFIfM7V8B/xF7iRfyH7JT+jdwn/z+n/5L/kfkxN/wTq/ahtv9Pj+HR6f9BG3/wDj1eUeNfh/42+HJx8RfDeqab9a/abxJ4g0fwtoza5rkws7S09Ur82/+Ckf7Unw2+OLWPgv4ez+YLTUv+JhqIT7n+zX1vBHiLxRxHj1RnQvDufmviZ4VcH8J5V7ajX/AHp87+G/A+sePNd/4R7wX4b/ALSvbyvXNP8A+CdP7UM4+3H4d/8ALj/0Ebf/AOPVm/sbfHLwh8CvjJZ+K/Hs/l2t+jKkv91q/VT4YfEbwh8VdDs/EHhDxFYahZ/eSW0cMpr0eO+NeJOGsdbDUvc7nkeFvhvwjxpl1sRXn7U/L7/h29+1N/0To/8Agxt//j1P/wCHa37Uf/ROz/4Mrf8A+PV+tX2b2Wnfvv8AZr4D/iL3EnaB+w/8S5cI/wDP6f8A5L/kfkd/w7X/AGnen/Cuz/4Mrf8A+PU9P+Ca/wC1CeE+HP8A5Ubf/wCPV+pniTxvoHg+1a88Wa5pmnD/AKe77b/Oud0/9ov4M6hIbOL4laVn/sIQV1UPFPjKtT9rSpq3+E8nFeBPh5ga/ssRi53/AMcf8j80L/8A4J6/tP6CPtw8L/8AlRt//j1eeeI/2efjZof+gar8NNUX/uG1+y+l+MtE11fL0fWLO69/twb/ANBrQ+x6Vc/8wX/x2qh4vcQYf/eKUCf+JeeFMT+8wOLmfhpf+F9b0H/kM+G9W03/ALCGm1n3Uf2gZj5FftN8VP2b/hl8WdE/s3xZ4a0+Rf7z2O7FfDH7W3/BL/Xvh7/xWXwPja+tB/zCq+64d8VctzSsqOJ/dTPy3jLwL4hyPmxWB/e0j4/nAJwaPn9qTyPs9L8/tX6zRksTTuj8HlQqUatp9D1P4H/8gXUf+wjXbVxXwR/5Ampf9hKuvuP9J61/iL9IRc/i5mVD++f7wfRrrc3gtldX+4JHcP8Ax1P9of8Aya+0fgN+y78F7v4eWV9rHhxNQubpO9dNf/sY/ALVZcN4bj2/rRg/CLOMdgKVahWgfRYrxay7D46rR9g/d0Pgiivub/hgD9nj/oXr/wD77q9B+wh+zxZD/kXB+NdH/EFeIP8An4Yf8RfyN/8ALuZ8F0V+gtt+x5+z1p3+r0BKt/8ADKnwP/6FjS//AABWq/4ghnH/AD/gY/8AEW8q/wCfUz875+1Ffd/ir9hj4B662Y7YWNz2aJ68G+N/7DvjL4dv/bnw+/4mNp/crxM28JeI8koe3/i0j2sm8TOHMzr+xf7qZ4TRRRX5RXU6c+WR+gqamuZBRRR5/tRBTqS5IA3yK7CftRb/APQNI/Ovafgl+xb41+Jp+3eLR/Z9l6V9H+Dv2KPgx4NgzN4eS/Premv1jh/wk4gzuh7fEfuqR+fZ54kZHlL9hH97VPg7+ztb9DSfZvav0psvhR8MLLiPw/pi/S0irO179n74L+LofsMugacf+vTbur6qt4GT/wCYfFny68Xlz+9Q0Pzhor7B+K3/AAT08H3GjNqPwrjTTb3sUFfLXjv4eeMvhpq66F4p8P7r096/NuJeAOI+Gdav8I++4d41yfiDSl/FMOiiivhD673woo/6iNH/AB8UQoOpPlRDakuaegUW9sbrp617R8Ev2NvGXxDbT/EHiz/iX6PjdsFfSXhX9i/4K+EI8/8ACN/2g351+p5B4Q8R5yvby/dUj89z3xNyPJp+wh+9Z8FjR9cvP+Zbo+ze1fpPbfCT4QWHEfhzSU/7doqzNe/Z2+C/iSH7DJ4Z04f9etitfZ/8QKqW93FnzK8Xlf3qGh+dZ/fjPpUIIPIr68+K/wDwT08FzltS8AKFvE+b7Bv+WvmDx/8ADfxr8MtZ/wCEf8WeHM+4r8u4l4D4j4Zr/vaV6R9zw/xnkef/AML+KYVFFTafb/atc0+wH/L9XyVOg6k+U+wnU5Ic4fZvaoa+5Phl+yH8EIPBljff2B/aH2mxt8/lWhqP7Df7POqDL+F9p/6cq/aKHgtnGJwtKsqsNT8sreLuSYevKl7Keh8DfP7UltX3j/wwF+z/AP8AQA1L/wADv/r1asP2D/2fbXiLw2PbNS/AviBauqcy8Zcmf/Lo+Cv+Pei3t6+9/E37Gvwbk8OPZf8ACNp8gyK+Uvgf8HdE8a/GZ/h/qsebKwrxM48LsyyfF0qHtv4p7GT+IWBzPD1a/L/CPPPn9qpXFx9qr9Bx+xd+z0QCfDgrOuf2D/2eLr/mW6+ln4GZ24aVYHmf8Reyb/n1M+Cvn9qS2r7x/wCHfPwDz/yL+pf+B1X7H9h/9n3Sv9X4bFclPwPz9P2lesZT8Ycte1E+Bf8Aj3on7V9Mftl/s1eD/Ang1/GXhTGnXfZxXzPX5zxTw3X4Zx/1SqfoHDWf4HP8B9bpaBRXp3wI/Zo8a/HfWvt+f7N0SvqbwV+xT8E/CsPmP4fTUD/t19bw14YZ5xBQ9u/3VI+Zz/xFyrJKvsF79U+Ef7M/6luof+Pev0vPwq+GEWmfYv8AhHdM2j0tIq5TxV+yH8EfFsW9/D4H/XkK+qxfgfilQ/2fF89U+aoeL2Fv/tNDQ/PuivpTUP2BNXtfihp39mH+0PC/pmj9rj9mL4d/Cj4e2Xivwvb7blbvcj/9sWr4/GeF3EeFwNXF4j/l0fUUPETI8ZjqWFof8vT5rooor80p/wC9o++lzeyZ+kf7Mf8AyRPw/wD9eEP/AKDXoSdV/GvPf2Y/+SJ+H/8Arwh/9Br0JOq/jX+h/Dn/ACIcN/ggfxTnf/I3xH+Nk9FFFe8eYFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBE/T8a+Lv+Cyn/JK/Dv8A2H//AG3uK+0X6fjXxd/wWU/5JX4d/wCw/wD+29xX1fBH/JT4b/EfnHit/wAkNjf8B+cHze1A3Z5xR83tQN2ecV/aC2P83H/BD5/agbs84o+f2o+f2qDmLIEX/LM17r/wTu8R634c/af8O2GlPqbfbhcf2p6V4G0c0fz17H+wL/yd54N/6/rj/wBJ7ivkONMLTq8M4iTPveAa+Kw/E+C9jV+2fsKpkZQfUU75/anwf6lf92nV/GzP9M6etNHzv/wUi1D+zv2XNfkz/wAs6/Ju4ufstfrL/wAFMf8Ak0rxEP8Apn/Wvyar+kfBdL+x6tbzP4o+kZN/6z4eiv5Ag719yf8ABHHxBqn9v+K/Dc//AB5Wdp8n+9thr4bEeP4f1r7Y/wCCNn/I8eK/+vf/ANlhr6HxOp0KvClefU+N8Dq+Io8fUI30P0Ug71Dc1NRP2r+S6eh/oYfnX/wV/wDHGvxeMfD/AIP0vWfJtZbR2eP1r4xTUiZfLI/8qNfXP/BYkY+N+ghP+gJ/7Xmr44bf5lf1v4c5ZhanClCq4n+d/i1j8fDj3GUlV0Os8KfFn4q/D3XF8Q+E/iRqn+h1+j37BP7amhftF6IfD3iryoPEttZ5msO/2b5fmr8u7hZI22GvYP2F/Gv/AAhf7Ufh0dP7RvPsVebxzwnlONyOrXjT5asDu8MOP89yPiDD4adXnpTP2HEnm9P1qtqGni64otuRvxU1zX8u6wfun9+z9hXpe9sfmb/wVA/Zm0n4f+MdP+KHhof6Nqz7X07sWr5G2yL/APXr9Uv+Co/hzS9c/Zl1K4n6WN3aN/5NQ1+V1xcfulNf1h4XZxWzPhTlrP36R/Afjbw/QybjHmw/wVT1L4H/APIF1H/sI121cT8D/wDkC6j/ANhGu2r/ACG+kJ/ydnNJf3z/AF1+jd/yZ3K1/cOq8LfHj4o+END/AOEe0fxHVrw9+0z8a9E1r+0P+EkOpfUW4ri6hue9fBYTibPcPOjGOLP1ypw7keLp1ZexP1E+GfiNPGfgfTfEOf8Aj7s91eH/ALcH7RWr/DaXTvCnhP8A4/7yvVP2YpPK+Cugf9eFfMH/AAUdOfifp/8A15H+dvX9Q8b55j8s8PI4zD1f3vuH86cI5VhMdxq8NWXuR5/wPKtQ/aA+N90MD4i6tU+n/tFfGy1/5qRqn/kvXFUV/Kv+t/EkXf63M/o//VrIqq/3SB9A/Db/AIKBeMdC1jT9N8WR/wBpWD/f1QV9f+F/EeieOdCXxBpOGtLvrxX5fwd6+3P+CfF/rF18Gs6w/wDx53bLtr948IuM81zrF1cuzD97A/GPE3hDLMowkcbhfcPEf23fhJpPgH4lL4k0+PZbX331FeI19g/8FItIjvPCOg6jH/0ERXx9X5j4tZXhcp4qq08OvjP0Dw3zCeZ8N0nLoFfRf7F37MsviTWf+FpePIg1p/zDM9hXiHwq8FD4h+MtP8Pyfdu7+v0s8N6NpHhfQo9C0sBfs1nX03g9wbRzfF/2riV+6pHzvijxXXyyn9Rw71qkera7oHgbQ/t+okWNrivlT46/t86tqGs/8I18Kog1j/0E6o/t3/HiTXNX/wCFYeF/vWnL+1fN3+oH1r3PEPxOr06s8syn3DzOBvDuhjKEMxzE67UPj98UNT/5DHxI/IW9dF4E/a4+MngPVftc/iD+1I/7rV5rRX4rQ4v4owWI9t9bP1TEcM8P4ih7GVE++/2dP2sdH+M+3TtZT+ztYH+s04v0re+NXwR0X4peDbzStR+W72H/AE4d6/Pbw/4i1vwvra+IfCf/ABLb+zr9EP2dvivF8WPhvY+IkxvZPmr+lOAeMsJx7ltXKsw1qn4PxlwtiOD8XDMcBL92fnr468Cax8NfGd94R1TpaCsmvr//AIKFfBuPxF4S0/xvo0e29sb7eMV8gW9z9qr+fuPOGXwjn9TC/wDLqqftXA2ef6w5N9aluHn+1fTv7Gv7LsupyL8T/iBH/wBg7Tj0SvBvhB4H1r4r+NtP8GZ+tfpNomm6R4N8PCx06Pba2acrX3nhBwZQzbFzzHEfwqR8P4o8V18FRhluH0nMq674h0HwPoR1zVwNPsrQfdr5R+N3/BQDWLjWv7A+He77F31Tfb1nfttfH+XxRrP/AAr7wqf9Cs/+Qp7V8+I+8eZ0r2fEjxOxuDxf9nZOcnAnh3hK2C/tHMjqtU+OPxR1L/mou6ui8E/tbfGfwZ/p0niE6kv/AG7rXmtFfi1DjPiXCV/bfW5n6rW4Z4fxGH9j7A+/P2d/2q/CvxssVsI5x/auz54tlbfxx+CWjfF7wZeaVf4W72fLeAfNX59eF/FGt+C9c07xDpP/AB+2Nfoh8BvijonxY+G1h4v0j/nnmv6V8PeLsJx7ls8uzL+Kfz7xrw1juDcfDMcB/Cufnz408Faz8NvGWoeFNU/5dL75OKw5+1fWv/BQH4RxavoVh8TtEixe2NfJQmA6Cv5/4+4cnwtxBPD0P4Z+78F5/Q4myKGJn8XU9W8KftkfGPwrov8AYenxoxqbwX+2l8aPDGuNqWq/8TKx/wC3evI6KxwfGvElDEUYfW9DDHcI8P1aFWfsNZn6h+AvEyeM/CFlr3l7ftdnur56/bS/af8AGfwl1uw8C+Bo1VruxPzele1fABhL8FfDqR/Kf7Etf/RK18l/8FDdknxts0/6gX/txNX9R8fcQY/A8BxxeHf733D8D4KyvA47jL6piKfue8c5B+2t8Zp9DvtD1gbvtdj+7+tcB4X8Ua34N8bf8JDo/iT/AE2sZpfK+/Wno/h7W/FWuf8ACPeEh/pt5X8tzzziDOsfS5avPVgf0PDI8lyjD1X7LkpTPV7z9sv9oLxif+Ef0Uf6dj/P/LGvtD4PX/jLUfhtp9/4sC/b2Tc9eV/svfsi6P8ACmL+3vFkn9oa0e9af7S37Umi/BfQ10zQ/wDiYaxdp8iCv6b4RqZrwzk08xz2t/4Gfz7n8stz7NoZdkVA0P2k/wBpzQ/gzohQFG1d/l09P71fLV1+258Z77Wf7c/t/wCX/oF/5hry7xh4n1vxlrn/AAkPi0f6bfVTr8R4w8Uc2zbH/wCy1vZ0j9c4a8O8pyzAf7XS9rVOs+LX7QXjH4zReX4l8QbVsf4Uqr8IPBWr/Erxpp/hHSzj1Nc7P2r6G/4J06Aup/EvUtdb/l0sdvNfPcNfXuNOKKX1r96erns8PwtwnVqYWlyn1j4a8P6J8OdFFjYFFtLSz/06vlX9or9uLxBrmr6h4N+FR22lp/zE88V9A/tWajPovwV8Q6jp3T+zbj/0RX54+R71+0eL/FOO4bwdLLsv9w/LfDXhrBZ/Uq5jjvfOkuPih8Urr/iZf8LI1Su7+GH7a/xN+HnB/wCJlZV5BRX4JheNeJ8FXhWpVz9gr8K5BjMP7GrQP0m+DXxi8G/F/Q28QeFCn/T9Xl//AAUVv/8Ai0GlyD/oNH/0nnryP/gn14pTTfjLqPh1/u31mv8A6FcV7F/wUKtTN8IdLjx/zGT/AOk81f01DiSvxN4Y4itW/i8h+BLIv7B8RMPhPscx8VfP7VBRRX8fS/jL1P6fn/DP0l/Zh/5IvoP/AF5r/KvQY+q/Rq89/Zi/5IvoP/Xmv8q9Cj6r9Gr/AEQ4c/5J7C/4IH8VZ3/yOcR/jkTUUUV7p5gUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAET9Pxr4u/4LKf8AJK/Dv/Yf/wDbe4r7Qk6V8X/8FlP+SV+Hf+w//wC29xX1fBH/ACU+G/xH5x4rf8kNjf8AAfnB8/tR8/tR8/tSW1f2ZP4T/Nt7i/P7UfP7UfP7UfP7UqdQEO+fy+1exf8ABPv/AJO78Hf9f1x/6S3FeOfP5fevY/8Agn3/AMnd+Dv+v64/9Jbivn+L/wDkm8R/gPq+Bf8AkrML/jR+xUf+pT/cp9Lb/wCoT/dFJX8VPc/09pfwkfPH/BTf/k0rxH/uCvyV+f2r9av+Cm//ACaV4j/3BX5K/P7V/Sfg1/yI6v8AjP4n+kV/yVWH/wAAfP7V9t/8EbP+R48Wf9ev/ssNfE0n+tNfbX/BG/8A5HbxZ/17j/0GGvpfEm3+p1c+H8FJ/wDGf4c/ROPvUdzU1Q3NfyBOf7s/0TPzb/4LEDHxw0Qf9QX/ANqzV8b3J4xivsj/AILDf8lu0P8A7An/ALVmr49r+wfDqvCjwjh7s/zo8WsLVnx/i+WP2yOzj+f9592voL/gnj8PNa8eftP6fqen6APsWi/6bvNcD8HP2Zfid8dtZ0+x8L+H9UWw+3/8TTVH06v0+/ZI/ZY0H9mPwMugabP9uusfPfun3q8DxK41wFDAVcFD+Kz6fwl8OM2zXPaWY4hctKkeyxBPL8tf4RUTT/J0pY7hMb0TbXL/ABM+KvhH4X+Dr3xd45misLCzG6R37V/MdOnXxU/ZxW5/ctfG4LBYT2tR+4j5p/4K5+N4tI+Dlj4CH3tcv/8A0T++/pX5tyK67a9X/av/AGh9Y/af+J48WapHt0/Tv+QXXktx/pWtbCa/rnw7yR5Jw37Ot/FZ/nh4r8U0OJuL6lTD/wAKB6p8D/8AkC6j/wBhGu2rifgf/wAgXUf+wjXbV/kH9Ir/AJO3mX+M/wBjvo0/8mYyv/AFHke9FT/P7V+J4df7XE/eYwtSZ+jn7ME+fgroAf8A58RXy/8A8FHQR8T9Pz/z5H+dvX09+zFGI/groA/6cBWd8dP2c/B/xzWO01hAk6w/8f2z5lr+1uIuHK/Evh9SweH+O0D+UcjzuhkHG1XF1vgvP8z876J+1fXbf8EzvBQ6fEPU/wDwBrU8Jf8ABOX4X2Azq+vvqH+/X4FT8G+L6uIt7h+wf8RX4c9h9s+PPC/hbW/Hmuad4M0f/j9vq/Rb9n/4XRfCX4Z2HhIv8yj5qf4C+BHw0+Hswm0XQ0Nx6YrzT9pX9qbWPhNF/ZGk+GNUCnrqN992v2HhPhPBeGuAq5jjf4h+ZcRcRY3j/HQweD+DzPPf+CiPxAj1fV9P8BaN/wAunzV8z1peIPFGteL9c1DxDqpxe3lZtv8A6L1r+bOM+I/9Zs9q4o/euEMm/wBXsnpYU+gv+Cfngz+1viNqHi1x/wAeliiCvr34ka3H4W8F6nrknSzsJW/75i3V4B/wTZ0P7P4Jv7s/xX5r0P8AbX186H+z/r8g/wCeZr+nuBKf9jeG7xX9w/n3jH/hT48dD++j4O8Uax/wk+tah4g1X/l8v6zbf/RetFFfyFi8ZXxOMq1j+l8JR+rYOFEKLi3oormUDrCvpL/gnb42j0/xFeeBpOtxmvm2vV/2L9S/sv8AaBscf8vimvu/DfMP7L4qw/sP+Xsz5LjnL4Y3hvEcy2gfcvxT8OxeLPA9/oiD/j4tPSvzD8j7Frn2DNfqzdAJZMP+mfNfmJ8XdIGnfE/xBYj7tpf1+v8Aj7hKE6GExZ+YeDGMmsTiMJ9g90/4J1eEP7U8Z6h4vk/5dPlr6m+KviCPwb4HvtfJ/wCPazuK8R/4JuaeP+EF1K//AOn+vQv2zNS+wfAHxBcDqiV9hwbRhknhpOtR/k5z5XiipPMvED2NX+dQPz/8Q6h/b2uaj4h/5/r+qdH/AB70V/H2OrvE4yrXP6hwtFYbCKgFFFFcvQuoFfTH/BOXxXqdvrmoeEZP+PL/AI+wa+Z69a/Yn8QHTPj9YWA/5fHn/wDRVxX33hvjXg+LcPY+M8Qaf1zhirD+U+3Pip4Rj8Y+A9R0Rx8t1Z81+ZP2f7LzX6sXMAm09yR96OvzL+LGj/2X8UNR03/p/r9b8fcLD2eExZ+c+DOMnRq4jCfZObooqa2r+b8JrXifu2K/3Rn6Sfs7oJPgv4d466dD/wCilr5G/wCChOYvjYwP/QC2/wDkWWvrr9nrEXwX8N56/wBnW/8A6JWvmf8AbM+F3jL4rftQ2Hh/wmflPh+1Oo/+BFxX9gcdYHEZl4eUaGG+N8h/M/BeYYfLuNKtfEfAuc+fPBXgfxl471k+H/Cnhv8A02vuT9m/9mDwr8FNO+3G3T+1LwfPL9hra+Af7OHhH4PaR8jfbrvHLvXoWs20d1ostiPma4rl4A8OMBw1h/reN1xBrxrx9iOIcR9Uw75aJ4p+1R+1ZoPwqP8AwiPheUNrN2OMV8Sax4j1vxTrmoeItU+a9vq6r9oT4d654B8X31prH9rahv8A+YjXEogRNgr8U8S+Ls4zXNqmGr/wofYP1rgTh/JsqyqOJw/7yqx3ke9FFFfl/Jc/QuQJ+1fQv/BPvxRoeg/E3UNA/wCfuxBrwC2rQ8C+M9X+H/jLT/F+ljdd2g+cV9PwVnS4d4gpYt7HyvE2VTzbh+rhIn6NfGzwYPiB8MtT8IAZF9ZzrX5v+MPCOt+Btav9C8U/8S/7HX6I/Bz44eDfi/oK32lTDd60vxE+BPww+JJEninw+jXP+zX9O8bcIYbxCwFLHYCr7x+B8I8WYvgXFVcLiKWh+btHn+1fWPin/gm7pE+f7H8fvp30xXlnjj9i34z+Dv8AkD6ANS/Gv5/zDwz4qyzalc/aMH4icOZn+7dWw39ipok/aC0+KU4U/aK+hP2+v+SDyZxu/tA/ltlr5H0+3+KHwe1rT/EOseG/7PvbStT4tftKfEj4y6S2h6hFttLT79fS5VxJDI+B8Rl2KXJVmfN5nw7Wzfi7D5jhaq9lA4OiiftRX4tThesvU/Xp07Uj9Jf2Y/8AkjGhf9ea/wDoAr0OLtXnX7MX/JE9A/68If8A0CvRYu1f6H8M/wDJP4X/AK9xP4mzz/kcYj/HIkooor3jzAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAIZfuV8Xf8Fkv+SVeHP8AsPf+21xX2hN9yviv/gse+/4WeHU9fEP/ALQNfUcEP/jJsN/iPzjxW/5IbG/4D85m3r0FHmOyb6PszyvzXRfDr4Z+NfiX43sPB3hLw/8A2h9r++a/sXGY3D5dhPb4g/zmwWFxGNxcKGGjebMRbOM/fmxUFxhOY3r9CfhB/wAEjvBum/8AEx+LGvnVD7ivQ/Gn/BMD9njxFpHlw+Hksfda/McV4scOUcR7OKufteV+A3F2IwHt63/gB+WeH8vNexf8E+sj9rbwcf8Ap+uv/Se4qX9sH9jjVv2UtcsUj8R/2lourvt08HtSfsCWX2P9rzwYP+n64/8ASe4r6XM8zwOecGYjF4X4OQ+RyLI8dw7x7h8Bj1yT9ofsVB/qE/3KKbDzEp9qdX8ePc/0gpfwkfPH/BTf/k0jxD/1zr8lfn9q/Wv/AIKY/wDJpPiL/rn/AFr8ma/pHwV/5E1X1P4m+kl/yVOH/wABHJ9+vtv/AII2f8jz4s/69/8A4zXxJJ9+vtz/AII2f8jz4s/69v8A4zX0vib/AMkpX+X6HxHgl/yX2HP0TXqfrUVzUq9T9aingBGRX8gH+iNTY8b+Ov7G/wALP2hfF+m+MPHUe6809fkVaTwL+xj+z/8AD0/a/C3gGJJB6L/9lXGftift7J+yx4x0/wAHw/D7+0GvLBrvf/aK2+Nrba+f/EX/AAWI8Z36eXp/w0Wx/wB7Ua/Rsq4d45zPLYTwt/Y+uh+L8RcXeGGS5rV/tBL6x8z9AYNFtdJT/iXxQrSan4m0PQ9Na61TXVAXq1flb8SP+CjP7T3jlMaXry+H/wDryS4/+PV5j4q/aF+P/jLdpvij4yanfWWfu3d9tr3cv8Is9x01LEVD47H/AEhOG8tp+yy2hzn6F/Hv/gpX8G/AOiXtp8PfEDa3rSj5Y9k3kr/6L/8AHa+Avjr+0b8Tf2ifGn9v+LDtsP8AoF1wcT29l/q4zu96b88r9K/XeF+AMjyBe9rVPwPjHxY4j4x92f7qkOoqH7TS/P7V9/ZJH5WtZXPU/gf/AMgXUf8AsI121cT8D/8AkC6j/wBhGu2r/Eb6Rf8AydvNP8Z/u/8ARu/5Mvlf+AKn+f2qCjz/AGr8ToX+twP3KpRr+zZ+kX7NIRvgtoG//nwFcP8Atf8A7SuqfA6TTrTR/mvLs7Uruf2Z1DfBXQOOfsIr5d/4KPf8lP03/ryP/tvX9lcYZ3juHvDuli8N/EtA/l/hnKcLnfHlXCYj4Lz/ADM3UP2//jRcDrpen/U1Pp//AAUB+NGmDrpeofSvCfP9qK/mn/iIXFft+b62fvX+o3Ck1y/VD6h+Hf8AwUV1/WNc+wfEDRNO0yz+q/8Ax6vpLTdX8FfGPw8upaaE1Czu06j+GvzMr6A/YK+I2taX8Tf+FfE/6Dd2G+v1DgHxNzHMs0/szOP3sKp+e8a8AYLLcDLHZb7nIZ37Yn7MP/CqNbPjLwpHjRbv/kKV4hP2r9LfjJ4Bg8efDHUNB1T+JM5r82NQtxpf9o6b/wA+f2ivmPF3hChwzmqxeHX7qqe74YcS185yr2GI+OkfZv8AwTqQf8KdvrH/AKfjXS/t4p/xYHUMHtXm3/BNjXEbSNc8PufuSV7V+1F4dHiz4MeItNPexuB/5Ar9u4c/27wq5Y/yH5TnNsJ4j+2l/wA/D84LapqKK/jXFUfq+LdM/qKWtKIUUUVBdKoFel/sjW2f2gdBHtXmley/sJaN/avxpsL7P/HmK+t4Dp+24rwX+OB4XGdb2PDWI/wH3tcw+XZHP/PLJr80vjli5+M2v4P/AC/XFfpFruqCDQpL0f8APOvzH8b+IP8AhKPGeoeIB/y/X9fuvj5XoUcrw9E/F/Bqk55liKp9c/8ABN643/Da95/5fjXY/twRbv2fddwe0H/pRXm//BNrVvL0DU9G/uXxr2b9qjRx4i+CuvaZ/es2FfV5J/tnhT7OP/Ps+ez5fV/EG8v+fkf0Pzf/AOPeii4tvstFfxnUotYtn9S0HemmFFFFR/FFU/jBXpf7Hdv9p/aF8OfWf/0nuK80r2/9gXw39u+NS+IgP+POxH/oivsOA6PtuK8HT/vnzvGtsPwxiJf3D7wk3pGfYV+ZXx4uPtXxs8R/9f8AX6W6hfC00Jrr2r8tPGGsf29441G//wCn+v2/x8qqlgMJR/xH5B4N0fa5hiKv9wp1NbVDRB3r+a8F/FifvGK/3Rn6Ufs9ybvg/wCH09NMtv8A0nWum1HUNFtE+3ap6cVzH7PMWPhFoGP+gbbf+iVr56/bv+OHi7RfGA+G2jzfYrE2H2vUZa/uPMuIsDw3whSx1f8AkR/JeX5LiM+4mqYSj3f5md+1l+2GfErt4C+H5/0RxzqY6V337EH7QY8d6O3gDxaf9PsxzXxgYM960vA/i3W/hv4z0/xfo/8Ax+1/O2U+KOcR4r+u4h/uWfuOP8N8DLhv6rh/4p99/tM/A/RfjJ4Max8oLd2nNkR2r8+Nb0c+Ftc1Dw9qo/02xr9H/gt8WdF+MHg2z1+wcMuzcK8J/bl/Z1+1aT/ws7wnw3/MT+lfo/ijwph+KstpZ5l/2D4LgDiOfDmbf2ZmB8lW1TUef7UV/LdZWqWZ/RimmuZBWt4c8F+MfGqHw/8AD/QBqF6OpJrHZNhXivq//gm3o2i32i6/qDgNdfb/AN5X1nAeQUOJ+Ivqdf4D5XjPN6+QZF9bifNE8HjL4Uax5kf/ABL9btK9Y8K/t9fFHw6P7L1XQNOv/wDceul/4KNeGNA0nXvD95EuPtYuP/bevmyvZzfMM38PuI6mDwFfSB5uU4XJ+N8np4vFUD7R8D/8FAPBGsgf8JNElh/v16f4X/aJ+DfjCPGkeO03enmV+cv2n3o0+4/sH/T9HH9m31fVZN4453D93iqUD57NfCTJ68+bDS5D9Q7+x8P+IdJNsyRsuOoFfMH7WX7Jmk6fojfEH4fx7V/5iGmf8u7Vwf7M37UXjXwt4wsfD/ijxH/aFnfX8Fkj3t9X25d28fiHRtgC/ZrtM4FfrVKtw34n8N1XGkvaH5licNnvh5ntP97+7Py1orqPjF4c/wCEJ+Juv6Gv3bS/3CuXr+PMfl/1HN50P+fTP6WweN/tHAUsR5H6R/sy/wDJE/D3/YNhr0T+Na88/Zl/5In4e/7BkNeifxr9a/0G4c/5EGF/69wP46zj/kb4n/HIkooor3jzQooooAKKKKACiio/P9qAJKKq/wBoe36VN5/tQBJRUfn+1Hn+1AElFR0ef7UASUVH5/tR5/tQBJRVX+0Pb9Km8/2oAkooooAKKKKACio/P9qPP9qAJKKj8/2pPtY/uH86AJaKj8/2ooAkoqPz/ajz/agCSio/P9qPP9qAJKKi+1j+4fzohn30AS0VH5/tR5/tQBJRUVvcCcVLQAUUVFcXAgFAD/L96PL96b5/tR5/tS5kBJRUfn+1Hn+1MCSio/P9qkoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACio/P8Aajz/AGoAkoqPz/ajz/agCSio/P8Aajz/AGoAkoqPz/ak+1j+4fzoAloqGGbdU1ABRRRQAUUUUAFFQ3Fx5FL9rH9w/nQBLRUX2sf3D+dL5/tQBJRUfn+1SUAFFFFABRRUdAElFR+f7Uef7UASUVH5/tR5/tQA7y/ejy/eq9zqH2fqKkmm20uZAPwPUUYHqKg/tD2/SpvP9qZPNEkoqPz/AGo8/wBqCiSio/P9qkoAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAobofpRQehoAgf+L6V8U/8Fjf+SW+Hf+xg/wDaBr7Wk6n6V8U/8Fjf+SW+Hf8AsYP/AGga+n4J/wCSpwvqfnHiz/yQmM/wH50x3W2bNfol/wAEivhVpNv8Mb/4n6nGPtmo353ue1fnnHH5O6v1M/4Jg6lpF/8Asu2MaHi0vp6/ePFiviMPwrGP98/lH6P+X4PHcbc2I+xA+j7tvsvFcx8SPi14I+F+it4g+IHiBNPsh611d8fKRpBy3avym/4KQeLtW1j9qLUfDWra7/oFpY27bR/171+CcJ8PviTNfqtz+r/Ejjd8C5H9bw9Lnmeg/wDBSX9qT4O/GnwdoPh3wB4hj1C6+3Dy1T6xV4x/wT65/a48Gj/p+u//AEnrxyvbP+CdmnjUP2u/Dr6V/wAuf2j/ANJ6/ovG5HQ4b4CxGEpSP44y/iPF8aeJGHxtaPvznA/Xxf8AUr9KkqG26Ci5r+UJ7n+hlNWij57/AOCmFz/xid4hH/TOvygtpcHmv0o/4K1eLE0H4DSaEOmtXar+sVfmiqv5myv6X8H8HWjw/KS/mP4U+kTjKeN4x9j/ACQGrv3f4V9uf8Ebf+R68Wf9e/8A8Zr4kf8A1v4V9t/8Eav+Rh8V/wDXsP8A0CKvc8TP+SUrny/gl/yX+HP0VoPQ0UV/Ii3P9E+h+an/AAWF/wCS36B/2BP/AGtNXx9P2r69/wCCx58j44aB/wBgL/2vNXx78/tX9i+HTvwdh/66n+cvi9D/AIz/ABgbpf8AJo+f2o+f2o+f2r7vY/Jw+f2o+f2o+f2o+f2oC7D5/aj5/aj5/aj5/ak9hrc9T+B//IF1H/sI121cT8D/APkC6j/2Ea7av8QfpFexq+Lmaf4z/ez6NH/Jncr/AMAVDcIByB71JHcaOB+8fdTh9a/IaGGftYH7hUmqdKr+9P0j/ZhP/FlvD/8A14Cvl/8A4KPf8lP0/wD68j/7b19Sfs32/wBn+C2gD/pwFfMn/BSPTNatvG2na4D/AKIiXBf/AMl6/rTxApN+F9JLtA/mjgmpTXHspN9ZnznRRb29Ffx97OvVZ/TkHewT16j+yBZjUfj9Yp/sV5b9j+2f6A9fWv7D3wA17wxqEnj/AMVQfYWMUG2P+9X6b4Z8OZlmHEmHr2/dI+G4/wA1wGB4fq03V98+m/EuItCvM9PseK/MLxv/AMjpqP8A2Eriv0C/aZ+JmkfDP4bX+pFwLm7/AIfevzqhb7R1r9C8ec1w/tsPgj4LwbwFfnq4iWx69+xN8QP+EX+Mtjpw/wCPLWRkV95a7YRa7or2Dj/j6Tivy207UP7L1zTtS/5fbG/4r9Ef2e/jJpHxc8GWOo6fKjXPAvV/u16XgzxLQxOXzyfEP/Aeb4sZJiMNmUMyoI+Fvj98Oh8MvifqHh8d+a5Gvur9r/8AZwT4v6IviHRP+QvafcNfEOs6PrfhfWv+Ef8AFnhr+zb+vy/xG4Ox+SZ5OpFfuj9D4H4sw+e5dShOr+9RToot7eobj/R/61+bU5XfJY/Q701W1ZNX2D/wT1+F50TwbfeMtUHOsndXhH7PP7O3jL4zaxYvqkf2DRlTd9vi+81ff/h3RtH8HaH9i0/i2tEr+gfBvgqvDF/2xi6XuQ+A/D/FHimhWp/2ZhzkP2ofiDH8PPg/qGv55CZr837avf8A9un45f8ACwNXPw+8LybrS0/1j14NXyXjDxBQ4h4ihQw/wQPovDHI3lOS+3xH/L09m/YT8dR+FPjOtlrJ/wCQtZ/ZR/5L190a7p0esaNe6cDnePkNflvp+of2Drn/AAkOlH/jxr9E/wBnv4waX8Xfhvp+v+Yn2nYv21a/S/BbiXD4zKauR4j7B8H4r5HUw2bUszw6Pg74weEj8PPiV4j8P6j/AM//AP6O/fVykM3nc4P4191/ti/s3/8AC2dD/wCEg8JALrVn0r4b8Q6Brfh7WT4f1Uf2be1+S+I/BWP4azZzgv3VU/TeA+LMDnuUqjN/vUR0UXFvUNxcV+dqTvypH294Kt75KCHHFfZf/BPf4dHw/wCEdQ8bamMPfXjOK8H/AGd/2bPF3xX13T77WPD4/sT72K+87Gx0Pwtof2HT8fZLT79f0L4RcDV6OL/tjHfAfi3ilxZRrUv7JwpxH7VfxMt/hz8GtS1yP7xH2Wvzx/49691/bh+Np+IfjNfBmln/AESx+/XhVfG+Lef0c/4gnQw79ykfR+GeQPJMj9viPjqhU1tUPn+1Gn/6L/xLP+Ebr8vy9P63Spn3uKa+qM/Sn4AD/iyvh3n/AJgtv/6KWvkv/goYMftBY/6l+1/9KLivrv4Gwala/C/w/a6mnzCwgU/9+a+Sv+ChUPkfG+yH/P3oWP8AyPPX9YeJVB4jw3pf9uH87cBVFDjr/wADPBKKhuLipri3r+TK1Bx+LQ/pWjNUz1n9kP47f8Kc8afYdXONFu+hr7rkOh+NtC/duPstyPyr8tftH/MMzX1/+w58chrek/8ACsPFvy3tp/x5Zr+gvCLjijGn/YWL9/8AkPxHxQ4WUH/a+F+M8S/ak+BWt/Bzxn9vOP7Fu7//AIlgrzOv0m+OHwo0T4sfDXUPB2rx/fs9v4V+dPi7wVq/gbxnqHh/xT4d3XdfJeK/A88izX67h/4VU+j8OeMKGd5V7DFfxYGfX1j/AME2pM6frFoD92b/ANkir5On7V9U/wDBNaL59c4/5a/+yRVyeEipYfjTD3/kOvxIanwpX+Q//gpNo/nz6DrnPyRz/wDtGvlODPOa/Sb48fDDRfiv8Nb/AMOTnl7P5K/PHxx4H1v4Ya5/wj3i3/iW19H4z8M4qlxB/aKpe5M8bws4mw88j/s5/HAx6KP+wtRX4jOm77H6wpreRL4V51nT/wDr/t6/T7wQHTwZp3/XpAa+B/2WvglrfxL+J+n+IT4f/wCJJY33FfeXibxNpHg7wXfahqhC2lonWv6g8FsuxGV5LiMfiPcpH89+LWYYfNMzo4XD6s+B/wBqm4F18ftecdDfV51Wx4/8Tjx14z1DxcP+Xy/4rHr+es8xdDHcS4itHuftOR4N4HIcPRfY/SP9mP8A5Il4f/68If8A0GvQ4+q/Rq88/Zj/AOSJeH/+vCH/ANBr0OPqv0av7y4b/wCRDhf8ED+Q88/5G+I/xyJqKKK9080KKKKACiiigAqrc1aqrc0AcJ8Sfjn8MvhOLP8A4WB8QNL0trsfu/7Q1H7Nvrmh+23+y93+Nnhf/wAG9vXzX/wWJ/Zn0HxL8Nr79qNfEGp/2h4csNPstO04H/Rz5l+q/N/3/r8wbi51e150fNfqnCfAmB4myqWL9tbl3PwXjnxKzzhbPFg40viP3U/4bi/Zixvf44eEt3b/AIqC3roPAf7Q3wr+J63x8BfEfS9Sa0+//Zuowz18CeEv+CLUni74a6frj/GDWNN1m707mw8xPsn2z/vzXy9+0t+zh8bP2OfGg8P+LPEn9m2N/wD8gvVNP1Goy3g3h/NsRLBYfF/vQxnH/GOT0KWNx+E/dH7rPqEcy5jw49c15l4p/a4/Z68H6u/h/wAT/GXRtPvLf76S6lb1+df7Af8AwUR+KPg7/iw/xFc39kNDn/svVb1/+eNvcXFeIfDf4L/FH9ub42eItS+HX/L94huL/VNU/wCgf51xU0vDv6niq9LMq3JSpfbPQxPivDHUMPHKKPPVqn69r+2r+y9/y0+Nfhf/AMG8P/xVR/8ADbP7LnT/AIXh4X/8G0Nfmz+3J/wTm0T9kT4bWHj/AEv4h6tqV9d3wss6geua+aPB+jp4o8bab4M1XxD/AMf1/b16uVeG+RZtgfrOHxf7o+bzbxX4jyfNVl1eh+9P28P7bX7LQ6fG/wAM/wDg2h/xrsvhZ8V/BHxW0j+3Ph/4k0zU7M/8tdP1H7TX5ufG3/gjt438G/DD/hMvgv8AEPVNfvfsPGmahJ1rS/4Ii+Nx4N+KPjL4PatNsv7s2/8AxK/+fDyftHn187mHCuR/2JVxeX4nncOm35n1uV8bcRw4lpZbmlDkVU/UOpKq21Wq/PT9hCo5+1SUUAZd/cx6bG1/J0ryzVP20v2Z9L1R7DU/jVoqvbff3alb7a9D8V6HbeKNKbQtX/497pNrV+RH/BSX9jLwT+x/rfh/Ufh34j1P/ip3ulP22Td/Fbr/AO16+q4UyXK8+x6wderyzex+e8c8Q5zwxgfreHpc0In6bL+2x+y+MBPjV4Z2/wDYYh/+Kr0fSNWtde0dNV0yf7dZ3X3GDV+CH7O3wvj+NPxs8PfCzVv+PDWr+v3Y+E3gDRfhn4G034daHJ/oekad9kSurjXhahwxWhQ5rykcfhxxfmnF9Cpia9P3DsYO9FEHeiviz9OgN2D1qhfaqmm/6Xv/ANH2Vf3j0rjfit4Dg+J3gbUPAeo641h/bNhcWm60/wBqnQVN1Eqpz4l11h70Tk7r9sn9l6DVm00/GzwurWnX/ibw8Uw/tufsvdR8bPDX/g3hr8cP2rfgvoH7PH7RHiH4V6fr7ahZaL9n41D/AKbW/nV2H7Bv7HA/bH8can4e1HxH/Z9hodh/zD/+m1fsL8Ocpw+SxzOti/3TR/PsfFfiKtntXLKGF98/VtP23P2ZBtz8YtF/0r7n/E3t/wD45Xpula9omqof7NlT2xX5Z/tB/wDBGz4qfD/QP+El+E3xBbxA393U9v8A7LDXzP8ACD9o/wCNnwU8aaf4y8JeJNU/0H/mF6h/pNedhuAcrzvBTrZVi7no4nxOzvh7G0qOb4Tkufv0RGRtz970pvl7o2T+KvGf2Lf2g1/aT+CmmfEERot1dj/TkHavasc7z0r8zxWHr4LEuhLeJ+05fjcPmOFhiqP2h0HepKjg71JWR6AVHP2qSqt/NgYFAHHfEr4xfDT4TQi78d+LtM0r7X/FqN+sGa5Aftt/svN/rPjZ4X/8G0NeEf8ABWv9mfRfif8AC69+N/8Ab+pC88FabcahHYRn5X+Uf/GK/Ki4ufstfpfCHA+B4ly11/bfCfhfHfiPnXC2dKhGl7p+6H/Dbn7Lw4Hxr8M/+De3rd8C/tE/Bj4qXr6d4C+Jekao1r9/+zNRhn/9Bavz6+Dn/BHdPih8GfD3xP1P4z6rY3+teH7e/KpIn2cedb+d/wA8fevnX9pf9lL41/sYa5p//CWeJdU+xXf/ACC9U0/Uq0wvCHDuZ476lgsX+9DF8f8AGGU4CGY4jCfuj9zoryJ4v3cgapo+9fkv/wAE2v29/G/gX4pab8BviT4gOpaLq7/YtK1TUDiv1isLoXMXmV8dxJw5juGcd7DEH6PwhxbgeLsD9ZoFyio6K8E+tJKKjooAkooooAKKjyB1NFAElFGR61HketAElFR0UASVHP2oqSgCm0W5eHrF8deLtB8BaQ3iTxHrSWNlbjc8j/dreICZSvH/ANsj9nOD9p34Vt8Op/El/pUf2jc8un/KTWuFpUK2Mgq0jy8xrV8PgKtWh8ZCf23/ANmW4tvtcfxv8L9Ov9sW/wD8drf+H37SHwT+Jerf2N4B+JOl6leInzrp1/DJX4afGDwP/wAKm+J/iH4Wax4k/tL+w7+rnwI+Mv8Awon4n+Hvip/z53/av2R+FdPEZZ9Zw1Xofz5hfGzHUc6+rYmj15D+gBsMWTPGOKzPEGu6R4W0N9d1icWdtbJyWpnh3WY9c0Gx1zT/AJhcpXxj/wAFpfjzceFvg/ZfCHwrcD+2tdvFXYP4bb+I1+UZLleKzbOf7OS6n7dxFxDQyfIZZn/cPog/twfszY/5LZ4Uz/2FLf8A+O1q+BP2n/gL8RtYbw/4Q+JOj6jedxY38LN/6FX4Lfafevuz/gk1+xanjjVrD9pfW/EwC6Nf407TrH7o8m4r9M4j8N8u4dyn65Wqn5Nwn4qZzxPnkMJRpH6nQVJVXT6tV+Q6dD+glfqFFFR0ASUVHRQBynxN+J3gb4XaH/bvxC8R2GnWA/j1B6+d7z/grn+x7pvia+8H3XiS/CWNztl1JXh+y7v9mbzqx/8AgqN+x8Pjr4Qb4pj4g6lpt54c0X91p8Z/0dv3u7c3/j1fkJcf6Zodfp3CHBeV8Q5VVr1qusT8O498RM74Zz2lhKNL3JH9FvhrxBpfiHSLTWdKO61u/mStFjn5Ca85+AN39g+AOiXz/wAGhJ/6DX5oftE/8FU/2mta+KGqeH/Bev8A/CN2Wj6lcWTnT/s/zeTcbf8Alv8A7tfM5Twljs6x9XD4L7Fz7PNuOcu4eynD4vG/8vT9cnZvlaN/lqz/AMs6+O/+CXf7bPxK/ay0bUrH4keH9M+2aP8AK+pae/ytX2IjgjArwszwFfK8dPCV/iPqclzihn2WQxdD4ZE1FR0VyHqijofpSUo7/SkoJl8JXuOPkrL13XNH8N6O2o6pJ9itbYbnZztxWzOcJvrgfjz8MNJ+Mnwr134dajrMlimuadcWRltG+Ybq1oJOulI58a68ME/YnPSftp/sv2//ADWvwv8A+DaH/Gp9E/a+/Z48SawnhzSfjLo32y4+4g1G3r8SvjX4C1f4PfGvxD8LdY8Sf2kui31exf8ABOL9kfW/2mPjO2q6x4l1TTbLwvf29/GLJ9vNfrmYeHGV5fkX9qe33P5/yvxV4gxvEf8AZfsT9n5b3zxnZurD8ffFHwT8L9C/4SHx34gj06y7teGrukWEei6ZZaMf+XYL2rxH9v39ljRf2o/gte6Vq4P2vSEuL3Sz/tba/KsFRoYjHqhWl7h+55picdh8p9vQp/vDqLf9s39l66OP+F0eF/8AwaW9eq6fKLmM3iV+Fn7KvwEj+M/7Ttj8IfGHiT5Uvrpn/s//AKY3Hk1+3XhbQtI8M6PYeG9L/wCXNeBX0fGPDuB4brUqNGr8Wp8XwHxRmnFDq1MRS0gdICXOTxSLsi3bun1r4r/4KSf8FCfib+x9408O+EPh54A07Vv7as7hv+Jg9x8u3/dr6W/Zz+JGo/Fr4KeH/iDraJ9s1ew8x/sn3a8HFZTjsJg6WMl8Ez6vB8QYDM8zq4Kj8dI9DqSq3z+1Wa84+gCik3r60uR60AFFR0/evrQAtFFGQehoAKKKTevrQAtFGR60ZHrQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAQN91q+K/8Agsj/AMkv8Pf9jD/7QNfajfdavi7/AILJ/wDJK/Dn/YeH/pPcV9TwQr8TYf8AxH5v4sf8kPjP8B+cXz+1faP/AASw/aW0bwPNqHwe8XHi7v3vdOv/AOF6+Lv3i0tuP46/qribh+jxDlE8LWP4M4N4pr8IZ7DH0T94Le+jvYvtCdMdBXyv+3B+wA/7ReqL4z+H3iT+ztaA+/XzV8Cv+CpHxU+Fulf2H8QPD/8AwkVsv/ILO/7PN/6Jkr6N+G3/AAVP+Cvi2Py/GCxeHrz+7JqPy/8AtOv5up8LcZ8LZn9awsD+xZce+HfH+R/U8yq6nzCP+CXn7T0ur+Z/wjZ2/wDYRt//AI9X1L+wp+wnrf7NkmoeK/FuvadqWt3/AM29V+WvVbH9sz9mSSP7X/wuzwsq+/iS1/8AjtZHjH9vb9l/w3B9sj+M+kXy/wDUN1S3n/8AQWq814n45zyh9SlS91+TOPIOD/C3hnFQzHD11zw/vnuMEKWibP4azfFHiLRND0drzWJALfHSvjLxv/wWH8FaR/oHg/4eNqX/AHFPs/8A7Rr5s/aM/b5+M/x+lbw/HH/ZujP986fqNZZJ4b8SZliF7elyI9jibxt4UyzCT+q1eeqaX/BQf9qPSP2i/iauk+FpPM0fQ+r/AN+vnuJnWVeKjuM2Z/s2l+f2r+ociyihkWU0sHRP4i4nz3G8T5lVzGv9s2fC/hHWPHniKx8PaHH9vvL56/TD/gnj+x3rf7Nmkah4g8W655l7q8nNfnT8Bfi1q/wN+JVj480/w3/aS2ibSK+s7f8A4LUm0gEK/BTGBj/kYv8A7TX5p4kYfivMF9SwNK9KZ+s+DeM4JyXEf2jm9W1WHwH6D7m/55iky/oK+BP+H1Un/RFf/Li/+00f8PqpP+iK/wDlxf8A2mvxn/UHi3/oHf4f5n9Nf8Re4G/6Cz2T9uj9i0/tRRafqml6/wDYLux+59qSvzg+MfwQ8Z/Azxv/AMId4skzkV9a3H/BagKDGnwXzn18RD/4zXzN+1D+0/rf7UfjPTPFup+F/wCy7Kx/hGo/af8A2jDX6z4eU+NMqqQwmJpfuT+efF7MPD/PKE8wy+r/ALRM8tn/ANaaPn9qPn9qPn9q/bz+Zg+f2o+f2o+f2o+f2oAPn9qPn9qPn9qPn9qT2Gtz1T4I/wDIE1L/ALCVdrXE/A//AJAuo/8AYRrtq/xI+kHZeMePqv8AnP8AeT6N9/8AiCuV0l/IfX/wX/Y2+Geu/DexvtZj/wBKu4/vVt6P/wAE+PhXpmrrqesH+0P9+vnbwB+2D8Z/h7pH9haOdM/CyNampftvfHq8OX8QaZ/4AvXsZfxd4bYbAUvrFH96a43hXj+tjqvLW/d+p92aPpcPh/SU0zT9ot7ZNqCsLx78KvCXxQ0j+zvE8Ivk77xXw3J+2f8AtBx/c8SaZ/4AvV23/ba/aDtz8/iT/wAp1fZVfGPgbEYX2GIpT9l/gPCh4WcVUq/t6NWHMfQPib/gnz8K75d+jg2P+7Wbp3/BPXwHB/zMWq/99r/8ZryK3/b4/aDg6nTP/BeamH/BQb4+jp/Zv/gvNfM/64eEXtfafVJ/+AHrQ4a8S6VP2ca3/k59OeA/2Wvgz8O2XV9K8O2AvLQf8fzR/drQ+I3xw8EfC/SGutX17Tlwn/Hh618beIf20fj/AOK5fsh19NNs/wC9p6V5nq+sa3r+tf2nqn/H7/1EK0zDxc4cyzC+yyehyEYLw1zzM8R7XN6x3H7RHx71T41+Llu4MrpyfKledwd6Rl3Utfz3nWeY7P8AH/WsQft+WZZgcmwEKGHCuu+Bnxj1f4HeM/8AhINLG7T/APmKVyNInT8ayyzOcVkeLpYzBf8ALo1zPLMPm+AnQxB+j3wf+PPgn4s6GL/S3wf+n8U/4jfAD4YfEk51fQrBrvH3tlfnX4f8Qa34X1z+09G8Sf2bXsPhH9vb4z6HH5eqSaZfr/sPX9HZX4wZFm2B9jnFLnPwrMfDLPcvxXt8oqnpOqf8E1tEl/5BfiB1Wuk+HX7A/wANvBGq/wBpeJf9Pb/bFecQ/wDBSnxs4wfhyf8AwZf/AGmqF1/wUV+JzjGj/Dyw0/8A35m/+M0v7b8JMJX+t+wOetlXiXi6fsHI+udP07wZ4J0Q2ulw2Fhafdr52/ag/bO0iDTr/wABfD6Tbe3ifJf/AMNeC/EX9oL4m/ErdYeLPEn+hd/7Prhf+PevB4u8YVVwv1LJ6XJSPd4a8LpQxCr5lV55h5/tRB3on7UV+B1JzqPnZ+2ShThTVBEP2b2rufgd8atX+DHjP7dpf/Hlec6hplcZRXZk2c4/IsfSr4f4zhzDL8BmWE9hiF7h+kPws+O3gb4u6ML7RvEHDVB8SP2fPhF8UJjLq+hp9px8t95f/s1fnj4f8T614Q1r7f4S8R/2fe17F4Q/bt+M+iJ5Y/szUF/2ZK/pHLvFvIM1wKo5/RPw3M/DLOcrxft8nqnp2p/8E39BuOdL8R10nw8/YR+GfhD/AE/xRjUG/wBuvM4f+ClfjQ8D4aqP+4l/9pqlrv8AwUY+J8wxo3hvTP8Awa//AGmqp554R4Sv7f2JhWyrxNxtH2FaR9c2Fv4N8BaLxHp2nWWOK+bP2sP2ytNuNJ1H4f8Aw+l/0vy/+Qjj/Rx+NeGeO/2i/ib8QR/xVPiDb/1C68/t7f7LXhcX+LscVgPqWT0+SB7XDXhjUw+IjjcyfOyb/wBvqLe3N1/xLamuLeof+PevwShO+M9vij9ncP8AZOSB90/Df9jn4LN4KsZNY8Ppf3NxYW4dnrW8PfsX/A/wxrv9u6R4fG7uK+YfB/7bfxn8MaRY+HydM/0Sw/58jUOpftufH5uYtf2/9w6v6QwvHvhlh8NS/wBk96l/cifhVbg/j/EYir/tOn+M+/LeFrGIRRRhVHauK+KPwC8D/GVP+Ks0IN+FfFzfti/H6T7+uJ+VWtP/AG4/j9Z8f8JJpf42L162K8Y+Csdh/YYilP2X+A8XDeF3F+Cr+3w9X3z6U1f9i34M2nh2+tYvD6be+a+LNL8FaJP8Tz8Pj4l4F/XoviD9uT4z65oxss6dk9f9CevJNP1DW9O1n/hIf+X37fX5pxrxXwVmtTCwwFDQ/ReEeH+KMBCt9fran3vpH7G/wUHh1NH1Hw4GV4xWj8L/ANlP4R/DXWW8QaNoafbf72a+Wrf9vf8AaCstHWxB0zp/0DzWbP8Ats/H+fmPX0X8K+7oeIPhlg5xq0MJ7y/uRPicTwLx5i+f21bT/GfoFsVx5YT5f9+uI+JH7Onwz+K4/wCKs8Pj8a+Lf+Gxfj6Of7cT8q0bD9uP4/WvB8R6X+Ni1etjPF7gLNKPscRSnP8A7cPPo+GPF2A/fYeqfQHxI/Yz+Ddr4O1C00PRBp9z9h2nUNlcz/wTg0wadpWvpn/l/fFeO+MP21PjH4i0kaLu03/Sx13msH4BftJ6t8B/t0mleHX1L7W+dRxXy6444Lo8T4fFYel7KnD+4fR/6ocXVuGMRRxFXnfqfd3in4z+D/BfjHTvBurv9he8+5u+WnePfhr8Mvizo/8AxVWg6dfj+9hTXwP8c/jjrXxy1nT/ABDqiHTzZ1q/DT9qb40eAdtjp3iT+0LTsb4817U/GHhvMMfVwuPpc+HPIp+FufYfAQxWGq8lU+hdY/4J7+CtTf7bpHiXVLFv9j/9zV/wX/wT4+F/hjV21HVD/aJPe++avL7L/go146tx/wATT4f7f+4l/wDaabe/8FGvGNwf+JPoVi3/AG3f/wCM0v7f8I/b+39kU8m8Sqq9h7U+rdK0zwX8K9C+w6RHp9hZj+5Xyn+2T+1BovjmT/hWPhf5rT7dt1T2FebfE/8Aad+KHxO/0DV/EY+wnr/Z9eb21fJcZ+K+EzDAf2bk/wC6pn0PC3h1UwuKWNzJ3mTUUUV+F0m3WTZ+zNJUrH6R/sx/8kS8P/8AXhD/AOg16EnVfxrz39mP/kiXh/8A68If/Qa9CTqv41/obw5/yIMN/ggfxNnf/I3xH+Nk9FFFe8eYFFFFABRRRQAVVuLerVRz9qAPmT/grjaZ/wCCfvj9B3Gn4/8ABhb1+LWs/wCmdK/an/grUc/sB+PF9rD/ANOFvX4r/wDLH/gdf0L4S078KYy38/8A7afyT42VEuM8L/gh/wCls/oC+D0kh+GuirjpYivkL/gt7F4dn+A2jf2h/Z329vENr9i3f6/7Nt/f7azPEP8AwWR+GPwo+G2m2Xg/w/8A8JJe/YPu/wBpfZv/AGjJXxl+0F+0b8a/26vGa33/AAje7+zvtH9l+F9C/wBL/wDRNfI8M8K5lR4o+u4l+ypRlc+04w4zy3E8IrLcOva1bI8/+GfhT/hMPip4e8NEf2h/p9v/APb6/dD4J/s//DX4JaGdP8AeG00wXX3/ALGNtfF//BMj/gnfrvhCXT/2gvjrv/tC0T/iV+G77S/s39n/APf6v0ViGQVX04rl8TeJ6eb5n9WwtX3Eet4RcH1Mny363io+/I+Hv+C4sX2f9mDT/wDsOivzQ+D/APyWjwZ/2Mlr/wClFfpf/wAF0v8Ak2vQ/wDsPp/6Ca/ND4Lf8lo8Gf8AYxWv/pRX6J4br/jBp/8Abx+VeK1/+IkUbf3D9+fD1oJNFsYz0W0281yHg79mv4L+B/iVqXxg8NeDtP0/XNQG3UdRtE2s9dt4bULolkM8GzgP/jtaEoyCHr+d6lerCpUUWf1bSwWHxFOjOsveghPs3tU1FFcx6gef7Uef7UVDc0A2kSfu6/N3/gvfKIh8PXH9/Uv/AG3r9D/7c0e6l+wb/wDgNfnb/wAF7Dlfh8c/x6j/ACt6+v4CpThxXh7o/MvFLEQnwdiOVnyN+wRcZ/bX+Hnv4g/9t7iv3StpentX4W/sAcftsfDz/r+/9t7iv2z+IHiSPwT4K1TxfqWCuj6dcX7/APbK3bNfZeLtOo8/pR/uHxfgbifq3DeIlLpP/wBtLniPxz4M8FQ/a/FPiCw0/wD6+79V/wDQq8S8Vf8ABS/9k3wXrn/CN6/8TFa9/gEel3E//omGvy+/a6/bK+Jv7UnjPUI9UGqLoSX3/Er0vT9Rr7A/Zl/4JC/BzU/gvp+ofFhdT1DWNZsOWf8A0f7FXi4ng7Lshy6lis1qfxeiPUo+Iec8R5lVwuS0dKR9cfCn9sH9nv4zaH/avhP4j2Dp63f+j/pNXpPF4M1+Bvx68EaR8Cv2gvEHg34fa/sstEvv+JdqNgelfsV/wT4+MWt/HX9mTw/458Up/pskeJMVz8WcFUchwNLG4erz0qp7PBHiFW4hzKrl2IpclWkfl/8A8FRZ/s/7eXjP/uG/+m+3r2z/AIIQp9n+J/jVPTw9pv8A6UXFeKf8FQLtE/bv8b5HzZ07/wBILetj/gmH+1T8M/2W/GfjLXfiBc+UdatLRtM497jiv1vM8vrY7wzpU8Orz5IH4Tl+YUMs8VsRWxHuQhOZ+wF++23c6p2HevwT+P1joln8bPEX/CH/APHl9vr6m/aO/wCCzvjf4gaBf/Df4UfDv/hH7/7cE/tR9UbH/j0MdeA/s1/sZfGf9pLxpp+k/wDCN+KNO0e8vs6n4k1Dw7P9nP8A23r5fgHKq3CNGrjMwlyX6H0/ibntPjjFYfA5VS5/M+0/+CHMaaV8M/GF9qkf9n2xv7dkHt/pFfUHxW/bt/Zj+DsYPib4l6Yo/wCnJvtP/ondX50ftc/tBa38ANI/4Yr+BudLs/DEY/tTU7I/Z7i9q/8A8E3v+CeHgz9pfRL/AOMnxabUVsrPUbjT00yWx23G77P/AMfHn/8AbevHzXh3BV/a59mNTkpT+HzPbyPizNcPOlw7ldPnqR3mffXww/4KG/szfFbUf7N8KfEvTZX9dQFxaf8Ao6Fa9p0PX9L1y3+16c4kFfjf/wAFPP2VPg5+y38UPD//AAqqIf8AE6sbj+0dOB+03Fl5P2f5q+jv+CJX7QXjPxlpev8AwW8Wl9Qs9DP2vS9Uu++6vLzfg3Cw4cjnGAqe4+jPqcg4/wAc+I/7Cx9P3/5z9E949KJO1M+f2qWvzk/WzwP/AIKQQC4/Ys+Iaf8AUv3P/pPX4g/afev29/4KPH/jCz4hj/qXrv8A9J6/DyDvX9AeEtH22RYs/ljxwrKHFGFf9w/eD9jQk/ss/D4kf8yJo3/pDDXgn/BZs+Hz+y9/xMz/AKf9vtf7P/5+M/aBXnXhv/grR8Mvgv8As8eDvDfhPw+viPXLHw9p9lqGm/2j9mKeTbw/N/qZK+Tv2lf2qfjX+3L4xWKLw+zbP+QX4a0//SWNfKcMcH5pDif6/iH7KlBn1XEvHuTz4QWXYde1q1IHlHg/+2v+E203TNH/AOP/AO32/wDZlftNr37df7PPwc0HT9O+InxHsIbv7HBxGzT/APonzK+Of+Cf/wDwTB13XNJ/4Wn8c4tU0wbGtNO8Oahp375P+nivmb9s39mXV/2ZvjXqHw/8WeI9U1Rb7/TdL1Q19jnlPh/jrPfqka+tJHxGQYriPw44f/tB0v3VU/Zq8/aI+FeneDLT4haj4psF0a9sRd6dIX5b5f8A7Kuf+C37af7O/wAedVbw/wDDf4hx6heL83lmG4g/9HLX5QfAP4YfGD9s2Ow+Alh4l1KLTvCthPfadLI9xPa/9MLf/Xf9MK+oP2Df+CX3xp+DHx+0/wCNXxD8Sf2auj/aF/ssP5327d/FXwWbcI5Hk2FqxrYv98un5H6bw/x7xJxHXw9bD4X/AGf7Z+i95qmlWsX+nPt/3q8r+K/7bX7O3wct1Piz4k6eox0s/wDSP/RdfE//AAVZ/b88d6X40v8A9mb4fn+z7Q6d/wATXVF/4+K87/4Jt/sCeDf2rIdT+K3xYbURZWN/9i+wSn5b2sMJwZRw+R/2vmtXkpHZmniJXrZ5/Y2UUueqfoD8N/8Agoz+yh8VNT/s3wh8TI9//T/BcW3/AKPjWvZbHxNpGuaONV0K6W6tG6NafNX5D/8ABT39j34Ofss634dHwx1tY21xNQ3aZeybl/c/Z/8A4/XsX/BGr4+eNdWm1v4D6rcLe6Vo2itewyNfbs/vYf8A4/TzLg/L3w7HN8vq+55nPk/iLmS4ieTZvS9/+4foV4t+Ing3wbpC6n4q8S6dYR466hfLb/8AoVeI+LP+Cnn7Ing/XH8Paz8Rx9rtfvJ/Zt1x/wCQa/Nv/gob+1T42/aK+NniHwvrD/8AEl8MX9xYafYN/HXoX7CvwB/4J/8AxP8AhgL74++I9G03xUc/2rp2p6/b2+P35x/rq7v9QaOWZFSzPH1Obn6QOHE+J2LzLPZ5dlfucn85+g3wo/bw/Zh+NReLwD8TtPbCfduw1v8A+OzeXXrR1SB/3MfDL93d6V+XP7XH/BLXTfBmi6f8Yf2OfEep+JLL9xjTNM/4mNwf+ni2nhr6q/aT+OXjf9mD9jKx+IP2dB4l/s+3tN+of8uTtb18xjchy2s8P9Qq3c3bk63Psso4mzSjTxDzulyqlC/PA9k+KP7TXwT+EWiXl3428f6ZZfY03PYrfr56/wDAY23V5hD/AMFWP2K7s5PxM/8AKXcf/Ga/IrSvEDfFD40af4l+NviTU9+ueILf/hJNUP8Az5/aP39foZ4c/YD/AOCZnxK8P2eifC/4laM99dpuRNJ8YwT3P/fjc1fV5lwVkvDlGlHMZz556+4tEfD5b4jcS8UYirUyqnCFKl/P1PtL4ZfGn4V/FO2a8+H3iyw1Rf79m+a7DzI3jJPSvzg/YU/ZD+Nf7K/7c2oaAJdU1DwrfWE7HVBptxDb/wDLx5A4/c1+i1vb1+f53gcDgcb7PC1OeB+rcM5nmmZ4H2mOp8ky5Ve7gE4Jx0FWKbP/AKlvpXlrc+iqL92z8Pf2nfC//Cw/+ChHjHwYf+Yz4++wV5V8YPh7/wAKy+JXiL4b6z/y46jcbP8A2hXt3xPH/G1vUAf+io2v/pRb13P/AAWC+Ber+B/jV/wtDStAH2LxPYkcf8/MMFuK/pzIs/eBxOAwMvhq0z+LM7yCeLw2NzGH/LqsfYH/AAS5+NkfxZ/ZO0t9c2rf6G/2DUP9O+/5Kwzef/5HWvi79qHUNb/bY/4KE/8ACvtHH+haFffYsf8ATn/qZ7ivOv2Lf2tJf2Y9H8ZWIJX/AISfQv8AiXf8THref896+kv+CLnwU1jWvFnib9ojxZ4dYteJdWml39595/MuP3+38YBXydfJv9U8yx+ay/7h/M+uo54+NsswOSx6L3z4B1C2/svdY6T2r9af+CLkQn/Yy0uPPW8u/wD0omr8lp/+YhX6y/8ABFkCD9jXTOOf7Xvf/SqavY8UZupwnCUutjw/BaFSnxtOHa59gib7NxsriviT+0f8HfhRpl7rPjb4gaZYpZp+9T7eplH/AGyrxr/gpf8Ate6r+yx8KxZ+DAra3rh+x6Yw/wCXT5fvV+an7Pnwb8b/ALdv7Q//AAjfi3xHqn268/03VNT/AOPm2r8x4Z4HnmeTzzLES9lh4H7lxd4if2Rm0MpwFL2uImfqBpP/AAVM/ZF1nXf+Ec074khrr/nkNNuv/jNe2eFPiT4M8e239oeD/Eunah/16XytX5+/ttf8EzP2bvg3+zNqXxB8LxX+nXOhi12Pe6j/ANPFvXzN/wAE7fj541+Cv7T/AIe0zR/+PDxRf29hqml/9dq9GjwXledZFVzHLKj/AHXc8ReIWc5FxHSy7Naf8U/bv7agHSvM/i7+1h8AvgVpDaj8RPiVpmnbF+4R58//AH6h+avHv+CmP7YGqfs3/Bj7L4Kl/wCKo1r93paJ/rq/Lr4b+B/iZ+1b+0Fpvh4eJNT1HWtZv7f+1NU1D/Scf9PFcfDXAjzfA1cxxVXkpQPT4t8Sv7IzSll2X0va1Zn6h/FH9v79mL41fDDxb4M8F/ErdeJorM+7Tbi2b/yNDX44eZ8n2Cv0a+M//BHX4X+A/gxf+MPCfiLVBreiab/yFN//AB//APkavzqr9U8O8PkcMsxf1Crzn4p4nYziDEZnhHmtLkP32+B1sP8AhS3h8+thXyn+1H+yJ/wT61jXdR+Ini34if8ACM3eyf8AtF9BvrdW/wC+fJkr6m+DmnR65+z7ofh+Q/LeaIF/8dr8cf20vgBH+zz+0Vr/AMO7vxLqviJT9nv3+3jd/rv+/lfm3B2VvNeJcRSji3SneR+qcc5nTynhTC1ZYT2sORH6jfsH6F+yXpXg2/k/ZfudLZfu6jfpH+/b/e+WOvfdV8QaFo2mHUdQ1ZbGzg++z1+ef/BCAj+yPGOz7p1Pj8revpH/AIKJ/BH42ftAfBZvBnwU8UJpt87/AOnV89n2Uwo8VSweIq/9vn1PCmc16vA9LG4Wj/24bfxM/wCChX7Mvwn1CPTPF/xL05Xuf+fAXFz/AOiIWqn4J/4KT/smePNY/wCEb0H4mQref3dQt7i2/wDR0dfI/wAIf+CX37O3wytWuv2xvjbpMmr30e6OwvNSt7C4sv8Adnkm+avEv29vgP8AscfDiLw7f/st/EfRNTf/AEj+1DF4gt9RnP8Ax7+R/FX0mX8McNY3HRwVGpNuX27e6fK5pxxxZleC+v16cP8AAfsjonjTw34q0v8AtXw1rcd9b/wNZHdWw5cdUzX4/wD/AASj/ap8b/Dv416B8Bj/AMTDRfE/3D/cNfr0NhAkd8cV8nxPw5X4ZzT6vVZ+gcGcV0+Lsq+tcvIWaZLjyHz/AHKnHSqOp/8AIGf/AHK+egrzSPrqrtSfofhT+3Pf6Jqf7XnjPUtIP/L/AP8Atvb19zf8ELfBmjWXwY8Q/EMD/S7zXvsUn/bH/wDf1+cfxo/0r42eM8f8fv8AwmFx/wClFfpx/wAEN/8Ak17Uv+xsuP8A0nt6/ovxB9vg+AsPRXkfyb4bL6x4l1qv+M+2Ps3tWV4m0ePXNEv9DkPy3dlzW3Ve+/1TfSv51pytUUj+sa65qEl5H48fsh22i/Bz/gp9qfh7VPEY51+6sBn/AK+PtFfqd44+Mnw2+GhvD4w8T6ZZfZLH7a63d8qzAV+TWj2/2z/gq0P+x+r7D/4KJf8ABPjRf2gtVv8A45yfEZtOvdA8JTx/2c2nfaN3k+dNu/1w/vV+q8Y4DBYrNsD9dqfFBH4NwRmWaZZkeZPBU+fkmz4X/wCCiH7RmkftJftBah4v8J7NR0Wz/wBC0/7aPlz9n5r9P/2MvjL8MLL9n/wj4Z/4WFpa3g0xMWP9qW/Nfij/AMgv/QK+/v2Wv+CQWkeL9I8GfHH/AIXG5+S3vxp39l/L/wCjq+r4+ynJ8Hw1hsLVq8nJ8HnofEeGueZ7jOKMRiqVPn5/jP0iufEGlaPoraxrcy2Vr/e+7XkXxV/4KJ/so/CPUv7N8TfFDTDJ/wBOaXF3/wCk8Mlct+338C/jZ8Y/2fbH4b/BXxL5a4Eeo7v+X218nbXzB8Hf+CW37NPwejGpftffGfRmv/sPOnTalb6Wv/o7mvyvKMoyTEYH6zjazv8AyQ3P2zP+I8/w2M+q4Klb+/M+uvBP/BTD9kXx3rX9haP8SA0nbGm3X/xqvZ9H8ceD/Flr9v8ADHiPT79R96SzmWb/ANBr8dP2+fgh+yX8MBpviD9ln4kaNqWJP+Jpp2leIre44/7Y103/AAS1/as8afDH406b8BrST+0PC+uXlx/x/fwt9n/+0V9Lj+AqFbIP7Uy6p/27M+RyrxSx2F4hhlOa078/24H68+Z/zyf9KgTVoZeqfpXx9/wVZ+Mn7QvwF+Glh4z+E3iTTdOtL6+Fhqm6w/0j99/dl/hr5U/ZU/a8/bL+Jrr+z/8AD7X9R1LUNa1H/kadQ+0XP9n2f2f/AO0f89u9fNYDgvHY7KpZiqi5FufV534jYHKc7pZcqU+eZ+taaxGMIDgd8U+TVEj3bPlr8kf2u9K/bt/Y+8Z6bqWqftH+KtSsLw/8hM6hcW1v/wBe/wDrpq7X4H/txftm/tf6J/wo/wCHUf8AZWsxJt1TxQv+kqv/AAH9z/6Orpq8DYz6hDG0a0PZHDhfEygsxnl1ejP2p+nFvrsF0fLyKkkuE8vZ5ZavyJ/aA8U/t3fsI/E+wsdR+NmqeJLG8/5B2pan9o+z/wDo6SvvL/gnx+1ZqP7V/wAEl8Warbp/bNjffY9RRbuvPzPhfEZdl0MbGXPSketkPHmBznM6uWSjyYiB9BzXsXnYEbZ9aauraduZ2m59RXwX/wAFCv2jv28vCfxLX4Wfs/fBrxPJov2H/ka9N0u4uFz/ANsYa8z+NfwE/bp+BvwWb4wx/tK+J9Uv7HyL19L33H/x6qy/hn67TpfvoXmVmfHSwOLnTp4af7r4z9R5buMjHahLuOXg1+dH/BOP/gqF8UPi78TW+D37QQ0xWvh/xK9UT/R8/wDTvX6I7V9TXmZ5kOYZDjvquJPoeHeI8DxPgfrOCL3n+1SVHRB3ryT6EkooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAIR1P+7Xxf/wWU/5JX4c/7D3/ALb3FfZ03U18Xf8ABZX/AJI1oH/YeH/og19RwNpxNhv8Z+eeKi/4wbG/4D84/n9qPn9qPn9qPn9q/tWo1Y/zXa1D5/aj5/apai+f2rnc09xp1IbB8/tR8/tR8/tR8/tXOqdK/wAJ01MVW2uw+f2qWovn9qlrqVkcurIvn9qPn9qPn9qPn9qKlQNQ+f2qWDvUXz+1Hz+1F0x2dUS5pfn9qPn9qPn9qVOohaktRfP7UfP7VLVT9gPWkRfP7UfP7UfP7UfP7Uro57MPn9qPn9qPn9qPn9qd0FmHz+1Hz+1Hz+1Hz+1JtWBJ3PU/gf8A8gXUf+wjXbVxHwQ/5Abf9f8AXb+f7V/h/wDSEv8A8RYzT/Gf7zfRph7XwZyv/AFFFFfjFj989p7XQKKKKLsOSoFFFFVzMAooorP2hj7MKKKKr2rK0Ciiig0mFFFFGwBRRRWgaBRRRWdPYOQKKKKDP3gooooEvbhRRRWm5qFFFFHtPZGPswooorO4UYBRRRQbU6YUUUUD98KKKKB1GFFFFH7ikcnJXYUUUVNQqnCsFFFFZ0abN5w9qFFFFbGeysFFFFBnyVwoooqadQpfvQooorGwVAooorrozftYk1P4bP0j/Zj/AOSJeH/+vCH/ANBr0JOq/jXnv7MP/JEvD/8A2Dof/Qa9CTqv41/ofw5/yIcN/ggfxTnf/I3xH+Nk9FFFe8eaFFFFABRRRQAVHP2qSqtxcUAfNf8AwVqH/GBHxAf/AGNO/wDThb1+Lb3H3a/ZT/grb4i062/Ya8aaE8n+lXf9mqif9xC3r8a7uXZ1r+h/CuNSHCuL/wAf/tqP5E8bPYPjLC/4P/b2frj8L/8Agk5+xZ4h8I2Pi7VPhqdQvbux++3iPUPm/wDJivcvg5+yF8APgTa+R4A+G2naazdkDS/+PSVc/Zh8beEfHnwd0PUvC2upqFh9gHlyj+KvQ0b96UA+YCvxTNc0zWWLq0q1WW5/RPDmQZE8vo4qjSXwEwtQBgCpqKh+0+9eHyX1Pr4JJaHw/wD8F08/8M2aJ/2MCf8AoJr8zvgv/wAlq8G/9jDa/wDpRX6U/wDBcfXdFuP2ftO0Myf6V/bqbBX5m/DDWNF0L4oeHNX1iT+zbGz8Q297/wCTFf0t4dprgma/xn8f+K9Zf8REhL/Af0FeGl/4kll7WdvV77Qa57wdr+ma54HstS0hkvbR7ZdjDv8ALXgH/BRv9tzWP2RvCGiS+FvDen6jr2tpcNp1hfPt3eT5Pm/+j6/najgK+ZZt9Uo/G2f1JiM4wOT5AsfX+CyPqDzoymwGpVVPL2B6+Bv+CeH/AAU28cftK/GB/hZ8XNH8NWV+LHzNObRLGdc/9/JpK++Vx5e4d6rNsnxeS4v2OI+MrIM/wPEOC+tYciuIf3fFfIH/AAVb/bE8Z/sy+ENA0P4df8hzXFuFT/gPk/8AxVfXzyeZFX5+f8FwvhP4y8Y+EfCHxF0fw9/aVp4X+0f2on/Xb7OtepwjhsJieJKUcV8B4/iDi8dhOFa8sN8Z8h/AD4kftr/FH4n/APCQ/CLxJqmpX1p/p+qf8+1fSH/BcFtbbwb8Lo9UH+l41L+0U/8AAGuT/wCCT37XfwD+Beh+IPDnxW8RjT72+1L7bY37adcXKuv/AGxVqwf+CrH7XXwy/aW8X+G9E+FmvrqOlaMlx52p/wCkW+PO+zn/AJbKv/PCv1vEUsTi/ECjCFD2VKl1/wCCfgjxOFwvh1iJzr+1q1TyH9gX/k7z4e/9jD/7b3Ffq7/wUR1H+zP2QvGd8f8AoX7j/wBJ6/OL/glB8BNY+KH7UWn/ABGk/tNbLwvX6yfGz4b6J8V/hV4g+HWsjdZ6vp1wr14fiVmeGfF+Hkvs2Pr/AAryPELgrFafxf8A5A/AfT7g2o07Uv8Anzr7l+PP/BZHXPF2hX3gz9nnw/q+msNO/wCQpf6db4/9qV8hfGv4SeMvgJ8S7/wD4p0L+z7uzv8AcjK/y/8ATCv0T/ZI/wCCk/7Meo/DSws/i7eWPh3WbRMeUdOm2j/0ZX1/GNLD1sDhMxhS+sW/4HQ/MeB4Y7A4zFZfPF/Vz5Q+AH/BP79qH9qjWP8AhPtYxptlrj/b9S1TUP8AmIf6R/1xr9dPhT8L/Bnwj8Ead8OPBOgLY6dotn5dgo7L/FXyV+0f/wAFff2ffh54OW1+BviT/hIdavB/xLB/Ztx9nP8A6Lr0z/gnR44/aD8c/BZvGf7QexZ9SvPtmkt/057Ydv8A7NX5hxTiOIs4wkcTjf3VJfBA/a+CMFwzkONnQwX72rP46h+b/wDwVJ/5Px8a/XTf/Tfb10//AAS2/ZV+C/7U/jPxLoXxU8Lf2m2h2NvjbqVxb4/78zVyf/BTfUDrf7bHjP8A7d//AEnt69f/AOCKHjvwd4L+NXjTSdW1xLFtasbT+y0c+9xX6pmuIr4bw7pKh8ahA/EsBSwON8VqtPEfwpzmfYng3/glX+xv4XFnfaX8NEb7D9w3uqXVx/7Wr3nSvCmieFtJ+yaVo1hY2uOBafKv/oNb9seMmoNQhE3+rNfzpPM8fi3/ALRVP6xw2RZZgsP/ALLR1PwK/aE1LW5/2hvGt9n/AJm3Ul/783FxX0J+zx/wVK0n9nb9mfT/AIO+E9A1RvEv2v8A4/8AZb/Zt/7msv8A4Kb/ALLetfBP42aj8VNL8N48Ma1f7n1Lf93/AJ7113/BM79uL4YfBTSdQ+GPxtl0zTbL7f8AbdM1H+zrjB/0f/7RX9D5rXwudcFYepQo+19l0P5XwdHMcn45xFGVX6vz/bPH7jwv+1x/wUF+JWoeIZPD/wDaF393Lv8A6Np//fmGv0v/AOCfv7EsH7JXwrj07Wrj+0vE1982qap/erB8b/8ABUP9i3wRoV94g0n4jjUDHZ7v7MsNLuOf/INeefsFftaftS/tafHnVPFl74fEXw82bYO20/8Af6vzbO82zzMsp9h7H6vh4dD9T4XyvhnKc85/bfWMRM+96Ki+f2p8022vzY/dFseCf8FHgP8Ahiz4h4/6F66/9J6/Dz/j3/Cv24/4KR69olt+yJ4zsdX6X3h66/8ASevxIj/0P/viv6D8Jpzw+Q4o/k7xveHxHFmHp/3D9U/2Y/8Agl7+xp8QvgP4L+IWrfC0Ndaj4T0+/eX+1b/5fOt4Zv8AntX0V8Iv2MP2evgXGbj4f/DfTdN3dSm6b/x6Ss79g/xVpHiL9mLwFZ+GvEEV+mn+EdNtLuUHq0NrCrV7Z/x71+M5vm2bSxlSlKq+p+78McP5FHKaVZUlsRLbxwBYkAHsBX5I/wDBbRtn7W2lY/6FBeR/18XFfrk8wz5melfkH/wWl1TTNc/ab0uPT/8AWWfh/wCc/wDbxcV9L4XRnPieMj5jxn9hDhD2SO5/4IR4/wCFmeNyRn/QNN/9uK/T/VPu5Ffll/wQ513SdL+J/jXTdQPzXlhpuzP/AG8V+psIyCDU+I/7riur2NfB+afBkYo/Br9sDVJNV/az+Ii6gP8Aj08Wazj/AMCLivbv2Uv+CnWk/swfs+r8LNK0DU9S8Si+51HFv9mpf+CrH7JmtfB/4033xl8JeF9RbRPEt/cXur6j/o+37ZNVn/gmn+2j8M/gG998MPjbLpi6Ldv9v0vVBp1xcZuf++a/UMVUwOccD0JUaftfZcvufmfi+Gp47IfEDEQxFb2XP9s818QW/wC1z/wUS+J51OR/7RvNOv8A7FpZ1D/RrbT/ADv+uMNfor+wF+w2P2UvhpeHxUdO/wCEo1v59UlT7ppfFP8AwVD/AGNvCGkXt9o/xJi1C6itN39mWWl3G5v/ACDXk/7HP7ZP7Tv7WP7QWo+IdI8OBPA32DaP8+dXwma47iLNcmlRpUVh8PDofpeS5fwrlGc/WKtaeIxFU+a/+CjP7FvxN+CvxQ8Q/FjRvDm7wrrV/cX7/wBn/wCkV8vPc99Hr73tv+ChXxs+Dn7ZupfDb9ob+ztN8L3mu/u/7Qsfm0+z8/8Acf6mvpf9pCT9hP4tfBM/ED4ga9pLaLjI1SykwK+lynizNMro4fC4+h7Wl/c1Phs64LyrOsdisdgK/sqsPsTPzF+DX7cH7QfwADX3hP4kn+zrT7P/AGjp1/8A6R/6O8yv07+LHhjRP+Cgv7CS3+kJ/peuWP23S/7Q/hvIf3O8+T/nmvx80/wvrfijXNP8N+Ev+Jle31//AMSv/ttX6k+P7X49/sy/8E3tO0n4eaAn9vWNju1Fc/8AIPs5riaYtU8c4LLcPjsJUwSUKrmdfhrjsZiMtxtDMOerh+Q/Mr4kfC/xn8HtdbwZ8SPDf9m/Y/WqWgeMNY8Pa1/aXg/xJ/Z3/YPr9Kf+Ce//AAUB8G/G3wbH8P8A9oTxJpf/AAlSP9iIGnT/AOn+9eMf8FdPCv7M2iHS9W+FetCPxX9uy6WD5/0X7PcV9Hl3FmJxOYrLcywfv/znyWY8F4WjlFXNctxlo/8APs2/+CcP/BRX41+IfjTp/wAG/jp4g/tGz1j/AETSP9BhXP8A3xX6eQYY59a/Gj/gl78I/G3xF/a70/xtp/h/Fhof/IULV+ztuvGM8KK/JPE3B5dl+e+zwJ++eD2PzbMOHPaY4sUyYgIcmjzDjpWB4+8aaD4H0Z9e8Ua1FY2qjlpK/P6H72t7OJ+oYqsqOGdVn46/FD/lK/qGP+in2v8A6UW9foB/wVJ+DSfGH9k3ULiPQ/MvtFR7/Tv95beb/wCKr83PHnxT8Ea1/wAFBr74yaN4k/4kQ+IFve/2mP8Ar4r9hvAvxF+G/wC0F8Lf+Ek8KeIItS0i7j4kSv1ziWpissq5bi7fBCP6H4DwbDA5zgs1wfWrOZ+Cmj2/9qD+zP4b7/kF/wDbav28/Yd+EUnwV/Zc8JeDRGqn+wfteoH+9dTbZm/9Cavhz9n3/gmZ8ZvBX7aGn3Gs+H/+KG0O/wDt/wDaf9oW+dQ4zBx/18V+jvxe+K/gT4IeBz4s8Y66thYquPmrTxB4ko588LhMB7/crwz4S/1coYvMMf7m5+BOrf8AMSr9aP8Agiopt/2LtNX/AKftQP8A5NTV+SOoXH2r+0a/VT/gip4/8J/8M1Q+DI9dibWLO+vPO04v8y/6RNtr67xKoT/1Qo/I+B8IJKHGU3fqzwv/AILl6m//AAu3w/Y/9Stb/wDpVcV4t+wn+1p4S/Y4+J2oeNvFGganf2moWIsv9Cjt2/0mvt7/AILB/sz6r8XvhvY/E3wf4eXUNS0T5v8At1+b/wCOtX5/fsffHf8A4Zw+Ndj4y1jw4b+yf/QNUN52rn4Xr0Mw4Dlgl7719w6eNaGPyrxG+t+09n/fPRf2gf20f2nf251/4VR4NGdDvuumWVjbsT+Ne9/8E7f+CY3jb4d+M7L46fHJ9OR7SG3bwvpsN9cbkvP709e/aP8A8FGv2DpdH/tLS/ibpg9v7NuP/jNfPfxf/wCClfxh+P8A8ZdA+En7GnhGLUUtL/7a9/qCfK3k/wDbavkqma53Wyqpl2Bwv1el9s+0o5fkGEzSlmOaYv6xV+wec/8ABbS/1c/tP+H9PjuPMX/hE4P+Jb/29XH7+ue/4I7N9k/bXsYm/wCheugf/Jevcv8AgsV8DPGHiXwZoHxxh0TdJp9lb2mqfP8Ad+Zv/Zp2r4c+A3xf1j4H/Gvw/wDFPTI9y2l/zmvueHIVc68PKuXYf4j4PiKdfIvEeljcR/C+M/bT9qmNv+Gf/Fv93+xW3flX4E/Z/wDiR1+nn7TX/BWb4LeMP2ZtR034f+It3ifV7D9xpx064z/rttfmXc9F+lcvhjkeOy7A4uniP3R1eL2f5XnePwksDU59j+gH9nuMD4L+Hk9dOgr8o/8AgsCRB+2jqJHfTLX/ANuK/VL9nLV9Nn+CmglXG37ANma/Kf8A4K1THU/20Nejsj8yaVab8f8AbxXy3h1Q/wCM2xCl/f8AzPtfFOvR/wCIcYaKevuHvn/BCH7vjL/r/wD/AIzXpv8AwVV/ba8afsyaToHhL4SXX2LxJrwuPJb7Jbsv7n7P/wA9v+u9eTf8ELb/AMmXxhY+kn9LevPv+C0fg3XtL/ae0vxxrce3SNa05bLTtR+9tb+7V4rLcDjvEeVHE/B/wDmwebY7LPCCFTC/xTwXw5pXxs/bf/aH03wTrPiP+0Nd1wbtU1T/AKB/k/8AXCvff2//ANgj4M/so/s/2PiTR/DS/wDCSXt8P7Q1X+0bjn/VZrzX/gm9+0D8M/2eP2h28SfESQabaX1h9i3PXsH/AAVk/bR+Dnxt8G+HfAXwq8UDUrV7ue91fbp9xt/5d/I7Cvp8f/aOG4ywuEw8f9nPj8pnleP4JxWKx1bnxB4R/wAE8D9q/bX+Hmf+f/8A9t7iv3MU/uVI/u1+E/7AFx/Zn7bHw8vj/wBBH/23uK/dWCYFVA6V8h4vRf8AbtL/AAH6J4DtQ4dqx/vk+CUqnqMeNHdP9irVNkGUYetfk8HZn7pWjz0pRP57Pi+M/FLxoB/0N+pf+lFxX6J/8EMPGekXnwZ8QfDvzV/tay15r2bd/wBNv/3FeC/8FXf2PfG/w6+NF98e/B3hz7fout39v/aij/r3/wDtFeS/sOftWav+yj8T28XyD/iRX32f+1K/pHOHS4y4JUcP8UT+RMkliODOP5PEfwrn7oEuBkms3VNRi0rRpb0/8sU+avANE/4KkfsZ65pH9pJ8Z4tmPn/4l1x/8Zrwr9t//gq18L/+FZ6j4R+AHiNdWvrwT2N8P7LuPk85T/1z9a/C8v4dzXEYuNF0mtT+jMz4zyPCZbOpCt7x8w/C8f8ACxv+Cof/AAkPhM/8zfcXtfrR8eYj/wAKL8YZP/Mp3/8A6Imr4O/4I3fsu6q2u3/7SPjfw39hV/l8NnP/AB+iaXdPcN/22r70/aHIj+BvjIf9Stf/APpPNX0PG+PwuIz/AA2Fof8ALqyPjfDvL8RhOF8Xi63/AC95z+f7xB/yGtQ/6/xX7ufsV4tf2XvBuf8AoBV+FOsYujqP/X/dV+1/7D/xb+GeofszeELUeJNOb7JpqLjf0r7vxVw2IqZNhGlf/hj8/wDBPE0MNnWK9u+U8z/4KiftreMv2WtB03wv8J9cx4m1e/4bbbz/AGO2/ibbNX50+CtP+Nn7bv7QWn+Ddc+JH2/WtX6/2j2s/wDtjXuv/BaPw94xsf2g9O8bxr/oF5ZsNP1P3W3t1NeYf8E4Pjv4J/Z6/aE0/wASfEYCwsf9IzqZH/TvcV08M5VhsDwc8XgqXNX5Dz+Lc8xWP49+qY2r/s/Oerft9fsC/C/9kX9mHw/4y0uJ7/xR/wAJBa2Gp6qdSuOf9HuK8W/4J/2/2X9tjwZpusf8/wDcf+k9xX0L/wAFXP23/g5+0J4G8N/Cz4V+I01K2/t77bq/+g3HHk/hXzp+wRqOi2n7X/gy/J/5f7j/ANJ7ivS4f+uvgbEVMd/Fnznn59DK6XiPhaeB/he4foT/AMFvf+TTNP8A+xstf/Se4r5r/wCCHwB/ad8Q5H/MBX/0KvpL/gtpcC4/ZO08oRz4stf/AEnuK+bf+CHn/JwviH/sBD+dfLcP3Xhjjz7DiHXxawR7b/wXbxb/AAV8Ov8A9R6vMf8AghafP+J/jMn/AJ8R/OvU/wDgumPP+Cvh3B/5j1eZf8ELB5HxQ8Zg/wDPgv8A6FWGAv8A8Qnq97muYWXjNS7Gt/wXrUC4+F1iO51HOPpb1t/8EISF8EeNCT/zMH/tvb1i/wDBez/SNe+Fv11L/wBt60P+CIMWz4YfEDHfVrj/ANJ7etVRU/Cqlf8Ar3zi9o4eNdWUf69wP+CkP/BSDxZ8MvGF38G/ggXsNa00br7VGNvNt/4DN5leEQ+Gf26/2rvg7ffH7xh8TFXwzBpu5E1D/Rt23/phBDXhf7SGn63oP7RHxD0zVP8Aj9/4S/Uv/Si4r9Irj45/B21/4Jm/aD4kfyv+Ee4+f/SP+Piu+vg6fDmX4CrgKXM5tXn+Z58cZX4lznMo4+t7Kx8B/sFf8nY+Af8AsbLf/wBKLev3cUsYFx/cr8I/2G7s2H7WPgCLVDj7Jrunr/5MW9futDMJkWPrXy3i5eGc4dy/lR9v4GLkyvER/vl6pKjog71+XH7sSUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFB6Gig8jFAFZ3Mka47ivBP22v2TtT/AGqvBGneGU8SHThYX/2vive3ZIlWo3t+6GunCYytgcRGvR+JHn5pleGznAVcHiPgmfnx/wAOWda/6LQf/BV/9uqP/hy14y/6LU//AIKv/t1fob9nT0H5UnmR+lfXrxD4q/5/n5t/xBXgC/8ABPz0/wCHLPi7/oth/wDBUf8A49R/w5Z8Xf8ARbD/AOCo/wDx6v0N+0+9H2n3rL/iIfFf/P00/wCIM8Df8+D88v8Ahyz4u/6LYf8AwVH/AOPUf8OWfF3/AEWw/wDgqP8A8er9DftPvR9p96f/ABEPiv8A5+j/AOIM8D/8+D88v+HLPi7/AKLYf/BUf/j1H/Dlnxd/0Ww/+Co//Hq/Q37R70faPer/AOIhcV/8/Q/4gzwP/wA+D88v+HLPi7/oth/8FR/+PUf8OWfF3/RbD/4Kj/8AHq/Q37T70fafeo/4iHxX/wA/Q/4gzwP/AM+D88v+HLPi7/oth/8ABUf/AI9R/wAOWfF3/RbD/wCCo/8Ax6v0N+0e9H2j3q/+IhcV/wDP0P8AiDPA/wDz4Pzy/wCHLPi7/oth/wDBUf8A49R/w5Z8Xf8ARbD/AOCo/wDx6v0N+0+9H2n3rP8A4iHxX/z9D/iDPA//AD4Pzy/4cs+Lv+i2H/wVH/49R/w5Z8Xf9FsP/gqP/wAer9DftPvR9p96f/EQ+K/+fof8QZ4H/wCfB+eX/Dlnxd/0Ww/+Co//AB6j/hyz4u/6LYf/AAVH/wCPV+hv2j3o+0e9X/xELiv/AJ+i/wCIM8D/APPg/PL/AIcs+Lv+i2H/AMFR/wDj1H/Dlnxd/wBFsP8A4Kj/APHq/Q37R70faPej/iIXFf8Az9D/AIgzwP8A8+D88v8Ahyz4u/6LYf8AwVH/AOPUh/4Is+LgM/8AC7D/AOCo/wDx6v0O+0+9Sbx6Gs/+Ih8Vf8/Q/wCINcDdKB8M+Av+CVmueF4fssfxoZv9g6V/9urdk/4Jm64qb/8AhYgY/wDYO/8At1fXsdu/8b1YAcdBX4xnnBWR8T5rVzHMKX72Z+2cNZ/m3CWU0suy+ralA+PP+HZmtd/iL/5Tv/t1Sf8ADs/W/wDoo4/8F/8A9ur6/wDs4pfn9q8f/iEvB3/Po93/AIiJxV/z/PkIf8EzNYx/yUn/AMp//wBuo/4dmax/0Un/AMp//wBur69+f2o+f2pf8Qn4K/58i/4iDxX/AM/z5C/4dmax/wBFJ/8AKf8A/bqP+HZmsf8ARSf/ACn/AP26vr35/aj5/aj/AIhPwT/z5D/iIPFf/P8APkL/AIdmax/0Un/yn/8A26j/AIdmax/0Un/yn/8A26vr35/aj5/al/xCfgn/AJ8B/wARB4r/AOf58hf8OzNY/wCik/8AlP8A/t1H/DszWP8AopP/AJT/AP7dX178/tR8/tR/xCfgn/nwH/EQeK/+f58hf8OzNY/6KT/5T/8A7dR/w7M1j/opP/lP/wDt1fXvz+1Hz+1P/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8V/8AP8+Qv+HZmsf9FJ/8p/8A9uo/4dmax/0Un/yn/wD26vr35/aj5/aj/iE/BP8Az5D/AIiDxX/z/PkL/h2ZrH/RSf8Ayn//AG6j/h2ZrH/RSf8Ayn//AG6vr35/aj5/aj/iE/BP/PkP+Ig8Vf8AP8+QP+HZ+t/9FHH/AILv/t1IP+CZmsH/AJqUv/gu/wDt1fX/AO8pfm9qf/EJeDv+fIT4/wCKf+f58d/8Oydcxx8SB/4Lf/t1LN/wTM1xv+aj/wDlO/8At1fYXz0Sdq1l4V8ILVURf8RC4pirOsc18JPAy/DzwTY+FQf+POPaK6hf3i80y3GRipVGO9fe4WhSw2HjRj0Pja1ariK/tZdRaKKK6gCiiigAooooAKhuamqL5/agD5C/bb/4J765+2h4zsfEn/C59R8N2lnYfYn02Kw3b/303zf66vEh/wAEHtabp8a2/wDBV/8Abq/SdVfvRJ1/eV9JlvF2eZPQ9jhauh8Pm3AnDud4j2+Np6nzb+wn+w5/wxhoGoab/wALG1TxF9uv9373+GvpaMgtx2ph93pRb55FfP43GYvHYj21Y+qyzAYLLMP7DD7E1Q3NTef7VD9nxWZ2ux8a/tn/APBLmP8Aa7+Ja/EJPjXq2mKlht/stk8+2/8AR1eND/gg7rBi+wf8LqO3/sG//bq/Sy2kd0bmlYc/N+tfVYDjHP8ALML9Xw9X3D4jMOAuGM5xf1vEU/ePL/2XPgCf2Z/gnp/wvHiR9UNj/wAv97WF+1/+xv4G/a38F/8ACOeLdq39sLj+zNR/isWmX/8AZr2355PuGie23j568CGPxlHF/XI/xT6LE5NluMy7+zq1P90fLH7E/wDwTT8Ffsq6mfGer+IG8Qa43ynVZPvV9UwyPj50wvaj/vmoprpB9+ljcfjszr+1xDvIeUZNgckwn1bA0+WI94d/MfWsbxb4L0Xxzol34f8AEqJd2d4m14z6Vs+eg+5TWlSXjNc1H29F80TsrrD4mHscQfA/xg/4Ip+B/F+p/wBs/CfxL/wjaf8APgNN+X/2nWd8OP8Aghb4N0LXP7S+IPxCOq2H/QN/s4ba/Q75/aj5/avp/wDXTiHk9l7U+J/4h1wr9Y9p7I4L4N/Ab4Z/ALw//wAI/wDDvwxFptn/AHbMV2gts84qydvc0DdjjFfL1q2IxFf21Z6n2uCoYTAUPYYdaHjfx/8A2P8A4HftGLs8ffDXT9QvFTjUXhh+0Cvj7XP+CDIu9YWTS/jS62X93+yv/t1fpJ9nA60vz+1e1gOJc7yyh7GhV0Pms24K4cziv7avS94+T/2dP+CUvwB+CkPmeJfDg8RXo66nqcMP/oNe8eO/hzH4n+GGpeAdG8QNppvLBrT+0U/5dPlruPn9qZg3I59e1cuLzbMcfW9tXq3PTwHD+U5ZQ9lQpH5v6x/wQs1i61r+0x+0e/8A4Kv/ALdU3gb/AIIia54a8b6b40P7R+qbtHv7dsafp32f/U/9tq/Rw24HJps8G5M17EuNeIq2F+r1anuHz1Pw64W/tH677L96VvD2nx6Ro1lYj/l1s1/9Bq3cgelFtR9p96+Xep94rYdWOQ+Jvwo+HHxg0U+HPiD4V0zVbI/fsNQsVnWvif4rf8ENvBnijXPt/wAOviA3huy/6B39nC5X/wBp1+hHz+1Hze1enlmfZ5kyth6uh8znPC2RZ874ikfBPwE/4Iq/BT4bax/wkXxB18+Jn2QbE/s7/R2/9GV9n+Avhl4M+Fmh/wDCM/D3w1p2mWa/csLBBAv6V0lMuIx131OPznM8z9/ESNcs4fynJn/sVIt1Dc0fafei3t+9ecfRHyv+3B+wbrn7Y+o6S7fGfVPDdppH2jzNLgsdy3//AJGr53H/AAQa1U/81t/8pbf/AB6v0uFs55Bp+GHQCvo8u4tzvJqHssHUPh824B4dzvFe3xFPU+Vf+Cf/AOwBH+xourXyfEV9SbWPs+9fuw/ua+qJuVpf++aa0f8AH1rwcZj6+Nxftax9LleWYfK8F9Ww5Q120Gq6OdOz/wAfdfnl4z/4IleMvFniHUPF+sftHyam1/8AN/pulN/8er9HfKXGaZKHl6S7a7Moz7Msnn7TD+4efn3DWVcSU/Y40/O74Y/8EVfGHgPxxp/jDR/2k9U05rG8t5MabpvkfKv/AG2r9BfD+kR6Xo9lYb/+PZdprQy/rQLcHpRmec47OX7XEPUvIOHMq4eoexwxzHxL+Fvgn4qaI3hf4geHLDUrJusV6u6viz4zf8ERvhh451j+1fh54i/4Ryw/6By6b8p/9F199Lv/AP10SYOBVZVnmbZP/u9UwznhbIs+d8bSPgv4Gf8ABE34X/D7XP8AhIfiD4hbxO392+05d3/tSvsX4f8Awo8DfC/RV0LwF4f07TLT+5p9ntrrZbdiOtOtwD1FPMeIc2zJ/wC2VeY1ynhTIsn/AIFM+d/2p/2APgv+1DH/AGhrejfYdXKyqmqWf3v+BV8vp/wQs1th/Z3/AA0e/wBh9P7K/wDt1fpOlv2FL9nBrqwHFef5bQ9jQqHnZlwNw7mWO9tWpnzN+zB/wTP/AGev2dv7P1L/AIRz+0tasemqXvWvoDxFomj6tpMmnahb/bbUp/x5bN1af2jy/neZjUhk3R7+1eTjczzDG1/b1pe+e5gMkyzLMH9Xw9LkgfDHx2/4Iy/DD4gauviH4T+JP+EJk+17n/s7Tv8A93XMeCf+CIGkaX4z/wCEh+IHxn/tO07aW+m4/wDa1fogu/8A/XR9m9q9yPF3EEKHs/anz1Tw+4ZrV/aezPP/AIJfs9/C/wCAfh//AIR/4W+FNM0mz/uWFmF/9Br0A3AxzTPMH96nm4B6183WrYjE1/a4jU+uw2Cw+Bw/sMPEkGwr1ryX9rj9nH/hpn4Taj8MBrr6aL5P+P8AQbttetCRB0pnz+1Xhqk8JX9tSJxeFoYyh7GsfmdB/wAEGtYsovsh+Nx2/wDYK/8At1fVP7CH7Hcn7G/gW/8ACl98R9S8SG+vtyRv/qbL/ZWvofZxs/hqORmhXGOPavbzLijOc4w6o4ip7h8zlnBuQZDjvrWHp7jraIZ3AYr5/wD27P2NP+Gw/Aen+FP+E8k037Df/bcj5oXr39Hdtron3qJR5o2CTa1eNg8TiMJXVaifRY/L8DmeDlha3wTPzcP/AAQe1ARfZP8Ahd58v/sFN/8AHq9D/ZM/4JM65+zL8ZrP4oRfGs6laWce3+yzpu3/ANrV9xC3Hal+ze1e/ieMeIMwwvsMRU0Pkcu8OuGMpxHt8LT1MiXT49Siax1GMNbXKcV8qftNf8EnPgH8a3e/8Cwx+GtWuR8slhZ/uW+q7a+wIx/co+zpXkZZmebZVX9rh6tj6DNOH8mzuh7PG0j84/CH/BCfRLLxjY6t4w+M76lYJ/zC/wCym/8ARvnV9gfAv9jn9n39nu22fDH4a6Tpl6y/Pfw2EP2n/vqvXQWfpSN51d+YcRZ3mv8AvFQ4Mt4Q4dyn95QpGL4n8GeFvGuh3Wha5okd5Z3n+tXZuVq+H/jV/wAETfhn458YL4j+F3iI+HLT+PTo4Wwf+A/u6++Yo3j6vSyRf9NK5cuz/Nspr/7LV5DrzjhnJuIaf+20j4c+AP8AwRp+C/ws3a74+1//AISd/tm7y76wXyP++WaSuO+Iv/BEVPGHjrxJ4t8LfGz+y7PV7ydtO0vT9N+XT/8Ap3/11fosYBPyaPs3tXp0+MuI6WI9r7Y8afhvwlUoKn7E+d/2V/2P9d/Zt+DGofDn/hdereIr28+0f2Zqmoj/AI8q+afFP/BD/wAZeMdb1LxD4t/aPbUtQvP+YnqGlt/8er9G2jKlUoktkZcSdK48FxRnOBx1XEYep77O7MODeH8zwtLDYin7kD4W/Zw/4JN+Mf2c/ihp3xG8JftI6pts/wDkKaZ/Z3/IQ/8AI1fUX7QH7Onwz/aD8If8Ip8QfD8WoR/esg/rXpDQjOajrDE57meMx312vU/em2C4bynAYH6l7L90fnR4u/4IW6Jqet3w8J/Gf+zbJ/8AmFjTf/t1ejWH/BHX4Kab8MtQ8GRqn9uXljsfxL/Z/wA1fa/2b2o2v/e/WvYnxlxHUt+/PMh4b8K0r8tI/NxP+CGGtWOtf8JFpX7RjaffWf8AyC9TXS+n/kavvP4NeD/EXw8+FmgeD/FXiR/EWoWGnW9rf6v/AM/zbf8Aj4rrfIbPtSpv3NXBmmfZpnfvY2pz2PVyDhnKsg51gqfIWKKKPN/2v0rxD6P2ZzPi7wP4f8eaC2ieKvD0WoWbj57O8FfKvxt/4I9/s/fEU6hqXw7j/wCEbvb5Oun/APHvX2PayFfv0GIH569HAZzmuU1v9nq8p4ma8PZNn1P/AG2kfmqf+CCQHX4zn/wW/wD26vbvgR/wSN/Z5+GEun3vizw43iO/sR11CO3+yf8Afivr+PvR89eji+Mc7xa9nWqniYHw+4Ywlb2tKmYfg7wnoPg7Ro9B0TQI9OtbRNqWdog8kfpS+PfCUHjDwbqnhlpAv9oafcWjf9tl2/1rZ+z7ad+8r5/nqfWOfqfX/VsL9X9h9k/OHVf+CFMcusahqenfGx1+2Xe//kFf/bqn8Hf8ERNb8I6zp2p6R+0Y4+w6lb3vOl/88f8AttX6L4c9RTuBX08+NeIqlD2EqvuHxdDw44Yw+J9vGmeR/GH9l74YfG/4ZH4ffEDQP7SsTY7SH/4+K+PfGH/BCv8AtTXdQvfCXxrOm2V8P+QX/ZXH/o6v0W8j3qU2wxzxXJgOI88yxWw9U7cy4E4bzauqtekfFuhf8EePgBpfw1vfBkFsjavfWECzasbHla8qtP8AghXrGn6uuraN+0hqmm3toP8AkKf2b/8Abq/SWaHbtSkMfXeldFPizP6dJx9ructTw84VrV41lS96B8c/tGf8E4/iT+0D4K8O+DfFP7RerfYtGsduqkRt/wATD/yNXJ/s5f8ABJPxv8APihpfxF8J/tESq1n/AMhQf2Q3+n/+Rq+8njQDlvxp/lDrvNYR4ozmjgp4NVP3UzepwVkdbH08Z9uB8gftuf8ABOzxn+1t4zh8Q3Hxs1fTdGsxtPhfH+jlv+fj/XVzP7Kn/BLnxZ+y58YtN+IGnftC6pPp1o8/9p6R5PkrqH7r/rtX3E0GePMFOEAx9/NSuIs1jl31L2n7o2qcGZHWzb+0f+Xp8U/th/8ABMTxt+1h8S/+Ez1n42S2Fkif8SzTf7K3fYf/ACNVr9jr/gmx42/ZI+JEnizQ/jhJeaNLCy6j4cXS8fbfl+9/rq+yzA4537fwqKWAHo+6o/1jzZ4D+z/afug/1MyOlm39o/8AL0+Uf2w/+CXvwv8A2ndWbxlo7r4f1u7/AOQhqkVjuZ64f4Hf8Eb/AAP8PDqH/CwvE6+JFvLHbpemahp3+jafX3YLcmoZLdP4xWtHijOcPhI0I1djnxXAPDGNxjxVWnufnAn/AAQ11fTtYbUfC37Rsulbbzdp32PStu3/AMjV+hPhPTv+Ee0Ox0K9GWs7H5611jAGypTiLdIa5c34gzjOqkPrr57Hq5Jw5lXD/P8AVSxRB3ogoryj6AkooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAK1x0/CvB/jD+2n4T+E3jF/BmraDqLvbfe+yR17vc26SR/PVG503RNQ+SeNG9K8XN6WYV6FsDV5J/wCC525dVoUq/wC/p88D5x/4eU/Db/oX9T/8F1H/AA8p+G3/AEL+p/8Agur6M/4R3S/+eEVA8O6X/wA8Ivyr59ZPxh/0Hw/8A/4J7/8AafDP/QJ/5P8A8A+c/wDh5T8Nv+hf1T/wXUf8PKfht/0L+qf+C6vo7/hHdJ/55J/3ytH/AAjuk/8APJP++Vp/2Jxd/wBB/wD5J/wQ/tThn/oE/wDJ/wDgHzj/AMPKfht/0L+qf+C6j/h5T8Nv+hf1T/wXV9Hf8I7pP/PJP++Vo/4R3Sf+eSf98rR/YfF3/Qf/AOSf8EP7U4Z/6BP/ACf/AIB84/8ADyn4bf8AQv6p/wCC6j/h5T8Nv+hf1T/wXV9Hf8I7pP8AzyT/AL5Wj/hHdJ/55J/3ytH9h8Xf9B//AJJ/wQ/tThn/AKBP/J/+AfOP/Dyn4bf9C/qn/guo/wCHlPw2/wChf1T/AMF1fR3/AAjuk/8APJP++Vo/4R3Sf+eSf98rR/YfF3/Qf/5J/wAEP7U4Z/6BP/J/+AfOP/Dyn4bf9C/qn/guo/4eU/Db/oX9U/8ABdX0d/wjuk/88k/75Wj/AIR3Sf8Ankn/AHytH9h8Xf8AQf8A+Sf8EP7U4Z/6BP8Ayf8A4B84/wDDyn4bf9C/qn/guo/4eU/Db/oX9U/8F1fR3/CO6T/zyT/vlaP+Ed0n/nkn/fK0f2Hxd/0H/wDkn/BD+1OGf+gT/wAn/wCAfOP/AA8p+G3/AEL+qf8Aguo/4eU/Db/oX9U/8F1fR3/CO6T/AM8k/wC+Vo/4R3Sf+eSf98rR/YfF3/Qf/wCSf8EP7U4Z/wCgT/yf/gHzj/w8p+G3/Qv6p/4LqP8Ah5T8Nv8AoX9U/wDBdX0d/wAI7pP/ADyT/vlaP+Ed0n/nkn/fK0f2Hxd/0H/+Sf8ABD+1OGf+gT/yf/gHzj/w8p+G3/Qv6p/4LqP+HlXw2/6F/VP/AAXV9Hf8I7pP/PJP++Vo/wCEd0n/AJ5J/wB8rR/YnF3/AEH/APkn/BD+1OGf+gT/AMn/AOAfOP8Aw8p+G3/Qv6n/AOC6j/h5T8N/+hf1P/wXV9Gf8I7pf/PCL8qB4d0vPMEX5Uf2Pxh/0Hw/8A/4If2nwz/0Cf8Ak/8AwD5y/wCHlfw5/wChf1P/AMFlL/w8q+HP/Qv6n/4Lq+kP+Ee0b/nlD/3xS/8ACP6N2ih/74pf2Rxb/wBB/wD5J/wRf2pwx/0B/wDk/wDwD5x/4eS/Dz/oB6n/AOC9qP8Ah5L8PP8AoB6n/wCC9q+jv+Ef0j/n3T8qP+Ef0j/n3j/Kr/szjH/oPh/4B/wSv7S4Z/6AX/4H/wDanzj/AMPJvh5/0AdS/wDABqP+Hk3w8/6AOpf+ADV9Hf8ACP6N/wA+kf5Uf8I/o3/PpH+VL+zOMP8AoPh/4B/wRf2lwx/0A/8Ak/8AwD5x/wCHk3w8/wCgDqX/AIANR/w8m+Hn/QB1L/wAavo7/hH9G/59I/yo/wCEf0b/AJ9I/wAqP7M4w/6D4f8AgH/BD+0uGP8AoB/8n/4B84/8PJvh5/0AdS/8AGo/4eTfDz/oA6l/4ANX0d/wj+jf8+kf5Uf8I/o3/PpH+VH9mcYf9B8P/AP+CH9pcMf9AP8A5P8A8A+cf+Hk3w8/6AOpf+ADUf8ADyb4ef8AQB1L/wAAGr6O/wCEf0b/AJ9I/wAqP+Ef0b/n0j/Kj+zOMP8AoPh/4B/wQ/tLhj/oB/8AJ/8AgHzj/wAPJvh5/wBAHUv/AAAaj/h5N8PP+gDqX/gA1fR3/CP6N/z6R/lR/wAI/o3/AD6R/lR/ZnGH/QfD/wAA/wCCH9pcMf8AQD/5P/wD5x/4eTfDz/oA6l/4ANR/w8m+Hn/QB1L/AMAGr6O/4R/Rv+fSP8qP+Ef0b/n0j/Kj+zOMP+g+H/gH/BD+0uGP+gH/AMn/AOAfOP8Aw8m+Hn/QB1L/AMAGo/4eTfDz/oA6l/4ANX0d/wAI/o3/AD6R/lR/wj+jf8+kf5Uf2Zxh/wBB8P8AwD/gh/aXDH/QD/5P/wAA+cf+Hk3w8/6AOpf+ADUf8PJvh5/0AdS/8AGr6O/4R/Rv+fSP8qP+Ef0b/n0j/Kj+zOMP+g+H/gH/AAQ/tLhj/oB/8n/4B84/8PJvh5/0AdS/8AGo/wCHk3w8/wCgDqX/AIANX0d/wj+jf8+kf5Uf8I/o3/PpH+VH9mcYf9B8P/AP+CH9pcMf9AP/AJP/AMA+cf8Ah5N8PP8AoA6l/wCADUf8PJvh5/0AdS/8AGr6O/4R/Rv+fSP8qP8AhH9G/wCfSP8AKj+zOMP+g+H/AIB/wQ/tLhj/AKAf/J/+AfOP/Dyb4ef9AHUv/ABqP+Hk3w8/6AOpf+ADV9Hf8I/o3/PpH+VH/CP6N/z6R/lR/ZnGH/QfD/wD/gh/aXDH/QD/AOT/APAPnH/h5N8PP+gDqX/gA1H/AA8m+Hn/AEAdS/8AABq+jv8AhH9G/wCfSP8AKj/hH9G/59I/yo/szjD/AKD4f+Af8EP7S4Y/6Af/ACf/AIB84/8ADyb4ef8AQB1L/wAAGo/4eTfDz/oA6l/4ANX0d/wj+jf8+kf5Uf8ACP6N/wA+kf5Uf2Zxh/0Hw/8AAP8Agh/aXDH/AEA/+T/8A+cf+Hk3w8/6AOpf+ADUf8PJvh5/0AdS/wDABq+jv+Ef0b/n0j/Kj/hH9G/59I/yo/szjD/oPh/4B/wQ/tLhj/oB/wDJ/wDgHzj/AMPJvh5/0AdS/wDABqP+Hk3w8/6AOpf+ADV9Hf8ACP6N/wA+kf5Uf8I/o3/PpH+VH9mcYf8AQfD/AMA/4If2lwx/0A/+T/8AAPnH/h5N8PP+gDqX/gA1H/Dyb4ef9AHUv/ABq+jv+Ef0b/n0j/Kj/hH9G/59I/yo/szjD/oPh/4B/wAEP7S4Y/6Af/J/+AfOP/Dyb4ef9AHUv/ABqP8Ah5N8PP8AoA6l/wCADV9Hf8I/o3/PpH+VH/CP6N/z6R/lR/ZnGH/QfD/wD/gh/aXDH/QD/wCT/wDAPnH/AIeTfDz/AKAOpf8AgA1H/Dyb4ef9AHUv/ABq+jv+Ef0b/n0j/Kj/AIR/Rv8An0j/ACo/szjD/oPh/wCAf8EP7S4Y/wCgH/yf/gHzj/w8m+Hn/QB1L/wAaj/h5N8PP+gDqX/gA1fR3/CP6N/z6R/lR/wj+jf8+kf5Uf2Zxh/0Hw/8A/4If2lwx/0A/wDk/wDwD5x/4eTfDz/oA6l/4ANR/wAPJvh5/wBAHUv/AAAavo7/AIR/Rv8An0j/ACo/4R/Rv+fSP8qP7M4w/wCg+H/gH/BD+0uGP+gH/wAn/wCAfOP/AA8m+Hn/AEAdS/8AABqP+Hk3w8/6AOpf+ADV9Hf8I/o3/PpH+VH/AAj+jf8APpH+VH9mcYf9B8P/AAD/AIIf2lwx/wBAP/k//APnH/h5N8Pf+gBqX/gA1J/w8m+Hv/QA1H/wAavpD+wNG/59U/Kj+wNG/wCfVPyo/szjD/oPh/4B/wAEP7S4Z/6AP/J/+AfN3/Dyf4ff9C/qf/gA1R/8PKvh3/0L+qf+C6vpX+wtD/590pf7D0T/AJ90qf7I4u/6D/8AyT/gj/tLhj/oA/8AJ/8A7U+av+HlXw8/6AGp/wDgtaj/AIeVfDz/AKAGp/8AgtavpX+wdG/590/Kj+wdG/590/Kj+xeLv+g//wAk/wCCH9pcMf8AQB/5P/8Aanzb/wAPJ/h7/wBADU//AAXtTv8Ah5L8PP8AoBal/wCC9q+j/wCxNI/54JSf2JpH/PBP0o/snjD/AKD4f+Af/bB/aPDP/QB/5P8A/anzl/w8k+HH/QA1P/wXmj/h5J8OP+gBqf8A4LzX0R/wjul/88Ivyo/4R3S/+eEVP+x+MP8AoPh/4B/wSf7S4Z/6BP8Ayf8A4B87/wDDyT4cf9ADU/8AwXmj/h5J8OP+gBqf/gvNfRH/AAjul/8APCKj/hHdL/54RUf2Pxh/0Hw/8A/4If2lwz/0Cf8Ak/8AwD53/wCHknw4/wCgBqf/AILzR/w8k+HH/QA1P/wXmvoj/hHdL/54RUf8I7pf/PCL8qP7H4w/6D4f+Af8EP7S4Z/6BP8Ayf8A4B87f8PJfh3/ANALU/8AwAaj/h5L8O/+gFqf/gA1fR39h6T/AM8I/wAqP7E0r/nkn5Uv7I4w/wCg+H/gH/2w/wC0eGP+gF/+B/8A2p84/wDDyX4d/wDQC1P/AMAGpP8Ah5R8PP8AoX9T/wDABq+j/wCxNK/55J+VH9h6T/zwj/Kj+yOMP+g+H/gH/wBsH9o8Mf8AQD/5P/8AanzZ/wAPKvh5/wBADU//AAWtT/8Ah5P8Pv8AoAan/wCC9q+kf7B0b/n3T8qP7B0b/n3T8qP7G4u/6D//ACT/AII/7S4X/wCgD/yf/wC1PnD/AIeTfDz/AKAOpf8AgA1H/Dyb4ef9AHUv/ABq+jv+Ef0b/n0j/Kj/AIR/Rv8An0j/ACqv7M4x/wCg+H/gH/BF/aXDH/QD/wCT/wDAPm//AIeUfD7/AKF7Uv8AwAal/wCHk3w9/wCgBqP/AIANX0h/YGjf8+qflR/YGjf8+qflR/ZnGP8A0Hw/8A/4If2lwz/0Af8Ak/8AwD5r/wCHlPw8/wCgDqn/AILWqT/h5P8ADz/oAap/4L2r6Q/sHSP+fZKP7B0fvbJR/Y/F3/Qf/wCSf8Ef9pcM/wDQC/8AwP8A+1PnAf8ABSj4cgf8i/qn/gvaj/h5R8Of+hf1T/wAavo//hHtE/59I/yo/wCEe0T/AJ9I/wAqn+xeLv8AoYf+Sf8ABH/anDH/AEAy/wDA/wD7U+aj/wAFKvh928P6l/4LzT/+Hk/w/HTQNS/8F7V9Jf8ACP6L/wA+yflR/wAI/ov/AD7J+VV/ZnGP/QfD/wAA/wCCL+0uF/8AoA/8n/8AtT5w/wCHk3w9/wCgDqX/AIANR/w8m+Hv/QA1L/wAavo/+wNF/wCfVPyo/sDRv+fVPyo/szjH/oPh/wCAf8EX9pcM/wDQB/5P/wAA+bf+Hkvw7/6F7U//AAWtS/8ADyT4df8AQA1P/wAAGr6T/sTRf+eSflR/Yeif88k/Kp/sXi7/AKD/APyT/gk/2jwxf/cP/J//ALU+Z/8Ah5V8O/8AoX9T/wDBdS/8PKvh3/0L+qf+C6vpX+w9H/54pR/Ymkf88ko/sjjH/oPh/wCAf8E0/tLhn/oA/wDJ/wD7U+a/+HlXw4/6AOqf+C5ql/4eTfDn/oB6p/4Lmr6Q/sPRf+eUf5Uf2Ho3/PKP8qX9mcY/9B8P/AP/ALYz/tThj/oC/wDJ/wD7U+bf+Hk/w3/6F/U//BaaP+Hk/wAN/wDoAan/AOC019GHw7pef9RF+VIPDul/88Ivyqv7H4w/6D4f+Af8Er+0+Gf+gT/yf/gHzr/w8l+Hv/QC1L/wXtUX/Dyv4e/9AHU//Baa+lf7E0j/AJ4JR/Yuk/8APFKX9k8Yf9B8P/AP/th/2lwz/wBAH/k//wBqfNX/AA8r+Hv/AEAdT/8ABaaX/h5L8Pv+gBqX/gur6U/sXSf+eKUf2LpP/PFKP7J4w/6D4f8AgH/2wf2lwz/0Af8Ak/8A9qfNf/DyT4e/9C5qX/gtNJ/w8r+H/wD0L+pf+C819K/8I/ov/Psn5Uf8I/ov/Psn5VX9mcY/9B8P/AP+CH9pcMf9AH/k/wD9qfNf/Dyv4ff9ADU//BdUv/DyX4ef9APU/wDwXtX0d/wj+kf8+8f5Uf8ACP6R/wA+8f5U/wCzOMf+g+H/AIB/wQ/tLhn/AKAX/wCB/wD2p85/8PJvhx/0AdT/APBe1H/Dyb4cf9AHU/8AwXtX0R/wj+lf88ov++KP+Ee0r/nlF/3xU/2Xxj/0Hw/8A/4Iv7T4Z/6BP/J/+AfN/wDw8q+Hf/Qv6p/4LqP+HlXw9/6AWp/+C019Kf2Ho/8Azwj/ACo/sPR/+eEf5Uv7I4x/6D4f+Af8Er+0uGV/zAf+T/8A2p85f8PJPhx/0AdT/wDBeaX/AIeSfDj/AKAOp/8Agvr6J/4R/Ss/6mL8qB4f0v8A54xflR/ZHGH/AEHw/wDAP+CZ/wBpcMf9An/k/wDwD5y/4eT/AA//AOgBqf8A4L2pf+Hkvw+/6AWpf+C9q+kP+Ef0X/n2T8qP7A0X/n2T8qr+zOMf+g+H/gH/AAS/7S4X/wCgD/yf/wC1Pmv/AIeVfDz/AKAGp/8Agtanf8PJfh//ANC/qf8A4LWr6S/sHRv+fdPypf7B0b/n3T8qn+xeLv8AoP8A/JP+CH9pcMf9AH/k/wD9qfNcX/BSL4en7nh/Uv8AwW0//h5L8Pf+gFqX/gA1fSH9iaR/zwSk/sTSP+eCfpR/ZHGH/QfD/wAA/wDtg/tLhn/oA/8AJ/8A7U+bf+HkvgD/AKF/U/8AwWtT/wDh5N8Pf+gBqX/gA1fSB0DRu1qn5U3+w9I/590op5TxjH/mPh/4B/wRf2lwy/8AmA/8n/4B85f8PJfh5/0A9T/8F7VD/wAPK/h5/wBADU//AAWV9Kf8I/pH/PvH+VH/AAj+kf8APvH+VV/ZnGH/AEHw/wDAP+CP+0uGf+gF/wDgf/2p82f8PK/h7/0AdT/8AGqT/h5P8Pf+gBqX/gvavpD+wNG/59U/Kj+wNG/59U/Ksv7I4x/6D4f+Af8ABF/aXDP/AEAf+T/8A+bP+HkXw4/6AWp/+C2j/h5F8OP+gFqf/gtr6R/4R7R/+ecP/fFH/COaT/zyi/791f8AY/Fv/Qf/AOSf8EX9q8Mf9An/AJP/AMA+cf8Ah5J8Ov8AoX9T/wDBbTf+HlXw2/6F/VP/AAXV9Hf8I5pH/PBP++aP+Ec0f/ngn/fNH9icXf8AQf8A+Sf8EP7T4Z/6BP8Ayf8A4B88f8PKPhr/ANADVf8AwXUn/Dyj4a/9ADVf/BdX0T/YGkf88o/++aX+wNK/54x/98U/7L4w/wCg+H/gH/BI/tLhr/oE/wDJ/wDgHzb/AMPKvh5/0ANT/wDBa1P/AOHk/wAPv+gDqf8A4L2r6R/sHSP+fZKP7B0j/n2Sl/Y3Fy/5j/8AyT/gmv8AaXDP/QD/AOT/AP2p83/8PLfhp/0L+q/+C2pf+Hk/w3/6F/Vf/ABq+h/7A0r/AJ4RflR/YGldPs8X5U/7K4x/6D4f+Af8Ej+0eGf+gT/yf/gHzj/w8k+Hn/QA1T/wW08/8FJ/hz/0L2qf+C9q+j/7A0H/AJ9Y/wAqP7A0H/n1jpf2Pxb/ANB//kn/AATT+0+GH/zAv/wP/wC1Pmn/AIeVfD7/AKF/U/8AwXVL/wAPJ/h9/wBC/qf/AIANX0l/Yeif8+6Un9haH/z7pR/ZHF3/AEH/APkn/BF/aXDH/QA//A//ALU+cP8Ah5L8PP8AoB6n/wCC9qb/AMPJ/h9/0AdT/wDBe1fSH9h6R/zwj/Kl/sXSf+eKUf2Rxh/0Hw/8A/8Atg/tLhn/AKAX/wCB/wD2p81/8PJPh728Oal/4LTR/wAPJPh7/wBC5qX/AILTX0p/wj+i/wDPsn5Uf8I/ov8Az7J+VV/ZnGP/AEHw/wDAP+CP+0+GP+gH/wAn/wDtT5s/4eS/Dz/oXNT/APBaaT/h5X8PP+hf1P8A8F9fSn/CP6L/AM+yflR/wj+i/wDPsn5Uv7L4w/6D4f8AgH/BF/aXDH/QB/5P/wDanzl/w8m+HH/QB1P/AMF7Uf8ADyb4cf8AQB1P/wAF7V9Ef8I/pX/PKL/vij/hHtK/55Rf98Uf2Xxj/wBB8P8AwD/gi/tPhn/oE/8AJ/8AgHzv/wAPJvhx/wBAHU//AAXtR/w8m+HH/QB1P/wXtX0R/wAI9pX/ADyi/wC+KP8AhH9K/wCeUX/fFH9l8Y/9B8P/AAD/AIIf2nwz/wBAn/k//APnX/h5L8PP+gHqf/gvaj/h5L8PP+gHqf8A4L2r6O/sPSP+eEf5Uf2HpH/PBPyFL+yeMf8AoPh/4B/9sP8AtLhn/oBf/gf/ANqfOn/Dyf4bf9ALVv8AwXGj/h5P8Nv+gFqv/guNfRP9gaR/zyj/AO+aP7A0j/nlH/3zR/ZHGH/QfD/wD/gmX9p8Nf8AQJ/5P/wD5w/4eTfDv/oXNT/8FlN/4eV/Dr/oX9U/8FlfSf8Awj+j/wDPsn5Uf8I/o/8Az7JR/ZfGP/QfD/wD/gmv9p8M/wDQC/8AwP8A+1PnL/h5N8N/+gBqf/guao/+HkXw6/6F7Uv/AAXGvo3/AIR/Sf8AnlH/AN8Uf8I/pP8Azyj/AO+Ky/sbi7/oPh/4B/wRLM+Gf+gT/wAn/wCAfN3/AA8q+Hn/AEL+p/8AgtqX/h5R8P8A/oX9S/8AABq+kf7E0j/nglH9i6T/AM8UrX+yeMP+g+H/AIB/9sP+0uGP+gD/AMn/APtT5r/4eS/D7/oAal/4Lqb/AMPKvh5/0L+p/wDgtr6W/sXSf+eKUf2JpH/PBP0o/snjD/oPh/4B/wDbB/aXDP8A0Af+T/8A2p81f8PKvh7/ANADU/8AwXNTv+HkvgD/AKF/U/8AwWtX0n/YOjf8+6flS/2Do3/Pun5U/wCxuLv+g/8A8k/4If2lwx/0Af8Ak/8A9qfN4/4KT/DkD/kXtU/8F7Uv/DyX4cf9AHVP/ABq+jv+Ee0T/n0j/Kj/AIR7RP8An1T8qX9i8Xf9DD/yT/gh/afC/wD0Av8A8D/+1Pmv/h5L8Pf+gBqf/guqT/h5L8Pf+gFqX/gvavpH+wtD/wCeC0f2Fof/ADwWsv7F4u/6D/8AyT/7YX9pcMf9AH/k/wD9qfNv/Dyf4ff9AHU//Be1L/w8l+Hv/QD1L/wXtX0h/YOjf8+6flS/2Do3/Pun5Vr/AGNxd/0H/wDkn/BF/aXDH/QD/wCT/wD2p81/8PJfAH/Qv6n/AOC1qP8Ah5L4A/6F/U//AAWtX0p/YOjf8+6flR/YOjf8+6flT/sbi7/oP/8AJP8Aglf2lwv/ANAH/k//ANqfNX/Dyr4ef9ADU/8AwWtTv+Hkvw+/6F/U/wDwWtX0n/YOjf8APun5Uf2Do3/Pun5Uv7F4u/6D/wDyT/gh/aXDH/QB/wCT/wD2p82/8PJ/h9/0AdT/APBe1M/4eVfDz/oAan/4LWr6V/sHRv8An3T8qP7B0b/n3T8qP7G4u/6D/wDyT/gh/aXDH/QB/wCT/wD2p498D/2wPCXxn1dvD+i6Bfow/wCfyPbXtlrOJYt6iqNtpdvbf6XpUSf7tX7S3+zx7ExX02WUMdh6P+0VOc+bx1bCVq/+z0uQnooor1DmCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCOftRUlR0AFFFHke9c4BRRRXQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRRZAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUWQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUWQBRRRQAUUUUWQBRRRQAUUUUAFFFFABRRRQAUUUUrIAoooosgCiiinZAFFFFABRRRQAUUUUrIAooop2QBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFc+oBRB3o8j3psMO2ugCaiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/Z';
  }

  // 2. Resolusi arrow bullet JP
  $arrowJp = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAJCAYAAAA/33wPAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAAiklEQVQokaXSIQoCYRDF8d93AaPBaBAxGE1iEPGGHkCMHsKwJ/AEdptRDGNwFj4srrsPhnkT5s/wGNghIkLfQtOayDr2BO3r4YYJLjj9DatAWxzSr3FN6KoLqOSiUsoID9x9NM4uIopfqi56VllFQucd8pli1g7nL8CiV0YJeGE54AU02Az5o4jwBmbAZCpiE9QOAAAAAElFTkSuQmCC';
  $arrowCandidates = [
    'media/arrow_jp.png',
    'public/media/arrow_jp.png',
    'images/arrow_jp.png',
    'storage/arrow_jp.png',
    'uploads/m_media/arrow_jp.png'
  ];
  foreach ($arrowCandidates as $cand) {
    $paths = [
      function_exists('public_path') ? public_path($cand) : null,
      function_exists('base_path') ? base_path('public/' . $cand) : null,
      function_exists('base_path') ? base_path($cand) : null,
      __DIR__ . '/../' . $cand,
      __DIR__ . '/../../' . $cand,
      '/opt/www/hris/public/' . $cand,
      '/opt/www/hris/' . $cand
    ];
    foreach ($paths as $full) {
      if ($full && file_exists($full) && is_file($full)) {
        $type = pathinfo($full, PATHINFO_EXTENSION);
        $arrowJp = 'data:image/' . ($type === 'png' ? 'png' : 'jpeg') . ';base64,' . base64_encode(file_get_contents($full));
        break 2;
      }
    }
  }

  // 3. Resolusi footer JP
  $footerJp = '';
  $footerCandidates = [
    'media/footer_jpbooks.jpg',
    'public/media/footer_jpbooks.jpg',
    'images/footer_jpbooks.jpg',
    'storage/footer_jpbooks.jpg',
    'uploads/m_media/footer_jpbooks.jpg'
  ];
  foreach ($footerCandidates as $cand) {
    $paths = [
      function_exists('public_path') ? public_path($cand) : null,
      function_exists('base_path') ? base_path('public/' . $cand) : null,
      function_exists('base_path') ? base_path($cand) : null,
      __DIR__ . '/../' . $cand,
      __DIR__ . '/../../' . $cand,
      '/opt/www/hris/public/' . $cand,
      '/opt/www/hris/' . $cand
    ];
    foreach ($paths as $full) {
      if ($full && file_exists($full) && is_file($full)) {
        $type = pathinfo($full, PATHINFO_EXTENSION);
        $footerJp = 'data:image/' . ($type === 'png' ? 'png' : 'jpeg') . ';base64,' . base64_encode(file_get_contents($full));
        break 2;
      }
    }
  }
@endphp

<style>
  @page {
    size: A4 portrait;
    margin: 8mm 14mm 6mm 14mm;
  }

  body {
    margin: 0;
    padding: 0;
  }

  table,
  tr,
  td,
  div {
    page-break-inside: avoid;
  }
</style>

<div style="font-family:'Times New Roman',serif;width:100%;margin:0 auto;font-size:10px;line-height:1.25;">

  <!-- KOP HEADER RESMI JP BOOKS (SESUAI ACUAN RESMI JP BOOKS GAMBAR 2) -->
  <table width="100%" cellpadding="0" cellspacing="0" style="width:100%; border-collapse:collapse; margin-bottom:8px;">
    <tr>
      <td width="100%" style="width:100%; padding:0; text-align:left;">
        @if(!empty($logoJpHeader))
          <img src="{{ $logoJpHeader }}" width="700" style="width:700px; max-width:100%; height:auto;" alt="JP Books - PT. JePe Press Media Utama">
        @else
          <table width="100%" cellpadding="0" cellspacing="0"
            style="width:100%; border-collapse:collapse; border-bottom:2.5px solid #00a0e9; padding-bottom:3px;">
            <tr>
              <td style="vertical-align:middle; width:220px;">
                <table cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
                  <tr>
                    <td
                      style="background-color:#00a0e9; color:#ffffff; font-family:'Arial Black',Gadget,sans-serif; font-weight:bold; font-size:24px; padding:3px 10px; vertical-align:middle; line-height:1;">
                      JP</td>
                    <td
                      style="background-color:#f39800; color:#ffffff; font-family:'Arial Black',Gadget,sans-serif; font-weight:bold; font-size:24px; padding:3px 10px; vertical-align:middle; line-height:1;">
                      BOOKS</td>
                  </tr>
                </table>
              </td>
              <td style="vertical-align:middle; text-align:left; padding-left:14px;">
                <span
                  style="font-family:'Times New Roman',serif; font-weight:bold; font-size:20px; color:#00a0e9; letter-spacing:0.5px;">PT.
                  JePe Press Media Utama</span>
              </td>
            </tr>
          </table>
        @endif
      </td>
    </tr>
  </table>

  <!-- JUDUL & TENTANG -->
  <table style="width:100%; border-collapse:collapse; margin-top:4px; margin-bottom:4px;">
    <tr>
      <td style="text-align:center; font-weight:bold; font-size:12.5px; letter-spacing:0.5px;">
        <span style="display:inline-block; border-bottom:2px solid #000; padding-bottom:1px; line-height:1.15;">
          SURAT KEPUTUSAN
        </span>
      </td>
    </tr>
    <tr>
      <td style="text-align:center; font-weight:bold; font-size:10px; padding-top:2px;">
        No. {{ strtoupper($t_mutasi?->nomor) }}
      </td>
    </tr>
    <tr>
      <td style="text-align:center; font-weight:bold; font-size:10px; padding-top:4px; line-height:1.2;">
        TENTANG<br>
        MUTASI TEMPAT TUGAS
      </td>
    </tr>
  </table>

  <!-- BAGIAN 2: PERTIMBANGAN & PENETAPAN -->
  <table style="width:100%; border-collapse:collapse; font-size:10px; margin-top:3px;">
    <!-- MEPERHATIKAN -->
    <tr>
      <td style="width:18%; vertical-align:top; white-space:nowrap;">MEPERHATIKAN</td>
      <td style="width:3%; vertical-align:top; text-align:center;">:</td>
      <td style="width:79%;"></td>
    </tr>

    @if($memperhatikan && count($memperhatikan) > 0)
      @foreach($memperhatikan as $item)
        <tr>
          <td style="width:18%;"></td>
          <td style="width:3%; vertical-align:top; text-align:center; font-size:10px; line-height:1.2;">&bull;</td>
          <td style="width:79%; vertical-align:top; line-height:1.25; padding-bottom:1px; padding-left:4px;">
            {{ is_array($item) ? ($item['value'] ?? '') : ($item->value ?? '') }}
          </td>
        </tr>
      @endforeach
    @else
      <tr>
        <td style="width:18%;"></td>
        <td style="width:3%; vertical-align:top; text-align:center; font-size:10px; line-height:1.2;">&bull;</td>
        <td style="width:79%; vertical-align:top; line-height:1.25; padding-bottom:1px; padding-left:4px;">
          Keputusan hasil koordinasi manajemen {{ $companyName }}
        </td>
      </tr>
      <tr>
        <td style="width:18%;"></td>
        <td style="width:3%; vertical-align:top; text-align:center; font-size:10px; line-height:1.2;">&bull;</td>
        <td style="width:79%; vertical-align:top; line-height:1.25; padding-bottom:1px; padding-left:4px;">
          Upaya optimalisasi SDM di {{ $companyName }}
        </td>
      </tr>
    @endif

    <!-- SPASI ANTARA MEPERHATIKAN DAN MEMUTUSKAN -->
    <tr>
      <td colspan="3" style="height:3px;"></td>
    </tr>

    <!-- MEMUTUSKAN SERTA MENETAPKAN -->
    <tr>
      <td style="width:18%; vertical-align:bottom; line-height:1.2;">
        MEMUTUSKAN<br>
        <span style="display:inline-block; padding-left:14px;">SERTA</span><br>
        MENETAPKAN
      </td>
      <td style="width:3%; vertical-align:bottom; text-align:center;">:</td>
      <td style="width:79%; vertical-align:bottom;"></td>
    </tr>
  </table>

  <!-- BAGIAN 3: POIN KEPUTUSAN 1 & 2 -->
  <table style="width:100%; border-collapse:collapse; font-size:10px; margin-top:3px;">
    <!-- POIN 1 -->
    <tr>
      <td style="width:18%;"></td>
      <td style="width:3%; vertical-align:top; text-align:center;">1.</td>
      <td style="width:79%; vertical-align:top; line-height:1.25;">
        Terhitung efektif <b>{{$tanggalIndo}}</b>
      </td>
    </tr>

    <!-- NAMA -->
    <tr>
      <td style="width:18%;"></td>
      <td style="width:3%;"></td>
      <td style="width:79%; vertical-align:top; padding-top:1px;">
        <table style="width:100%; border-collapse:collapse; font-size:10px;">
          <tr>
            <td style="width:20px; vertical-align:middle;">
              <img src="{{ $arrowJp }}" width="15" height="8" style="vertical-align:middle; display:inline-block;"
                alt=">">
            </td>
            <td style="width:65px; vertical-align:middle; white-space:nowrap;">Nama</td>
            <td style="width:14px; vertical-align:middle; text-align:center;">:</td>
            <td style="vertical-align:middle; font-weight:bold;">
              <nobr>{{ strtoupper($t_mutasi->m_kary?->nama_lengkap ?? '-') }}</nobr>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- TEMPAT TUGAS LAMA -->
    <tr>
      <td style="width:18%;"></td>
      <td style="width:3%;"></td>
      <td style="width:79%; vertical-align:top; padding-top:3px; font-size:10px; text-decoration:underline;">
        Tempat Tugas Lama :
      </td>
    </tr>

    <!-- JABATAN & JAM KERJA LAMA -->
    <tr>
      <td style="width:18%;"></td>
      <td style="width:3%;"></td>
      <td style="width:79%; vertical-align:top; padding-top:1px;">
        <table style="width:100%; border-collapse:collapse; font-size:10px;">
          <tr>
            <td style="width:20px; vertical-align:top; padding:1px 0;">
              <img src="{{ $arrowJp }}" width="15" height="8"
                style="vertical-align:top; margin-top:2px; display:inline-block;" alt=">">
            </td>
            <td style="width:65px; vertical-align:top; padding:1px 0; white-space:nowrap;">Jabatan</td>
            <td style="width:14px; vertical-align:top; text-align:center; padding:1px 0;">:</td>
            <td style="vertical-align:top; line-height:1.25; padding:1px 0; white-space:nowrap;">
              <nobr>{{ $t_mutasi->m_posisi_lama?->name ?? '-' }}</nobr><br>
              <nobr>{{ $t_mutasi->m_sbu_lama?->name ?? ($t_mutasi->m_sub_lama?->name ?? '-') }}</nobr><br>
              <nobr>{{ $t_mutasi->m_sub_lama?->address ?? ($t_mutasi->m_branch_lama?->address ?? '') }}</nobr>
            </td>
          </tr>
          <tr>
            <td style="width:20px; vertical-align:top; padding:1px 0;">
              <img src="{{ $arrowJp }}" width="15" height="8"
                style="vertical-align:top; margin-top:2px; display:inline-block;" alt=">">
            </td>
            <td style="width:65px; vertical-align:top; padding:1px 0; white-space:nowrap;">Jam Kerja</td>
            <td style="width:14px; vertical-align:top; text-align:center; padding:1px 0;">:</td>
            <td style="vertical-align:top; padding:1px 0; white-space:nowrap;">
              <nobr>{{ $jamKerjaLama }}</nobr>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- TEMPAT TUGAS BARU -->
    <tr>
      <td style="width:18%;"></td>
      <td style="width:3%;"></td>
      <td style="width:79%; vertical-align:top; padding-top:3px; font-size:10px; text-decoration:underline;">
        Tempat Tugas Baru :
      </td>
    </tr>

    <!-- JABATAN & JAM KERJA BARU -->
    <tr>
      <td style="width:18%;"></td>
      <td style="width:3%;"></td>
      <td style="width:79%; vertical-align:top; padding-top:1px;">
        <table style="width:100%; border-collapse:collapse; font-size:10px;">
          <tr>
            <td style="width:20px; vertical-align:top; padding:1px 0;">
              <img src="{{ $arrowJp }}" width="15" height="8"
                style="vertical-align:top; margin-top:2px; display:inline-block;" alt=">">
            </td>
            <td style="width:65px; vertical-align:top; padding:1px 0; white-space:nowrap;">Jabatan</td>
            <td style="width:14px; vertical-align:top; text-align:center; padding:1px 0;">:</td>
            <td style="vertical-align:top; line-height:1.25; padding:1px 0; white-space:nowrap;">
              <nobr>{{ $t_mutasi->m_posisi_baru?->name ?? '-' }}</nobr><br>
              <nobr>{{ $t_mutasi->m_sbu_baru?->name ?? ($t_mutasi->m_sub_baru?->name ?? '-') }}</nobr><br>
              <nobr>{{ $t_mutasi->m_sub_baru?->address ?? ($t_mutasi->m_branch_baru?->address ?? '') }}</nobr>
            </td>
          </tr>
          <tr>
            <td style="width:20px; vertical-align:top; padding:1px 0;">
              <img src="{{ $arrowJp }}" width="15" height="8"
                style="vertical-align:top; margin-top:2px; display:inline-block;" alt=">">
            </td>
            <td style="width:65px; vertical-align:top; padding:1px 0; white-space:nowrap;">Jam Kerja</td>
            <td style="width:14px; vertical-align:top; text-align:center; padding:1px 0;">:</td>
            <td style="vertical-align:top; padding:1px 0; white-space:nowrap;">
              <nobr>{{ $jamKerjaBaru }}</nobr>
            </td>
          </tr>
        </table>
      </td>
    </tr>

    <!-- POIN 2 -->
    <tr>
      <td style="width:18%; vertical-align:top; padding-top:4px;"></td>
      <td style="width:3%; vertical-align:top; text-align:center; padding-top:4px;">2.</td>
      <td style="width:79%; vertical-align:top; line-height:1.25; padding-top:4px; text-align:justify;">
        Keputusan ini berlaku sejak {{ $kotaTerbit }} dan akan ditinjau kembali jika diperlukan.
      </td>
    </tr>
  </table>

  <!-- BAGIAN 4: PENUTUP & TANDA TANGAN (PERSIS GAMBAR 2) -->
  <table style="width:100%; margin-top:8px; font-size:10.5px; border-collapse:collapse;">
    <tr>
      <td style="width:55%;"></td>
      <td style="width:45%; vertical-align:top; line-height:1.35;">
        <table style="border-collapse:collapse; font-size:10.5px;">
          <tr>
            <td style="padding-bottom:1px; white-space:nowrap;">Dikeluarkan di</td>
            <td style="padding:0 6px 1px 14px; text-align:center;">:</td>
            <td style="padding-bottom:1px; white-space:nowrap;">{{ $kotaTerbit }}</td>
          </tr>
          <tr>
            <td style="padding-bottom:1px; white-space:nowrap;">Pada Tanggal</td>
            <td style="padding:0 6px 1px 14px; text-align:center;">:</td>
            <td style="padding-bottom:1px; white-space:nowrap;">{{ $tanggalTerbit }}</td>
          </tr>
        </table>
        <div style="margin-top:6px; white-space:nowrap;">
          {{ $companyName }}
        </div>
        <div style="height:32px;"></div>
        @if(!empty($t_mutasi->signature?->nama_lengkap))
          <div style="font-weight:bold; white-space:nowrap;">
            {{ strtoupper($t_mutasi->signature->nama_lengkap) }}
          </div>
          <div style="font-style:italic; font-weight:bold; white-space:nowrap;">
            {{ strtoupper($t_mutasi->signature->m_posisi?->name ?? 'HUMAN CAPITAL DEPT.') }}
          </div>
        @else
          <div style="font-weight:bold; white-space:nowrap;">
            NAMA YANG TTD
          </div>
          <div style="font-style:italic; font-weight:bold; white-space:nowrap;">
            JABATAN
          </div>
        @endif
      </td>
    </tr>
  </table>

  <!-- BAGIAN 5: TEMBUSAN (PERSIS GAMBAR 2) -->
  <table style="width:100%; margin-top:6px; font-size:9.5px; border-collapse:collapse;">
    <tr>
      <td style="width:100%; line-height:1.3;">
        Tembusan&nbsp;&nbsp;&nbsp;&nbsp;:<br>
        <div style="padding-left:14px; margin-top:1px;">
          @if($tembusan && count($tembusan) > 0)
            @foreach($tembusan as $index => $t)
              {{ $index + 1 }}. {{ is_array($t) ? ($t['value'] ?? '') : ($t->value ?? '') }}<br>
            @endforeach
          @elseif($isJpBooks)
            1. Direksi Holding<br>
            2. Direksi PT JPMU<br>
            3. HRD Cabang
          @else
            1. Direksi<br>
            2. Human Capital Dept.<br>
            3. Yang Bersangkutan<br>
            4. Arsip
          @endif
        </div>
      </td>
    </tr>
  </table>

  <!-- BAGIAN 6: FOOTER RESMI JP BOOKS -->
  @if($footerJp)
    <table width="100%" cellpadding="0" cellspacing="0" style="width:100%; border-collapse:collapse; margin-top:6px;">
      <tr>
        <td width="100%" style="width:100%; padding:0; text-align:left;">
          <img src="{{ $footerJp }}" style="width:100%; max-height:65px; height:auto; display:block;"
            alt="Footer JP Books">
        </td>
      </tr>
    </table>
  @else
    @include('projects.web_sk_footer')
  @endif

</div>