<!-- LANDING -->
@if(!$req->has('id'))
  <div class="bg-white p-1 rounded-md border-t-10 border-gray-500">
    <div class="flex justify-between items-center px-2.5 py-1">
      <div class="flex flex-col md:flex-row md:items-center gap-y-2 md:gap-y-0 gap-x-4">
        <p class="font-semibold">Filter Status:</p>

        <!-- Dropdown Mobile -->
        <div class="block md:hidden">
          <select @change="onStatusChange" class="border rounded-md text-sm py-1 px-2.5 w-full">
            <option value="">Pilih Status</option>
            <option value="1">Pending</option>
            <option value="2">Proses</option>
            <option value="3">Half Approved</option>
            <option value="4">Diterima</option>
            <option value="5">Tidak Diterima</option>
          </select>
        </div>

        <!-- Button Desktop -->
        <div class="hidden md:flex flex-wrap gap-2">

          <button @click="filterShowData('Pending',1)" :class="activeBtn === 1 
              ? 'bg-gray-700 text-white' 
              : 'border border-gray-700 text-gray-700 bg-white hover:bg-gray-700 hover:text-white'"
            class="rounded-md text-sm py-1 px-3 transition-all duration-300">
            Pending
          </button>

          <button @click="filterShowData('Proses',2)" :class="activeBtn === 2 
              ? 'bg-blue-600 text-white' 
              : 'border border-blue-600 text-blue-600 bg-white hover:bg-blue-600 hover:text-white'"
            class="rounded-md text-sm py-1 px-3 transition-all duration-300">
            Proses
          </button>

          <button @click="filterShowData('Half Approved',3)" :class="activeBtn === 3 
              ? 'bg-yellow-600 text-white' 
              : 'border border-yellow-600 text-yellow-600 bg-white hover:bg-yellow-600 hover:text-white'"
            class="rounded-md text-sm py-1 px-3 transition-all duration-300">
            Half Approved
          </button>

          <button @click="filterShowData('Diterima',4)" :class="activeBtn === 4 
              ? 'bg-green-600 text-white' 
              : 'border border-green-600 text-green-600 bg-white hover:bg-green-600 hover:text-white'"
            class="rounded-md text-sm py-1 px-3 transition-all duration-300">
            Diterima
          </button>

          <button @click="filterShowData('Tidak Diterima',5)" :class="activeBtn === 5 
              ? 'bg-red-600 text-white' 
              : 'border border-red-600 text-red-600 bg-white hover:bg-red-600 hover:text-white'"
            class="rounded-md text-sm py-1 px-3 transition-all duration-300">
            Tidak Diterima
          </button>

        </div>
      </div>
      <div>
        <RouterLink v-if="data?.can_create" :to="$route.path+'/create?'+(Date.parse(new Date()))"
          class="border border-blue-600 text-blue-600 bg-white  hover:bg-blue-600 hover:text-white duration-300 transform hover:-translate-y-0.5 rounded-md py-1 px-2">
          Create New
        </RouterLink>
      </div>
    </div>
    <hr>
    <TableApi ref='apiTable' :api="landing.api" :columns="landing.columns" :actions="landing.actions" class="">
      <!-- <template #header>
      </template> -->
    </TableApi>
  </div>
@else

  <!-- CONTENT -->
  @verbatim
    <div class="flex flex-col border rounded-md shadow-md md:w-full w-full p-0 bg-white border-none">
      <div class="bg-gray-500 text-white rounded-t-md py-2 px-4">
        <div class="flex items-center">
          <Icon fa="arrow-left" class="cursor-pointer mr-2 font-bold hover:text-yellow-500" title="Kembali"
            @click="onBack" />
          <div>
            <h1 class="text-20px font-bold">Form Hasil Test</h1>
            <p class="text-gray-100">Transaksi Hasil Test</p>
          </div>
        </div>
      </div>

      <!-- Banner Peninjauan & Persetujuan Pengaju Recruitment -->
      <div v-if="canShowApprovalActions" class="bg-amber-50 border-l-4 border-amber-500 p-3 mx-4 mt-4 rounded-r shadow-sm">
        <div class="flex items-center">
          <icon fa="info-circle" class="text-amber-600 mr-2 text-xl" />
          <div>
            <p class="text-sm text-amber-900 font-bold">
              Menunggu Persetujuan Anda (Pengaju Recruitment / Manager)
            </p>
            <p class="text-xs text-amber-700 mt-0.5">
              Silakan periksa data hasil dan nilai seleksi pelamar di bawah ini. Klik tombol <b>Approve</b>, <b>Reject</b>, atau <b>Revise</b> di bagian bawah untuk memproses persetujuan.
            </p>
          </div>
        </div>
      </div>

      <div class="p-4 grid <md:grid-cols-1 grid-cols-2 gap-2">
        <!-- START COLUMN -->
        <div>
          <FieldX :bind="{ readonly: true }" :value="values.nomor" :errorText="formErrors.nomor?'failed':''"
            @input="v=>values.nomor=v" :hints="formErrors.nomor" :check="false" class="w-full !mt-3" label="Nomor"
            placeholder="Auto Generate By System" />
        </div>

        <!-- 1. PILIH LOWONGAN KERJA TERLEBIH DAHULU (EXCLUDE CLOSED) -->
        <div>
          <FieldPopup class="w-full !mt-3" :bind="{ readonly: !actionText }" :value="values.t_loker_id"
            @input="onLokerChange" :errorText="formErrors.t_loker_id ? 'failed' : ''" :hints="formErrors.t_loker_id"
            valueField="id" displayField="title" :api="{
              url: `${store.server.url_backend}/operation/t_loker`,
              headers: { 'Content-Type': 'Application/json', Authorization: `${store.user.token_type} ${store.user.token}`},
              params: {
                simplest: true,
                join: true,
                transform: true,
                scopes: 'notclosed'
              }
            }" placeholder="Pilih Lowongan Kerja" label="Nama Lowongan Kerja" :check="false" :columns="[
              { headerName: 'No', valueGetter: (params) => params.node.rowIndex + 1, width: 60 },
              { headerName: 'Kode', field: 'nomor', width: 160 },
              { headerName: 'Nama Lowongan', field: 'title', flex: 1 },
              { headerName: 'Posisi', field: 'm_posisi.name', width: 150 },
              { headerName: 'Status', field: 'status', width: 110 }
            ]" />
        </div>

        <!-- 2. PILIH PELAMAR SESUAI LOKER YANG DIPILIH -->
        <div>
          <FieldPopup class="w-full !mt-3" :bind="{ readonly: !actionText || !values.t_loker_id }"
            :value="values.t_pelamar_id" @input="v => values.t_pelamar_id = v"
            :errorText="formErrors.t_pelamar_id ? 'failed' : ''" :hints="formErrors.t_pelamar_id" valueField="id"
            displayField="nama_depan" :api="{
              url: `${store.server.url_backend}/operation/t_pelamar`,
              headers: { 'Content-Type': 'Application/json', Authorization: `${store.user.token_type} ${store.user.token}`},
              params: {
                simplest: true,
                transform: true,
                join: true,
                scopes: 'loker',
                t_loker_id: values.t_loker_id || 0,
                current_pelamar_id: values.t_pelamar_id || 0
              }
            }" :placeholder="values.t_loker_id ? 'Pilih Pelamar' : 'Pilih Lowongan Kerja Terlebih Dahulu'"
            label="Nama Pelamar" :check="false" :columns="[
              { headerName: 'No', valueGetter: (params) => params.node.rowIndex + 1, width: 60 },
              { headerName: 'Kode Pelamar', field: 'nomor', width: 160 },
              { headerName: 'Nama Depan', field: 'nama_depan', flex: 1 },
              { headerName: 'Nama Belakang', field: 'nama_belakang', flex: 1 },
              { headerName: 'No. KTP', field: 'ktp_no', width: 160 },
              { headerName: 'Status', field: 'status', width: 100 }
            ]" />
        </div>

        <div>
          <FieldSelect :bind="{ disabled: !actionText, clearable:false }" :value="values.tahapan_id" class="w-full !mt-3"
            @input="v=>values.tahapan_id=v" :errorText="formErrors.tahapan_id?'failed':''" :hints="formErrors.tahapan_id"
            valueField="id" displayField="value" :api="{
                url: `${store.server.url_backend}/operation/m_general`,
                headers: { 'Content-Type': 'Application/json', Authorization: `${store.user.token_type} ${store.user.token}`},
                params: {
                  where: `this.group = 'TAHAPAN-PENERIMAAN-KARYAWAN'`,
                  simplest: true,
                  transform: false,
                  join: false
                }
            }" placeholder="Pilih Tahapan" label="Tahapan" fa-icon="" :check="false" />
        </div>

        <div>
          <FieldX :bind="{ readonly: !actionText }" :value="values.deskripsi" :errorText="formErrors.deskripsi?'failed':''"
            @input="v=>values.deskripsi=v" :hints="formErrors.deskripsi" :check="false" class="w-full !mt-3" label="Catatan"
            placeholder="Tulis Catatan" />
        </div>

        <div>
          <FieldSelect class="w-full !mt-3"
            :bind="{ disabled: !actionText || ['HALF APPROVED', 'DITERIMA', 'TIDAK DITERIMA'].includes(values.status), clearable:false }"
            :value="values.status" @input="v=>values.status=v" :errorText="formErrors.status?'failed':''"
            :hints="formErrors.status" valueField="value" displayField="value" :options="statusOptions"
            placeholder="Pilih Status" label="Status" fa-icon="" :check="false" />
        </div>

        <!-- END COLUMN -->
        <!-- ACTION BUTTON START -->
      </div>

      <div class="grid grid-cols-8 md:grid-cols-12 text-[14px] gap-x-[29px] gap-y-[26px] mx-4">

        <div class="col-span-8 md:col-span-12">
          <button v-if="actionText" @click="addDetail" type="button"
            class="bg-[#005FBF] hover:bg-[#0055ab] text-white py-[12px] px-[19.5px] flex items-center justify-center space-x-2 rounded">
            <icon fa="plus" /> <span>Add to List</span>
          </button>
          <div class="mx-1 mt-4">
            <table class="w-full overflow-x-auto table-auto border border-[#CACACA]">
              <thead>
                <tr class="border">
                  <td
                    class="text-[#8F8F8F] font-semibold text-[14px] text-capitalize px-2 py-[14.5px] text-center w-[5%] border bg-[#f8f8f8] border-[#CACACA]">
                    No.</td>
                  <td
                    class="text-[#8F8F8F] font-semibold text-[14px] text-capitalize px-2 text-center border bg-[#f8f8f8] border-[#CACACA]">
                    Tanggal</td>
                  <td
                    class="text-[#8F8F8F] font-semibold text-[14px] text-capitalize px-2 text-center border bg-[#f8f8f8] border-[#CACACA]">
                    Nama Test</td>
                  <td
                    class="text-[#8F8F8F] font-semibold text-[14px] text-capitalize px-2 text-center border bg-[#f8f8f8] border-[#CACACA]">
                    Nilai Test</td>
                  <td
                    class="text-[#8F8F8F] font-semibold text-[14px] text-capitalize px-2 text-center border bg-[#f8f8f8] border-[#CACACA]">
                    Dokumen</td>
                  <td
                    class="text-[#8F8F8F] font-semibold text-[14px] text-capitalize px-2 text-center border w-[5%] bg-[#f8f8f8] border-[#CACACA]">
                    Aksi</td>
                </tr>
              </thead>
              <tbody>
                <tr v-for="(item, i) in detailArr" :key="item.id" class="border-t" v-if="detailArr.length > 0">
                  <td class="p-2 text-center border border-[#CACACA]">
                    {{ i + 1 }}.
                  </td>
                  <!-- <td class="p-2 border border-[#CACACA]">
                    <FieldSelect
                      :bind="{ disabled: !actionText, clearable:false }"
                      :value="item.m_divisi_id" @input="v=>item.m_divisi_id=v"
                      :errorText="formErrors.m_divisi_id?'failed':''" 
                      :hints="formErrors.m_divisi_id"
                      valueField="id" displayField="name.value"
                      :api="{
                          url: `${store.server.url_backend}/operation/m_divisi`,
                          headers: { 'Content-Type': 'Application/json', Authorization: `${store.user.token_type} ${store.user.token}`},
                          params: {
                            where: `this.is_active = true`,
                            scopes:'Name',
                            simplest:true,
                            transform:false,
                            join:false
                          }
                      }"
                      placeholder="" label="" fa-icon="" :check="false"
                    />
                  </td> -->
                  <td class="p-2 border border-[#CACACA]">
                    <FieldX type="date" :bind="{ readonly: !actionText }" :value="item.tanggal"
                      :errorText="formErrors.tanggal?'failed':''" @input="v=>item.tanggal=v" :hints="formErrors.tanggal"
                      placeholder="Masukkan Tanggal" label="" fa-icon="" :check="false" />
                  </td>

                  <td class="p-2 border border-[#CACACA]">
                    <FieldSelect :bind="{ disabled: !actionText, clearable: false }" :value="item.nama_tes"
                      @input="v=>item.nama_tes=v" :errorText="formErrors.nama_tes?'failed':''" :hints="formErrors.nama_tes"
                      valueField="value" displayField="value" :api="{
                          url: `${store.server.url_backend}/operation/m_general`,
                          headers: { 'Content-Type': 'Application/json', Authorization: `${store.user.token_type} ${store.user.token}`},
                          params: {
                            where: `this.group = 'NAMA-TEST-PELAMAR'`,
                            simplest: true,
                            transform: false,
                            join: false
                          }
                      }" placeholder="Pilih Nama Test" label="" fa-icon="" :check="false" />
                  </td>

                  <td class="p-2 border border-[#CACACA]">
                    <FieldX :bind="{ readonly: !actionText }" type="number" step="any" min="0" max="100"
                      class="w-full !mt-0" :value="item.nilai_tes" :errorText="formErrors.nilai_tes?'failed':''"
                      @input="v=>item.nilai_tes=v" :hints="formErrors.nilai_tes" placeholder="Masukkan Nilai Test" label=""
                      fa-icon="" :check="false" />
                  </td>

                  <td>
                    <FieldUpload :value="item.dokumen" @input="(v)=>item.dokumen=v" :maxSize="10"
                      :reducerDisplay="val=>!val?null:val.split(':::')[val.split(':::').length-1]" :api="{
                        url: `${store.server.url_backend}/operation/t_hasil_tes_det/upload`,
                        headers: { Authorization: `${store.user.token_type} ${store.user.token}`},
                        params: { field: 'dokumen' },
                        onsuccess: response=>response,
                        onerror:(error)=>{},
                       }" :hints="formErrors.dokumen" placeholder="Upload Dokumen" label="" fa-icon="upload" accept="*"
                      :check="false" />

                  </td>

                  <td class="p-2 border border-[#CACACA]">
                    <div class="flex justify-center">
                      <button type="button" @click="removeDetail(item)" v-if="actionText">
                        <svg width="14" height="18" viewBox="0 0 14 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path id="Vector"
                            d="M14 1H10.5L9.5 0H4.5L3.5 1H0V3H14M1 16C1 16.5304 1.21071 17.0391 1.58579 17.4142C1.96086 17.7893 2.46957 18 3 18H11C11.5304 18 12.0391 17.7893 12.4142 17.4142C12.7893 17.0391 13 16.5304 13 16V4H1V16Z"
                            fill="#F24E1E" />
                        </svg>
                      </button>
                    </div>

                  </td>
                </tr>
                <tr v-else class="text-center">
                  <td colspan="7" class="py-[20px]">
                    No data to show
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!--BUTTON-->
      </div>

      <hr>

      <div class="flex flex-row items-center justify-end space-x-2 p-2">
        <i class="text-gray-500 text-[12px]">Tekan CTRL + S untuk shortcut Save Data</i>
        
        <!-- Tombol Approval untuk Pengaju Recruitment / Manager (Muncul saat is_approval atau can_approve) -->
        <button v-show="canShowApprovalActions"
          class="mx-1 bg-green-600 text-white hover:bg-green-700 font-semibold rounded-lg py-[8px] px-[24px] transition-transform duration-300 transform hover:-translate-y-0.5"
          @click="onProcess('approve')">
          <icon fa="check" class="mr-1" />
          Approve
        </button>
        <button v-show="canShowApprovalActions"
          class="mx-1 bg-rose-600 text-white hover:bg-rose-700 font-semibold rounded-lg py-[8px] px-[24px] transition-transform duration-300 transform hover:-translate-y-0.5"
          @click="onProcess('reject')">
          <icon fa="times" class="mr-1" />
          Reject
        </button>
        <button v-show="canShowApprovalActions"
          class="mx-1 bg-amber-500 text-white hover:bg-amber-600 font-semibold rounded-lg py-[8px] px-[24px] transition-transform duration-300 transform hover:-translate-y-0.5"
          @click="onProcess('revise')">
          <icon fa="undo" class="mr-1" />
          Revise
        </button>
        <!-- Keputusan Final HC saat status HALF APPROVED -->
        <button
          class="bg-green-600 text-white font-semibold hover:bg-green-500 transition-transform duration-300 transform hover:-translate-y-0.5 rounded-md p-2"
          v-show="isRead && values.status === 'HALF APPROVED' && isHC" @click="onApproveHC()">
          <icon fa="check" />
          Diterima (Approve HC)
        </button>
        <button
          class="bg-rose-600 text-white font-semibold hover:bg-rose-500 transition-transform duration-300 transform hover:-translate-y-0.5 rounded-md p-2"
          v-show="isRead && values.status === 'HALF APPROVED' && isHC" @click="onRejectHC()">
          <icon fa="times" />
          Tidak Diterima (Reject HC)
        </button>

        <button
          class="bg-indigo-600 text-white font-semibold hover:bg-indigo-500 transition-transform duration-300 transform hover:-translate-y-0.5 rounded-md p-2"
          v-show="isRead && (values.status === 'PENDING' || values.status === 'DRAFT' || values.status === 'REVISED')" @click="onSendApproval()">
          <icon fa="paper-plane" />
          Kirim Approval
        </button>
        <button
          class="bg-blue-600 text-white font-semibold hover:bg-blue-500 transition-transform duration-300 transform hover:-translate-y-0.5 rounded-md p-2"
          v-show="isRead" @click="onPrint()">
          <icon fa="print" />
          Print
        </button>
        <button
          class="bg-red-600 text-white font-semibold hover:bg-red-500 transition-transform duration-300 transform hover:-translate-y-0.5 rounded-md p-2"
          v-show="actionText" @click="onReset(true)">
          <icon fa="times" />
          Reset
        </button>
        <button
          class="bg-green-600 text-white font-semibold hover:bg-green-500 transition-transform duration-300 transform hover:-translate-y-0.5 rounded-md p-2"
          v-show="actionText" @click="onSave">
          <icon fa="save" />
          Simpan
        </button>
      </div>
    </div>
  @endverbatim
@endif