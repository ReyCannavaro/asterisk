<?php
 // blade php file