//   javascript

import { useRouter, useRoute, RouterLink } from 'vue-router'
import { ref, readonly, reactive, inject, onMounted, onBeforeMount, watchEffect, onActivated } from 'vue'

const router = useRouter()
const route = useRoute()
const store = inject('store')
const swal = inject('swal')

const isRead = route.params.id && route.params.id !== 'create'
const actionText = ref(route.params.id === 'create' ? 'Tambah' : route.query.action)
const isBadForm = ref(false)
const isRequesting = ref(false)
const modulPath = route.params.modul
const currentMenu = store.currentMenu
const apiTable = ref(null)
const formErrors = ref({})
const tsId = `ts=`+(Date.parse(new Date()))
const detail = ref(null)

// ------------------------------ PERSIAPAN
const endpointApi = '/default_users'
onBeforeMount(()=>{
  document.title = 'Master Role Akses'
  // tampilkan default direktorat dengan store user comp.nama
  values.direktorat = store.user.data?.direktorat
})

//  @if( $id )------------------- VALUES FORM ! PENTING JANGAN DIHAPUS
let initialValues = {}
const changedValues = []
let trx_dtl = ref([])

const onDetailAdd = (rows) => {
  let stop = false
  let dataArr = [...trx_dtl.value]
  trx_dtl.value.forEach(row => {
    if(row.is_superadmin && trx_dtl.value.length){
      swal.fire({
        icon: 'warning',
        text: "User ini sudah memiliki akses role superadmin, tidak dapat menambah role yang lain"
      })
      stop = true
      return
    }
  })
  if(stop) return
  rows.forEach(row => {
    if (dataArr.some(existing => existing.id === row.id || existing.m_role_id === row.id)) {
      return
    }
    row.m_role_id = row.id
    if(row.is_superadmin && trx_dtl.value.length){
      swal.fire({
        icon: 'warning',
        text: "Menambahkan role superadmin, role yang lain akan dihapus oleh sistem"
      })
      dataArr = []
      dataArr.push(row)
      trx_dtl.value = dataArr
      return
    }
    dataArr.push(row)
  })
  trx_dtl.value = dataArr
}

const values = reactive({
  is_superadmin: false,
  is_active: true
})


onBeforeMount(async () => {
  if (isRead) {
    //  READ DATA
    try {
      const editedId = route.params.id
      const dataURL = `${store.server.url_backend}/operation/default_users/${editedId}`
      isRequesting.value = true

      const params = { join: true, transform: false, from : 'role_access', detail: true }
      const fixedParams = new URLSearchParams(params)
      const res = await fetch(dataURL + '?' + fixedParams, {
        headers: {
          'Content-Type': 'Application/json',
          Authorization: `${store.user.token_type} ${store.user.token}`
        },
      })
      if (!res.ok) throw new Error("Failed when trying to read data")
      const resultJson = await res.json()
      initialValues = resultJson.data

      resultJson?.data?.detail.forEach((v)=>{
        v.m_role_id = v.id
      })
      trx_dtl.value = resultJson?.data.detail ?? []

    } catch (err) {
      isBadForm.value = true
      swal.fire({
        icon: 'error',
        text: err,
        allowOutsideClick: false,
        confirmButtonText: 'Kembali',
      }).then(() => {
        router.back()
      })
    }
    isRequesting.value = false
  }

  for (const key in initialValues) {
    values[key] = initialValues[key]
  }
})

function onBack() {
  let isChanged = false
  for (const key in initialValues) {
    if (values[key] !== initialValues[key]) {
      isChanged = true
      break;
    }
  }

  if (!isChanged) {
    router.replace('/' + modulPath)
    return
  }

  swal.fire({
    icon: 'warning',
    text: 'Buang semua perubahan dan kembali ke list data?',
    showDenyButton: true
  }).then((res) => {
    if (res.isConfirmed) {
      router.replace('/' + modulPath)
    }
  })
}

function onReset() {
  swal.fire({
    icon: 'warning',
    text: 'Reset this form data?',
    showDenyButton: true
  }).then((res) => {
    if (res.isConfirmed) {
      for (const key in initialValues) {
        values[key] = initialValues[key]
      }
      values.company = initialValues['m_comp.nama'] || initialValues['m_dir.nama'] || initialValues.company || initialValues.direktorat || ''
      values.username = initialValues.username || ''
      values.email = initialValues.email || ''
    }
  })
}

function onSave() {
  if (!trx_dtl.value || trx_dtl.value.length === 0) {
    swal.fire({
      icon: 'warning',
      text: 'Detail hak akses wajib diisi minimal 1 role'
    })
    return
  }
  //values.tags = JSON.stringify(values.tags)
  values.detail = trx_dtl.value
  for(const i in values.detail) {
    for(const k in values.detail[i]){
      if(typeof values.detail[i][k] == 'boolean'){
        values.detail[i][k] = values.detail[i][k] ? 1 : 0
      }
    }
  }
  swal.fire({
    icon: 'warning',
    text: 'Save data?',
    showDenyButton: true
  }).then(async (res) => {
    if (res.isConfirmed) {
      try {
        const isCreating = ['Create','Copy','Tambah'].includes(actionText.value)
        const dataURL = `${store.server.url_backend}/operation/m_role_access/store`
        isRequesting.value = true
        values.pengguna_id = route.params.id ?? 0
        if(!values.pengguna_id || values.pengguna_id == null) 
        return  swal.fire({
                  icon: 'error',
                  text: 'User invalid'
                })
        const res = await fetch(dataURL, {
          method: isCreating ? 'POST' : 'PUT',
          headers: {
            'Content-Type': 'Application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`
          },
          body: JSON.stringify(values)
        })
        if (!res.ok) {
          if ([400, 422].includes(res.status)) {
            const responseJson = await res.json()
            formErrors.value = responseJson.errors || {}
            throw new Error(responseJson.errors || responseJson.message || "Failed when trying to post data")
          } else {
            throw new Error("Failed when trying to post data")
          }
        }
        router.replace('/' + modulPath + '?reload='+(Date.parse(new Date())))
      } catch (err) {
        console.log("ERR ",  err)
        isBadForm.value = true
        swal.fire({
          icon: 'error',
          text: err
        })
      }
      isRequesting.value = false
    }
  })
}

//  @else----------------------- LANDING
const activeBtn = ref(null)

function filterShowData(params, noBtn) {
  if (activeBtn.value === noBtn) {
    activeBtn.value = null
    landing.api.params.where = null
  } else {
    activeBtn.value = noBtn
    landing.api.params.where = `this.is_active=${params ? 'true' : 'false'}`
  }

  if (apiTable.value) {
    apiTable.value.reload()
  }
}

const landing = reactive({
  actions: [
    {
      icon: 'eye',
      title: "Read",
      class: 'bg-green-600 text-light-100',
      // show: (row) => (currentMenu?.can_read)||store.user.data.username==='developer',
      click(row) {
        router.push(`${route.path}/${row.id}?`+tsId)
      }
    },
    {
      icon: 'edit',
      title: "Edit",
      class: 'bg-blue-600 text-light-100',
      // show: (row) => (currentMenu?.can_update)||store.user.data.username==='developer',
      click(row) {
        router.push(`${route.path}/${row.id}?action=Edit&`+tsId)
      }
    }
  ],
  api: {
    url: `${store.server.url_backend}/operation${endpointApi}`,
    headers: {
      'Content-Type': 'Application/json',
      authorization: `${store.user.token_type} ${store.user.token}`
    },
    params: {
      simplest: true,
      from : 'role_access'
    },
    onsuccess(response) {
      if (response && response.data) {
        response.data = response.data.map((item) => {
          item.status = (item.is_active === true || item.is_active === 1 || item.is_active === '1' || item.is_active === 'true' || item.is_active === 't') ? 'Active' : 'Inactive'
          item.company = item['m_comp.nama'] || item['m_dir.nama'] || item.company || '-'
          return item
        })
      }
      response.page = response.current_page
      response.hasNext = response.has_next
      return response
    }
  },
  columns: [{
    headerName: 'No',
    valueGetter: (params) => params.node.rowIndex + 1,
    width: 60,
    sortable: true,
    resizable: true,
    filter: true,
    cellClass: ['justify-center', 'bg-gray-50', 'border-r', '!border-gray-200']
  },
  {
    headerName: 'Nama Karyawan',
    field: 'name',
    filter: true,
    sortable: true,
    flex:1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: [ 'border-r', '!border-gray-200']
  },
  {
    headerName: 'Username',
    field: 'username',
    filter: true,
    sortable: true,
    flex:1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: [ 'border-r', '!border-gray-200']
  },
  {
    headerName: 'Company',
    field: 'company',
    filter: true,
    sortable: true,
    flex:1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: [ 'border-r', '!border-gray-200'],
    valueGetter: (params) => {
      return params.data ? (params.data.company || params.data['m_comp.nama'] || params.data['m_dir.nama'] || '-') : '-'
    }
  },
  {
    headerName: 'Role',
    field: 'role_names',
    filter: true,
    sortable: true,
    flex:1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: [ 'border-r', '!border-gray-200'],
    valueGetter: (params) => {
      return params.data ? (params.data.role_names || '-') : '-'
    }
  },
  {
    headerName: 'Status',
    field: 'status',
    sortable: true,
    resizable: true,
    flex: 1,
    cellClass: [ 'border-r', '!border-gray-200', 'justify-center'],
    valueGetter: (params) => {
      const val = params.data ? (params.data.status !== undefined ? params.data.status : params.data.is_active) : params.value
      return (val === 'Active' || val === true || val === 1 || val === '1' || val === 'true' || val === 't') ? 'Active' : 'Inactive'
    },
    cellRenderer: ({ value }) => {
      return value === 'Active' || value === true
        ? `<span class="text-green-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">Active</span>`
        : `<span class="text-gray-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">Inactive</span>`
    }
  },
  ]
})
onActivated(() => {
  //  reload table api landing
  if (apiTable.value) {
    if (route.query.reload) {
      apiTable.value.reload()
    }
  }
})

//  @endif -------------------------------------------------END
watchEffect(()=>store.commit('set', ['isRequesting', isRequesting.value]))
