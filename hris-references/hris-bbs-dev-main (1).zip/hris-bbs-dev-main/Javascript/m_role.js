//   javascript

import { useRouter, useRoute, RouterLink } from 'vue-router'
import { ref, readonly, reactive, inject, onMounted, onBeforeMount, watchEffect, onActivated, watch } from 'vue'

const router = useRouter()
const route = useRoute()
const store = inject('store')
const swal = inject('swal')

const isRead = route.params.id && route.params.id !== 'create'
const actionText = ref(route.params.id === 'create' ? 'Tambah' : route.query.action)
const isBadForm = ref(false)
const isRequesting = ref(false)
const modulPath = route.params.modul
const currentMenu = store.currentMenu
const apiTable = ref(null)
const formErrors = ref({})
const tsId = `ts=`+(Date.parse(new Date()))
const detail = ref(null)

// ------------------------------ PERSIAPAN
const endpointApi = '/m_role'
onBeforeMount(()=>{
  document.title = 'Master Role'
  // tampilkan default direktorat dengan store user comp.nama
  values.direktorat = store.user.data?.direktorat
})

//  @if( $id )------------------- VALUES FORM ! PENTING JANGAN DIHAPUS
let initialValues = {}
const changedValues = []
let trx_dtl = ref([])

const onDetailAdd = (rows) => {
  const dataArr = [...trx_dtl.value]
  rows.forEach(row => {
    row.m_menu_id = row.id
    dataArr.push(row)
  })
  trx_dtl.value = dataArr

}

function deleteAll() {
detail.value.key++
}

const values = reactive({
  is_superadmin: false,
  is_active: true
})


onBeforeMount(async () => {
  if (isRead) {
    //  READ DATA
    try {
      const editedId = route.params.id
      const dataURL = `${store.server.url_backend}/operation${endpointApi}/${editedId}`
      isRequesting.value = true

      const params = { join: true, transform: false }
      const fixedParams = new URLSearchParams(params)
      const res = await fetch(dataURL + '?' + fixedParams, {
        headers: {
          'Content-Type': 'Application/json',
          Authorization: `${store.user.token_type} ${store.user.token}`
        },
      })
      if (!res.ok) throw new Error("Failed when trying to read data")
      const resultJson = await res.json()
      initialValues = resultJson.data

      initialValues.username = initialValues['default_user.username']
      initialValues.email = initialValues['default_user.email']
      const resDet = await fetch(`${store.server.url_backend}/operation/m_role_det?where=m_role_id=${editedId ?? 0}`, {
        headers: {
          'Content-Type': 'Application/json',
          Authorization: `${store.user.token_type} ${store.user.token}`
        },
      })

      const resultJsonDet = await resDet.json()
      console.log(resultJsonDet);
      resultJsonDet?.data.forEach((d)=>{
        d.menu = d['m_menu.menu']
      })
      trx_dtl.value = resultJsonDet?.data ?? []

    } catch (err) {
      isBadForm.value = true
      swal.fire({
        icon: 'error',
        text: err,
        allowOutsideClick: false,
        confirmButtonText: 'Kembali',
      }).then(() => {
        router.back()
      })
    }
    isRequesting.value = false
  }

  for (const key in initialValues) {
    values[key] = initialValues[key]
  }
  values.is_superadmin = (values.is_superadmin === true || values.is_superadmin === 1 || values.is_superadmin === '1' || values.is_superadmin === 'true' || values.is_superadmin === 't')
  values.is_active = (values.is_active === true || values.is_active === 1 || values.is_active === '1' || values.is_active === 'true' || values.is_active === 't')
})

function onBack() {
  let isChanged = false
  for (const key in initialValues) {
    if (values[key] !== initialValues[key]) {
      isChanged = true
      break;
    }
  }

  if (!isChanged) {
    router.replace('/' + modulPath)
    return
  }

  swal.fire({
    icon: 'warning',
    text: 'Buang semua perubahan dan kembali ke list data?',
    showDenyButton: true
  }).then((res) => {
    if (res.isConfirmed) {
      router.replace('/' + modulPath)
    }
  })
}

function onReset() {
  swal.fire({
    icon: 'warning',
    text: 'Reset this form data?',
    showDenyButton: true
  }).then((res) => {
    if (res.isConfirmed) {
      for (const key in initialValues) {
        values[key] = initialValues[key]
      }
      values.is_superadmin = (values.is_superadmin === true || values.is_superadmin === 1 || values.is_superadmin === '1' || values.is_superadmin === 'true' || values.is_superadmin === 't')
      values.is_active = (values.is_active === true || values.is_active === 1 || values.is_active === '1' || values.is_active === 'true' || values.is_active === 't')
    }
  })
}

function clearAll(){
  trx_dtl.value = []
}

function onSave() {
  formErrors.value = {}
  if (!values.name || String(values.name).trim() === '') {
    formErrors.value.name = ['Kolom Nama wajib diisi']
  }

  if (Object.keys(formErrors.value).length > 0) {
    return swal.fire({
      icon: 'error',
      text: 'Harap lengkapi semua kolom yang bertanda bintang (*)'
    })
  }

  if (!trx_dtl.value || trx_dtl.value.length === 0) {
    return swal.fire({
      icon: 'error',
      text: 'Detail hak akses menu wajib diisi minimal 1 menu'
    })
  }

  values.m_role_det = trx_dtl.value
  for (const i in values.m_role_det) {
    for (const k in values.m_role_det[i]) {
      if (typeof values.m_role_det[i][k] === 'boolean') {
        values.m_role_det[i][k] = values.m_role_det[i][k] ? 1 : 0
      }
    }
  }

  swal.fire({
    icon: 'warning',
    text: 'Save data?',
    showDenyButton: true
  }).then(async (res) => {
    if (res.isConfirmed) {
      try {
        const isCreating = ['Create','Copy','Tambah'].includes(actionText.value)
        const dataURL = `${store.server.url_backend}/operation${endpointApi}${isCreating ? '' : ('/' + route.params.id)}`
        isRequesting.value = true

        const payload = Object.assign({}, values, {
          is_active: values.is_active ? 1 : 0,
          is_superadmin: values.is_superadmin ? 1 : 0
        })

        const res = await fetch(dataURL, {
          method: isCreating ? 'POST' : 'PUT',
          headers: {
            'Content-Type': 'Application/json',
            Authorization: `${store.user.token_type} ${store.user.token}`
          },
          body: JSON.stringify(payload)
        })
        if (!res.ok) {
          if ([400, 422].includes(res.status)) {
            const responseJson = await res.json()
            formErrors.value = responseJson.errors || {}
            const errMsg = (Array.isArray(responseJson.errors) ? responseJson.errors[0] : (typeof responseJson.errors === 'string' ? responseJson.errors : responseJson.message)) || "Failed when trying to post data";
            throw new Error(errMsg)
          } else {
            throw new Error("Failed when trying to post data")
          }
        }
        router.replace('/' + modulPath + '?reload=' + (Date.parse(new Date())))
      } catch (err) {
        console.log("ERR ", err)
        isBadForm.value = true
        swal.fire({
          icon: 'error',
          text: err?.message || err
        })
      }
      isRequesting.value = false
    }
  })
}

//  @else----------------------- LANDING
// Transform role query to apply action button concept (where=this.is_superadmin=true/false and where=this.is_active=true/false) to table column filters
function transformRoleUrl(url) {
  try {
    if (!url || typeof url !== 'string') return url
    if (!url.includes('m_role')) return url
    if (!url.includes('filter_is_superadmin') && !url.includes('filter_superadmin') && !url.includes('filter_is_active') && !url.includes('filter_status')) {
      return url
    }

    const isRelative = url.startsWith('/')
    const base = typeof window !== 'undefined' && window.location ? window.location.origin : 'http://localhost'
    const urlObj = new URL(url, base)
    const isSuperadmin = urlObj.searchParams.get('filter_is_superadmin') ?? urlObj.searchParams.get('filter_superadmin')
    const isActive = urlObj.searchParams.get('filter_is_active') ?? urlObj.searchParams.get('filter_status')
    const currentWhere = urlObj.searchParams.get('where') || ''

    let conds = []
    if (currentWhere) {
      conds = currentWhere.split(/\s+and\s+/i).map(c => c.trim()).filter(Boolean)
    }

    if (isSuperadmin !== null) {
      const val = String(isSuperadmin).toLowerCase().trim()
      const boolVal = (val === 'yes' || val === 'true' || val === '1') ? 'true' : ((val === 'no' || val === 'false' || val === '0') ? 'false' : null)
      conds = conds.filter(c => !/\bthis\.is_superadmin\b/i.test(c))
      if (boolVal !== null) {
        conds.push('this.is_superadmin=' + boolVal)
      }
      urlObj.searchParams.delete('filter_is_superadmin')
      urlObj.searchParams.delete('filter_superadmin')
    }

    if (isActive !== null) {
      const val = String(isActive).toLowerCase().trim()
      const boolVal = (val === 'active' || val === 'true' || val === '1') ? 'true' : ((val === 'inactive' || val === 'false' || val === '0') ? 'false' : null)
      conds = conds.filter(c => !/\bthis\.is_active\b/i.test(c))
      if (boolVal !== null) {
        conds.push('this.is_active=' + boolVal)
      }
      urlObj.searchParams.delete('filter_is_active')
      urlObj.searchParams.delete('filter_status')
    }

    if (conds.length > 0) {
      urlObj.searchParams.set('where', conds.join(' and '))
    } else {
      urlObj.searchParams.delete('where')
    }

    const cleanSearch = decodeURIComponent(urlObj.search).replace(/\+/g, ' ')
    return isRelative ? (urlObj.pathname + cleanSearch) : (urlObj.origin + urlObj.pathname + cleanSearch)
  } catch (e) {
    console.error('Error transforming m_role filter:', e)
    return url
  }
}

// 1. Intercept fetch & XMLHttpRequest
if (typeof window !== 'undefined' && !window.__m_role_filter_intercepted__) {
  window.__m_role_filter_intercepted__ = true

  if (window.fetch) {
    const originalFetch = window.fetch
    window.fetch = async function (input, init) {
      if (typeof input === 'string') {
        input = transformRoleUrl(input)
      } else if (input && input.url) {
        const newUrl = transformRoleUrl(input.url)
        if (newUrl !== input.url && typeof Request !== 'undefined') {
          input = new Request(newUrl, input)
        }
      }
      return originalFetch.call(this, input, init)
    }
  }

  if (typeof XMLHttpRequest !== 'undefined' && XMLHttpRequest.prototype && XMLHttpRequest.prototype.open) {
    const originalXhrOpen = XMLHttpRequest.prototype.open
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      if (typeof url === 'string') {
        url = transformRoleUrl(url)
      }
      return originalXhrOpen.call(this, method, url, ...rest)
    }
  }

  if (window.axios && window.axios.interceptors && window.axios.interceptors.request) {
    window.axios.interceptors.request.use(function (config) {
      if (config && config.url) {
        config.url = transformRoleUrl(config.url)
      }
      return config
    })
  }
}

if (store && store.axios && store.axios.interceptors && store.axios.interceptors.request) {
  store.axios.interceptors.request.use(function (config) {
    if (config && config.url) {
      config.url = transformRoleUrl(config.url)
    }
    return config
  })
}

const activeBtn = ref(null)

function filterShowData(params, noBtn) {
  if (activeBtn.value === noBtn) {
    activeBtn.value = null
    landing.api.params.where = null
  } else {
    activeBtn.value = noBtn
    landing.api.params.where = `this.is_active=${params ? 'true' : 'false'}`
  }

  if (apiTable.value) {
    apiTable.value.reload()
  }
}

const landing = reactive({
  actions: [
    {
      icon: 'trash',
      class: 'bg-red-600 text-light-100',
      title: "Hapus",
      // show: () => store.user.data.username==='developer',
      click(row) {
        swal.fire({
          icon: 'warning',
          text: 'Hapus Data Terpilih?',
          confirmButtonText: 'Yes',
          showDenyButton: true,
        }).then(async (result) => {
          if (result.isConfirmed) {
            try {
              const dataURL = `${store.server.url_backend}/operation${endpointApi}/${row.id}`
              isRequesting.value = true
              const res = await fetch(dataURL, {
                method: 'DELETE',
                headers: {
                  'Content-Type': 'Application/json',
                  Authorization: `${store.user.token_type} ${store.user.token}`
                }
              })
              if (!res.ok) {
                const resultJson = await res.json()
                throw (resultJson.message || "Failed when trying to remove data")
              }
              apiTable.value.reload()
              // const resultJson = await res.json()
            } catch (err) {
              isBadForm.value = true
              swal.fire({
                icon: 'error',
                text: err
              })
            }
            isRequesting.value = false
          }
        })
      }
    },
    {
      icon: 'eye',
      title: "Read",
      class: 'bg-green-600 text-light-100',
      // show: (row) => (currentMenu?.can_read)||store.user.data.username==='developer',
      click(row) {
        router.push(`${route.path}/${row.id}?`+tsId)
      }
    },
    {
      icon: 'edit',
      title: "Edit",
      class: 'bg-blue-600 text-light-100',
      // show: (row) => (currentMenu?.can_update)||store.user.data.username==='developer',
      click(row) {
        router.push(`${route.path}/${row.id}?action=Edit&`+tsId)
      }
    },
    {
      icon: 'copy',
      title: "Copy",
      class: 'bg-gray-600 text-light-100',
      click(row) {
        router.push(`${route.path}/${row.id}?action=Copy&`+tsId)
      }
    }
  ],
  api: {
    url: `${store.server.url_backend}/operation${endpointApi}`,
    headers: {
      'Content-Type': 'Application/json',
      authorization: `${store.user.token_type} ${store.user.token}`
    },
    params: {
      simplest: true,
      searchfield: 'this.name'
    },
    onsuccess(response) {
      if (response && response.data) {
        response.data = response.data.map((item) => {
          const isSuper = (item.is_superadmin === true || item.is_superadmin === 1 || item.is_superadmin === '1' || item.is_superadmin === 'true' || item.is_superadmin === 't')
          const isActive = (item.is_active === true || item.is_active === 1 || item.is_active === '1' || item.is_active === 'true' || item.is_active === 't')
          item.is_superadmin = isSuper
          item.superadmin = isSuper ? 'Yes' : 'No'
          item.is_active = isActive
          item.status = isActive ? 'Active' : 'Inactive'
          return item
        })
      }
      response.page = response.current_page
      response.hasNext = response.has_next
      return response
    }
  },
  columns: [{
    headerName: 'No',
    valueGetter: (params) => params.node.rowIndex + 1,
    width: 60,
    sortable: true,
    resizable: true,
    filter: true,
    cellClass: ['justify-center', 'bg-gray-50', 'border-r', '!border-gray-200']
  },
  // {
  //   headerName: 'Direktorat',
  //   field: 'm_dir.nama',
  //   filter: true,
  //   sortable: true,
  //   flex:1,
  //   filter: 'ColFilter',
  //   resizable: true,
  //   cellClass: [ 'border-r', '!border-gray-200']
  // },
  {
    headerName: 'Nama',
    field: 'name',
    filter: true,
    sortable: true,
    flex:1,
    filter: 'ColFilter',
    resizable: true,
    cellClass: [ 'border-r', '!border-gray-200']
  },
  {
    headerName: 'Super Admin',
    field: 'superadmin',
    filter: 'ColFilter',
    filterParams: {
      options: ['Yes', 'No']
    },
    filterValueGetter: (params) => {
      const val = params.data ? (params.data.is_superadmin !== undefined ? params.data.is_superadmin : params.data.superadmin) : params.value
      return (val === 'Yes' || val === true || val === 1 || val === '1' || val === 'true') ? 'Yes' : 'No'
    },
    valueGetter: (params) => {
      const val = params.data ? (params.data.is_superadmin !== undefined ? params.data.is_superadmin : params.data.superadmin) : params.value
      return (val === 'Yes' || val === true || val === 1 || val === '1' || val === 'true') ? 'Yes' : 'No'
    },
    sortable: true,
    resizable: true,
    flex: 1,
    cellClass: [ 'border-r', '!border-gray-200', 'justify-center'],
    cellRenderer: ({ value }) => {
      return value === 'Yes' || value === true
        ? `<span class="text-green-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">Yes</span>`
        : `<span class="text-gray-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">No</span>`
    }
  },
  {
    headerName: 'Status',
    field: 'status',
    filter: 'ColFilter',
    filterParams: {
      options: ['Active', 'Inactive']
    },
    filterValueGetter: (params) => {
      const val = params.data ? (params.data.is_active !== undefined ? params.data.is_active : params.data.status) : params.value
      return (val === 'Active' || val === true || val === 1 || val === '1' || val === 'true' || val === 't') ? 'Active' : 'Inactive'
    },
    valueGetter: (params) => {
      const val = params.data ? (params.data.is_active !== undefined ? params.data.is_active : params.data.status) : params.value
      return (val === 'Active' || val === true || val === 1 || val === '1' || val === 'true' || val === 't') ? 'Active' : 'Inactive'
    },
    sortable: true,
    resizable: true,
    flex: 1,
    cellClass: [ 'border-r', '!border-gray-200', 'justify-center'],
    cellRenderer: ({ value }) => {
      return value === 'Active' || value === true
        ? `<span class="text-green-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">Active</span>`
        : `<span class="text-gray-500 rounded-md text-xs font-medium px-4 py-1 inline-block capitalize">Inactive</span>`
    }
  },
  ]
})

watch(() => ({ ...(landing.api && landing.api.params) }), (newParams) => {
  if (!newParams || !landing.api || !landing.api.params) return
  let isSuperadmin = newParams.filter_is_superadmin ?? newParams.filter_superadmin
  let isActive = newParams.filter_is_active ?? newParams.filter_status
  let modified = false
  let currentWhere = landing.api.params.where || ''
  let conds = currentWhere ? currentWhere.split(/\s+and\s+/i).map(c => c.trim()).filter(Boolean) : []

  if (isSuperadmin !== undefined) {
    const val = String(isSuperadmin).toLowerCase().trim()
    const boolVal = (val === 'yes' || val === 'true' || val === '1') ? 'true' : ((val === 'no' || val === 'false' || val === '0') ? 'false' : null)
    conds = conds.filter(c => !/\bthis\.is_superadmin\b/i.test(c))
    if (boolVal !== null) {
      conds.push('this.is_superadmin=' + boolVal)
    }
    delete landing.api.params.filter_is_superadmin
    delete landing.api.params.filter_superadmin
    modified = true
  }

  if (isActive !== undefined) {
    const val = String(isActive).toLowerCase().trim()
    const boolVal = (val === 'active' || val === 'true' || val === '1') ? 'true' : ((val === 'inactive' || val === 'false' || val === '0') ? 'false' : null)
    conds = conds.filter(c => !/\bthis\.is_active\b/i.test(c))
    if (boolVal !== null) {
      conds.push('this.is_active=' + boolVal)
    }
    delete landing.api.params.filter_is_active
    delete landing.api.params.filter_status
    modified = true
  }

  if (modified) {
    landing.api.params.where = conds.length > 0 ? conds.join(' and ') : null
  }
}, { deep: true })

onActivated(() => {
  //  reload table api landing
  if (apiTable.value) {
    apiTable.value.reload()
  }
})

//  @endif -------------------------------------------------END
watchEffect(()=>store.commit('set', ['isRequesting', isRequesting.value]))
